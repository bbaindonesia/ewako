
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import ENV from '../config/environment';
import { UserPayload } from '../types/user.types'; 

export const authenticateToken = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; 

  if (token == null) {
    return res.status(401).json({ message: 'Akses ditolak. Token tidak disediakan.' });
  }

  jwt.verify(token, ENV.JWT_SECRET, (err: any, user: any) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ message: 'Token kedaluwarsa. Silakan login kembali.'});
      } else if (err.name === 'JsonWebTokenError') {
        return res.status(403).json({ message: 'Token tidak valid.'});
      } else {
        return res.status(403).json({ message: 'Akses ditolak. Gagal verifikasi token.'});
      }
    }
    req.user = user as UserPayload; 
    next(); 
  });
};
