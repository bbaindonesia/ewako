
import { Request, Response, NextFunction } from 'express';
import { UserPayload } from '../types/user.types'; 

export const authorizeRoles = (allowedRoles: Array<UserPayload['role']>) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = req.user;

    if (!user) {
      return res.status(401).json({ message: 'Akses ditolak. Pengguna tidak terautentikasi.' });
    }

    const userRole = user.role;
    if (allowedRoles.includes(userRole)) {
      next(); 
    } else {
      return res.status(403).json({ message: 'Akses ditolak. Anda tidak memiliki izin untuk mengakses sumber daya ini.' });
    }
  };
};
