
import { Request, Response, NextFunction, ErrorRequestHandler } from 'express';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export const errorHandler: ErrorRequestHandler = (err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error("Unhandled Error:", err.stack || err);

  let statusCode = 500;
  let message = 'Terjadi kesalahan pada server.';

  // TODO: Implement more specific error handling based on error types or codes
  // For example:
  // if (err instanceof CustomAPIError) {
  //   statusCode = err.statusCode;
  //   message = err.message;
  // } else if (err.name === 'ValidationError') { // Example for a validation library
  //   statusCode = 400;
  //   message = err.message;
  // }

  return res.status(statusCode).json({ message });
};
