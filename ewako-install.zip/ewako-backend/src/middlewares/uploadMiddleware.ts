
import multer from 'multer';
import path from 'path';
import fs from 'fs';

// Helper function to ensure directory exists
const ensureDirExists = (dirPath: string) => {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }
};

// --- Storage configuration for Payment Proofs ---
const paymentStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/proofs/';
        ensureDirExists(uploadPath);
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    },
});

const fileFilter = (req: any, file: any, cb: any) => {
    const allowedTypes = /jpeg|jpg|png|pdf/;
    const mimetype = allowedTypes.test(file.mimetype);
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    if (mimetype && extname) {
        return cb(null, true);
    }
    cb('Error: File type not allowed! Only jpeg, jpg, png, and pdf are allowed.');
};

export const uploadPaymentProof = multer({
    storage: paymentStorage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: fileFilter,
}).single('paymentProofFile'); // 'paymentProofFile' must match the name attribute in the form data


// --- Storage configuration for Chat Files ---
const chatStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/chat/';
        ensureDirExists(uploadPath);
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    },
});

export const uploadChatFile = multer({
    storage: chatStorage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: fileFilter,
}).single('chatFile'); // 'chatFile' must match the name attribute in the form data
