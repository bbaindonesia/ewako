
import express, { Application, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import path from 'path';
import ENV from './config/environment';
import apiRoutes from './routes/index';
import { errorHandler } from './middlewares/errorHandler';
import { testConnection } from './config/database';

const app: Application = express();
const port: string | number = ENV.PORT;

// Test Database Connection
testConnection();

// Middleware
const corsOptions = {
  origin: ENV.CORS_ORIGIN,
  optionsSuccessStatus: 200,
};
app.use(cors(corsOptions));

app.use(express.json({ limit: '10mb' })); 
app.use(express.urlencoded({ extended: true, limit: '10mb' })); 

// Serve static files from the 'uploads' directory
// `__dirname` will correctly point to the directory of the currently executing file.
// In dev (ts-node): /ewako-backend/src -> path.join resolves to /ewako-backend/uploads
// In prod (node dist/): /ewako-backend/dist -> path.join resolves to /ewako-backend/uploads
app.use('/uploads', express.static(path.join(__dirname, '../../uploads')));

// API Routes
app.use('/api', apiRoutes);

// Root health check (optional)
app.get('/', (req: Request, res: Response) => { 
  return res.send('Ewako Royal Backend is healthy!');
});

// Error Handling Middleware (should be last)
app.use(errorHandler); 

// Start Server
app.listen(port, () => {
  console.log(`[Backend Server] Running at http://localhost:${port}`);
  console.log(`[Backend Server] API base path: http://localhost:${port}/api`);
  console.log(`[Backend Server] CORS allowed origins: ${ENV.CORS_ORIGIN.join(', ')}`);
  console.log(`[Backend Server] Serving static files from: ${path.join(__dirname, '../../uploads')}`);
});
