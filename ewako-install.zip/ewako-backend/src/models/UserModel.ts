
import pool from '../config/database';
import { UserDbRecord, UserDataForModel } from '../types/user.types'; // Use UserDbRecord for return types from DB

export class UserModel {
  static async create(userData: UserDataForModel): Promise<UserDbRecord | null> {
    const sql = 'INSERT INTO users (id, name, email, phone, ppiu_name, address, password_hash, role, account_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
    try {
      await pool.query(sql, [
        userData.id, 
        userData.name,
        userData.email,
        userData.phone,
        userData.ppiu_name, 
        userData.address,
        userData.password_hash, 
        userData.role || 'customer',
        userData.account_status || 'pending_approval'
      ]);
      return this.findByIdInternal(userData.id); // Fetch the full record including defaults from DB
    } catch (error) {
      console.error('Error creating user:', error);
      if ((error as any).code === 'ER_DUP_ENTRY') {
        const errorMessage = (error as any).sqlMessage || '';
        if (errorMessage.includes("for key 'users.email'")) { 
          throw new Error('Email sudah terdaftar.');
        } else if (errorMessage.includes("for key 'users.phone'")) { 
          throw new Error('Nomor telepon sudah terdaftar.');
        } else if (errorMessage.includes("for key 'PRIMARY'")) { 
            throw new Error('ID Pengguna sudah ada (masalah internal).');
        }
        throw new Error('Gagal membuat pengguna karena data duplikat.');
      }
      throw new Error('Gagal membuat pengguna.');
    }
  }

  static async findByEmailOrPhone(emailOrPhone: string): Promise<UserDbRecord | null> {
    const sql = 'SELECT * FROM users WHERE email = ? OR phone = ? LIMIT 1';
    try {
      const [rows] = await pool.query(sql, [emailOrPhone, emailOrPhone]);
      const users = rows as any[];
      return users.length > 0 ? (users[0] as UserDbRecord) : null;
    } catch (error) {
      console.error('Error finding user by email/phone:', error);
      throw new Error('Error saat mencari pengguna.');
    }
  }
  
  // Internal findById that includes password_hash, for auth purposes
  static async findByIdInternal(id: string): Promise<UserDbRecord | null> {
    const sql = 'SELECT * FROM users WHERE id = ?';
    try {
      const [rows] = await pool.query(sql, [id]);
      const users = rows as any[];
      return users.length > 0 ? (users[0] as UserDbRecord) : null;
    } catch (error) {
      console.error('Error finding user by id (internal):', error);
      throw new Error('Error saat mencari pengguna.');
    }
  }

  // Public findById that excludes password_hash
  static async findById(id: string): Promise<Omit<UserDbRecord, 'password_hash'> | null> {
    const sql = 'SELECT id, email, phone, name, role, ppiu_name, address, account_status, created_at, updated_at FROM users WHERE id = ?';
    try {
      const [rows] = await pool.query(sql, [id]);
      const users = rows as any[];
      return users.length > 0 ? (users[0] as Omit<UserDbRecord, 'password_hash'>) : null;
    } catch (error) {
      console.error('Error finding user by id:', error);
      throw new Error('Error saat mencari pengguna.');
    }
  }

  static async findAll(roleFilter?: UserDbRecord['role'] | UserDbRecord['role'][]): Promise<Array<Omit<UserDbRecord, 'password_hash'>>> {
    let sql = 'SELECT id, email, phone, name, role, ppiu_name, address, account_status, created_at, updated_at FROM users';
    const params: string[] = [];
    if (roleFilter) {
      if (Array.isArray(roleFilter)) {
        sql += ` WHERE role IN (${roleFilter.map(() => '?').join(',')})`;
        params.push(...roleFilter);
      } else {
        sql += ' WHERE role = ?';
        params.push(roleFilter);
      }
    }
    sql += ' ORDER BY created_at DESC';
    try {
      const [rows] = await pool.query(sql, params);
      return rows as Array<Omit<UserDbRecord, 'password_hash'>>;
    } catch (error) {
      console.error('Error fetching all users:', error);
      throw new Error('Gagal mengambil data pengguna.');
    }
  }

  static async update(userId: string, updates: Partial<Pick<UserDbRecord, 'name' | 'email' | 'phone' | 'ppiu_name' | 'address'>>): Promise<UserDbRecord | null> {
    const setClauses = Object.keys(updates)
      .map(key => `${key} = ?`)
      .join(', ');
    if (!setClauses) return this.findByIdInternal(userId); // No actual updates

    const values = Object.values(updates);
    const sql = `UPDATE users SET ${setClauses}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
    
    try {
      const [result] = await pool.query(sql, [...values, userId]);
      const updateResult = result as any;
      if (updateResult.affectedRows === 0) {
        return null; // User not found or no changes made
      }
      return this.findByIdInternal(userId);
    } catch (error) {
      console.error('Error updating user:', error);
      if ((error as any).code === 'ER_DUP_ENTRY') {
          throw new Error('Email atau nomor telepon sudah digunakan oleh pengguna lain.');
      }
      throw new Error('Gagal memperbarui data pengguna.');
    }
  }

  static async updateAccountStatus(userId: string, newStatus: UserDbRecord['account_status']): Promise<UserDbRecord | null> {
    const sql = 'UPDATE users SET account_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?';
    try {
      const [result] = await pool.query(sql, [newStatus, userId]);
      const updateResult = result as any;
      if (updateResult.affectedRows === 0) {
        return null; 
      }
      return this.findByIdInternal(userId);
    } catch (error) {
      console.error('Error updating account status:', error);
      throw new Error('Gagal memperbarui status akun pengguna.');
    }
  }
}