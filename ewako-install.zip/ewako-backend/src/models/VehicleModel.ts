
import pool from '../config/database';
import { v4 as uuidv4 } from 'uuid';
import { VehicleDbRecord } from '../types/vehicle.types';

export class VehicleModel {
    static async create(data: Omit<VehicleDbRecord, 'id' | 'created_at' | 'updated_at'>): Promise<VehicleDbRecord | null> {
        const id = uuidv4();
        const sql = 'INSERT INTO vehicles (id, type, name, plate_number, driver_name, driver_phone, company_name) VALUES (?, ?, ?, ?, ?, ?, ?)';
        try {
            await pool.query(sql, [
                id,
                data.type,
                data.name,
                data.plate_number,
                data.driver_name,
                data.driver_phone,
                data.company_name,
            ]);
            return this.findById(id);
        } catch (error) {
            console.error('Error creating vehicle:', error);
             if ((error as any).code === 'ER_DUP_ENTRY' && (error as any).sqlMessage?.includes('plate_number_unique')) {
                throw new Error('Nomor plat kendaraan sudah terdaftar.');
            }
            throw new Error('Gagal menyimpan kendaraan ke database.');
        }
    }

    static async findById(id: string): Promise<VehicleDbRecord | null> {
        const sql = 'SELECT * FROM vehicles WHERE id = ?';
        try {
            const [rows] = await pool.query(sql, [id]);
            const vehicles = rows as any[];
            return vehicles.length > 0 ? (vehicles[0] as VehicleDbRecord) : null;
        } catch (error) {
            console.error('Error finding vehicle by ID:', error);
            throw new Error('Gagal mengambil data kendaraan dari database.');
        }
    }

    static async findAll(): Promise<VehicleDbRecord[]> {
        const sql = 'SELECT * FROM vehicles ORDER BY created_at DESC';
        try {
            const [rows] = await pool.query(sql);
            return rows as VehicleDbRecord[];
        } catch (error) {
            console.error('Error fetching all vehicles:', error);
            throw new Error('Gagal mengambil daftar kendaraan dari database.');
        }
    }

    static async update(id: string, updates: Partial<Omit<VehicleDbRecord, 'id' | 'created_at' | 'updated_at'>>): Promise<VehicleDbRecord | null> {
        const setClauses = Object.keys(updates)
            .map(key => `${key} = ?`)
            .join(', ');
        if (!setClauses) return this.findById(id);

        const values = Object.values(updates);
        const sql = `UPDATE vehicles SET ${setClauses}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;

        try {
            const [result] = await pool.query(sql, [...values, id]);
            const updateResult = result as any;
            if (updateResult.affectedRows === 0) {
                return null; // Vehicle not found or no changes made
            }
            return this.findById(id);
        } catch (error) {
            console.error('Error updating vehicle:', error);
             if ((error as any).code === 'ER_DUP_ENTRY' && (error as any).sqlMessage?.includes('plate_number_unique')) {
                throw new Error('Nomor plat kendaraan sudah terdaftar untuk kendaraan lain.');
            }
            throw new Error('Gagal memperbarui data kendaraan di database.');
        }
    }

    static async delete(id: string): Promise<boolean> {
        const sql = 'DELETE FROM vehicles WHERE id = ?';
        try {
            const [result] = await pool.query(sql, [id]);
            const deleteResult = result as any;
            return deleteResult.affectedRows > 0;
        } catch (error) {
            console.error('Error deleting vehicle:', error);
            // Check for foreign key constraint errors if vehicles are linked elsewhere
            if ((error as any).code === 'ER_ROW_IS_REFERENCED_2') {
                throw new Error('Gagal menghapus kendaraan karena masih terkait dengan data lain (misalnya, rute paket).');
            }
            throw new Error('Gagal menghapus kendaraan dari database.');
        }
    }
}