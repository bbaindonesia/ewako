
import pool from '../config/database';
import { v4 as uuidv4 } from 'uuid';
import { 
    OrderDbRecord, OrderCreationAttributes, PackageInfoData, ManifestItem, 
    Payment, ChatMessage, OrderDataUpdatePayload, AddPaymentPayload, OrderStatus, 
    PaymentDbRecord, BusRouteItem, ZiarahRouteItem 
} from '../types/order.types';
import { 
    AddHandlingReportPayload, HandlingReportJemaahHealth, HandlingArrivalReportDataSpecifics, 
    HandlingHotelCheckInReportDataSpecifics, HandlingActivityReportDataSpecifics, 
    HandlingDepartureReportDataSpecifics 
} from '../types/handling.types';

export class OrderModel {
    static async createOrder(orderId: string, data: OrderCreationAttributes): Promise<string> {
        const sql = 'INSERT INTO orders (id, user_id, service_type, data, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())';
        await pool.query(sql, [
            orderId,
            data.userId,
            data.serviceType,
            JSON.stringify(data.data),
            data.status || 'Request Confirmation'
        ]);
        return orderId;
    }

    static async findOrderById(orderId: string): Promise<OrderDbRecord | null> {
        const [rows] = await pool.query('SELECT * FROM orders WHERE id = ?', [orderId]);
        const dbOrders = rows as OrderDbRecord[];
        return dbOrders.length > 0 ? dbOrders[0] : null;
    }

    static async findAllOrders(userId?: string): Promise<OrderDbRecord[]> {
        let sql = 'SELECT * FROM orders';
        const params = [];
        if (userId) {
            sql += ' WHERE user_id = ?';
            params.push(userId);
        }
        sql += ' ORDER BY created_at DESC';
        const [rows] = await pool.query(sql, params);
        return rows as OrderDbRecord[];
    }
    
    static async updateStatus(orderId: string, status: OrderStatus, customerConfirmation?: boolean): Promise<void> {
        let sql = 'UPDATE orders SET status = ?, updated_at = NOW()';
        const params: (string | boolean | null)[] = [status];
        
        if (customerConfirmation !== undefined) {
            sql += ', customer_confirmation = ?';
            params.push(customerConfirmation);
        }
        
        sql += ' WHERE id = ?';
        params.push(orderId);

        await pool.query(sql, params);
    }
    
    static async updateData(orderId: string, data: OrderDataUpdatePayload): Promise<void> {
        const sql = 'UPDATE orders SET data = ?, updated_at = NOW() WHERE id = ?';
        await pool.query(sql, [JSON.stringify(data), orderId]);
    }

    static async updatePricingAndData(orderId: string, data: any, totalPrice: number): Promise<void> {
        const sql = 'UPDATE orders SET data = ?, total_price = ?, updated_at = NOW() WHERE id = ?';
        await pool.query(sql, [JSON.stringify(data), totalPrice, orderId]);
    }
    
    static async savePackageInfo(orderId: string, packageInfo: PackageInfoData): Promise<void> {
        const busRoutes = packageInfo.busRoutes || [];
        const ziarahRoutes = packageInfo.ziarahRoutes || [];
        delete packageInfo.busRoutes;
        delete packageInfo.ziarahRoutes;

        const conn = await pool.getConnection();
        try {
            await conn.beginTransaction();

            const pkgSql = `
                INSERT INTO order_package_info (order_id, group_code, ppiu_name, ppiu_phone, pax_count, madinah_hotel_info_legacy, makkah_hotel_info_legacy, madinah_hotel_name, madinah_hotel_nights, madinah_hotel_check_in, madinah_hotel_check_out, madinah_rooms_quad, madinah_rooms_triple, madinah_rooms_double, makkah_hotel_name, makkah_hotel_nights, makkah_hotel_check_in, makkah_hotel_check_out, makkah_rooms_quad, makkah_rooms_triple, makkah_rooms_double, bus_vehicle_id, bus_name, bus_vehicle_type, bus_driver_name, bus_driver_phone, bus_syarikah_number, mutowif_name, mutowif_phone, representative_name, representative_phone, ewako_royal_phone, airline_name, airline_code, pnr_code, arrival_date_time, arrival_terminal, departure_date_time, departure_terminal, tour_leader_name, tour_leader_phone, tour_guide_name, tour_guide_phone, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                ON DUPLICATE KEY UPDATE
                group_code = VALUES(group_code), ppiu_name = VALUES(ppiu_name), ppiu_phone = VALUES(ppiu_phone), pax_count = VALUES(pax_count), madinah_hotel_info_legacy = VALUES(madinah_hotel_info_legacy), makkah_hotel_info_legacy = VALUES(makkah_hotel_info_legacy), madinah_hotel_name = VALUES(madinah_hotel_name), madinah_hotel_nights = VALUES(madinah_hotel_nights), madinah_hotel_check_in = VALUES(madinah_hotel_check_in), madinah_hotel_check_out = VALUES(madinah_hotel_check_out), madinah_rooms_quad = VALUES(madinah_rooms_quad), madinah_rooms_triple = VALUES(madinah_rooms_triple), madinah_rooms_double = VALUES(madinah_rooms_double), makkah_hotel_name = VALUES(makkah_hotel_name), makkah_hotel_nights = VALUES(makkah_hotel_nights), makkah_hotel_check_in = VALUES(makkah_hotel_check_in), makkah_hotel_check_out = VALUES(makkah_hotel_check_out), makkah_rooms_quad = VALUES(makkah_rooms_quad), makkah_rooms_triple = VALUES(makkah_rooms_triple), makkah_rooms_double = VALUES(makkah_rooms_double), bus_vehicle_id = VALUES(bus_vehicle_id), bus_name = VALUES(bus_name), bus_vehicle_type = VALUES(bus_vehicle_type), bus_driver_name = VALUES(bus_driver_name), bus_driver_phone = VALUES(bus_driver_phone), bus_syarikah_number = VALUES(bus_syarikah_number), mutowif_name = VALUES(mutowif_name), mutowif_phone = VALUES(mutowif_phone), representative_name = VALUES(representative_name), representative_phone = VALUES(representative_phone), ewako_royal_phone = VALUES(ewako_royal_phone), airline_name = VALUES(airline_name), airline_code = VALUES(airline_code), pnr_code = VALUES(pnr_code), arrival_date_time = VALUES(arrival_date_time), arrival_terminal = VALUES(arrival_terminal), departure_date_time = VALUES(departure_date_time), departure_terminal = VALUES(departure_terminal), tour_leader_name = VALUES(tour_leader_name), tour_leader_phone = VALUES(tour_leader_phone), tour_guide_name = VALUES(tour_guide_name), tour_guide_phone = VALUES(tour_guide_phone), updated_at = NOW();
            `;
            await conn.query(pkgSql, [
                orderId, packageInfo.groupCode, packageInfo.ppiuName, packageInfo.ppiuPhone, packageInfo.paxCount,
                packageInfo.madinahHotelInfo, packageInfo.makkahHotelInfo,
                packageInfo.madinahHotelStructured?.name, packageInfo.madinahHotelStructured?.nights, packageInfo.madinahHotelStructured?.checkIn, packageInfo.madinahHotelStructured?.checkOut,
                packageInfo.madinahHotelStructured?.rooms.quad, packageInfo.madinahHotelStructured?.rooms.triple, packageInfo.madinahHotelStructured?.rooms.double,
                packageInfo.makkahHotelStructured?.name, packageInfo.makkahHotelStructured?.nights, packageInfo.makkahHotelStructured?.checkIn, packageInfo.makkahHotelStructured?.checkOut,
                packageInfo.makkahHotelStructured?.rooms.quad, packageInfo.makkahHotelStructured?.rooms.triple, packageInfo.makkahHotelStructured?.rooms.double,
                packageInfo.busVehicleId, packageInfo.busName, packageInfo.busVehicleType, packageInfo.busDriverName, packageInfo.busDriverPhone, packageInfo.busSyarikahNumber,
                packageInfo.mutowifName, packageInfo.mutowifPhone, packageInfo.representativeName, packageInfo.representativePhone, packageInfo.ewakoRoyalPhone,
                packageInfo.airlineName, packageInfo.airlineCode, packageInfo.pnrCode,
                packageInfo.arrivalDateTime, packageInfo.arrivalTerminal, packageInfo.departureDateTime, packageInfo.departureTerminal,
                packageInfo.tourLeaderName, packageInfo.tourLeaderPhone, packageInfo.tourGuideName, packageInfo.tourGuidePhone
            ]);

            // Sync bus routes
            await conn.query('DELETE FROM order_package_bus_routes WHERE package_info_order_id = ?', [orderId]);
            if (busRoutes.length > 0) {
                const busRoutesSql = 'INSERT INTO order_package_bus_routes (id, package_info_order_id, date, from_location, to_location, route_vehicle_id, vehicle_details) VALUES ?';
                const busRoutesValues = busRoutes.map((r: BusRouteItem) => [r.id, orderId, r.date, r.from, r.to, r.routeVehicleId, r.vehicleDetails]);
                await conn.query(busRoutesSql, [busRoutesValues]);
            }

            // Sync ziarah routes
            await conn.query('DELETE FROM order_package_ziarah_routes WHERE package_info_order_id = ?', [orderId]);
            if (ziarahRoutes.length > 0) {
                const ziarahRoutesSql = 'INSERT INTO order_package_ziarah_routes (id, package_info_order_id, tujuan, kota, tanggal, waktu, remake) VALUES ?';
                const ziarahRoutesValues = ziarahRoutes.map((r: ZiarahRouteItem) => [r.id, orderId, r.tujuan, r.kota, r.tanggal, r.waktu, r.remake]);
                await conn.query(ziarahRoutesSql, [ziarahRoutesValues]);
            }

            await conn.commit();
        } catch (error) {
            await conn.rollback();
            console.error("Error saving package info:", error);
            throw error;
        } finally {
            conn.release();
        }
    }

    static async saveManifest(orderId: string, manifest: ManifestItem[]): Promise<void> {
        const conn = await pool.getConnection();
        try {
            await conn.beginTransaction();
            await conn.query('DELETE FROM order_manifest_items WHERE order_id = ?', [orderId]);

            if (manifest.length > 0) {
                const sql = 'INSERT INTO order_manifest_items (id, order_id, nama_jemaah, jenis_kelamin, tanggal_lahir, nomor_visa, nama_di_paspor, nomor_paspor, tanggal_terbit_paspor, tanggal_expired_paspor, kota_tempat_issued_paspor, kota_asal_keberangkatan) VALUES ?';
                const values = manifest.map(item => [
                    item.id, orderId, item.namaJemaah, item.jenisKelamin, item.tanggalLahir || null, item.nomorVisa,
                    item.namaDiPaspor, item.nomorPaspor, item.tanggalTerbitPaspor || null, item.tanggalExpiredPaspor || null,
                    item.kotaTempatIssuedPaspor, item.kotaAsalKeberangkatan
                ]);
                await conn.query(sql, [values]);
            }
            await conn.commit();
        } catch (error) {
            await conn.rollback();
            console.error("Error saving manifest:", error);
            throw error;
        } finally {
            conn.release();
        }
    }
    
    static async addPayment(orderId: string, paymentId: string, paymentData: AddPaymentPayload, filePath?: string, fileName?: string, fileType?: string): Promise<void> {
        const sql = 'INSERT INTO order_payments (id, order_id, user_id, amount, payment_date, payment_type, payment_method, notes, payment_proof_file_path, payment_proof_file_name, payment_proof_file_type, sender_account_name, sender_account_number, sender_bank_name, sender_transfer_method, destination_bank_name, destination_account_number, payment_gateway_type, payment_approval_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
        await pool.query(sql, [
            paymentId, orderId, paymentData.userId, paymentData.amount, paymentData.paymentDate,
            paymentData.paymentType, paymentData.paymentMethod, paymentData.notes, filePath, fileName, fileType,
            paymentData.senderAccountName, paymentData.senderAccountNumber, paymentData.senderBankName, paymentData.senderTransferMethod,
            paymentData.destinationBankName, paymentData.destinationAccountNumber, paymentData.paymentGatewayType,
            'Pending'
        ]);
    }
    
    static async findPaymentById(paymentId: string): Promise<PaymentDbRecord | null> {
        const [rows] = await pool.query('SELECT * FROM order_payments WHERE id = ?', [paymentId]);
        const payments = rows as PaymentDbRecord[];
        return payments.length > 0 ? payments[0] : null;
    }

    static async deletePayment(paymentId: string): Promise<void> {
        await pool.query('DELETE FROM order_payments WHERE id = ?', [paymentId]);
    }
    
    static async updatePaymentStatus(paymentId: string, status: "Pending" | "Approved" | "Rejected", approvedByUserId: string, adminActionNotes?: string): Promise<void> {
        const approvedAtField = status === 'Approved' ? 'approved_at = NOW(),' : 'approved_at = NULL,';
        const rejectedAtField = status === 'Rejected' ? 'rejected_at = NOW(),' : 'rejected_at = NULL,';
        
        const sql = `UPDATE order_payments SET payment_approval_status = ?, ${approvedAtField} ${rejectedAtField} approved_by_user_id = ?, admin_action_notes = ?, updated_at = NOW() WHERE id = ?`;
        await pool.query(sql, [status, approvedByUserId, adminActionNotes, paymentId]);
    }
    
    static async addChatMessage(messageId: string, orderId: string, senderId: string, senderName: string, text?: string, filePath?: string, fileName?: string, fileType?: string): Promise<void> {
        const sql = 'INSERT INTO order_chat_history (id, order_id, sender_id, sender_name, text_message, file_path, file_name, file_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
        await pool.query(sql, [messageId, orderId, senderId, senderName, text, filePath, fileName, fileType]);
    }
    
    static async findChatMessageById(messageId: string): Promise<ChatMessage | null> {
        const [rows] = await pool.query('SELECT * FROM order_chat_history WHERE id = ?', [messageId]);
        const messages = rows as any[];
        return messages.length > 0 ? messages[0] : null;
    }

    static async findChatMessagesByOrderId(orderId: string): Promise<ChatMessage[]> {
        const [rows] = await pool.query('SELECT * FROM order_chat_history WHERE order_id = ? ORDER BY timestamp ASC', [orderId]);
        return rows as ChatMessage[];
    }

    static async saveHandlingReport(orderId: string, payload: AddHandlingReportPayload): Promise<void> {
        const connection = await pool.getConnection();
        try {
            await connection.beginTransaction();
            
            const [existingReports] = await connection.query('SELECT id FROM handling_reports WHERE order_id = ? AND report_type = ?', [orderId, payload.reportType]);
            for (const report of (existingReports as any[])) {
                // Manually cascade delete
                await connection.query('DELETE FROM handling_report_jemaah_health WHERE handling_report_id = ?', [report.id]);
                await connection.query('DELETE FROM handling_report_jemaah_absensi WHERE handling_report_id = ?', [report.id]);
                await connection.query('DELETE FROM handling_reports_arrival WHERE handling_report_id = ?', [report.id]);
                await connection.query('DELETE FROM handling_reports_hotel_check_in WHERE handling_report_id = ?', [report.id]);
                const [activityReport] = await connection.query('SELECT id FROM handling_reports_activity WHERE handling_report_id = ?', [report.id]);
                if ((activityReport as any[]).length > 0) {
                    await connection.query('DELETE FROM handling_report_activity_tujuan WHERE activity_report_id = ?', [(activityReport as any[])[0].id]);
                }
                await connection.query('DELETE FROM handling_reports_activity WHERE handling_report_id = ?', [report.id]);
                await connection.query('DELETE FROM handling_reports_departure WHERE handling_report_id = ?', [report.id]);
                await connection.query('DELETE FROM handling_reports WHERE id = ?', [report.id]);
            }

            const handlingReportId = uuidv4();
            const baseSql = 'INSERT INTO handling_reports (id, order_id, report_type, created_by_user_id, petugas_pj_id, petugas_pj_name) VALUES (?, ?, ?, ?, ?, ?)';
            await connection.query(baseSql, [
                handlingReportId, orderId, payload.reportType,
                payload.createdByUserId, payload.petugasPJId, payload.petugasPJName
            ]);
            
            const specificData = { ...payload.data }; // Clone to avoid mutation
            const { absensiJemaah, jemaahSakitDetails, absensiJemaahKeberangkatan, tujuanKegiatan, absensiJemaahCheckout, jemaahSakitDetailsCheckout, ...restSpecifics } = specificData as any;
            
            let absensiToSave: { [key: string]: boolean } = {};
            let healthDetailsToSave: HandlingReportJemaahHealth[] = [];
            let absensiTypeForDb: 'Arrival' | 'ActivityDeparture' | 'CheckoutHotel' | null = null;
            let healthContextForDb: 'Arrival' | 'Activity' | 'DepartureCheckout' | null = null;
            
            if (payload.reportType === 'Arrival') {
                await connection.query('INSERT INTO handling_reports_arrival SET handling_report_id = ?, ?', [handlingReportId, restSpecifics]);
                absensiToSave = absensiJemaah; healthDetailsToSave = jemaahSakitDetails;
                absensiTypeForDb = 'Arrival'; healthContextForDb = 'Arrival';
            } else if (payload.reportType === 'HotelCheckIn') {
                await connection.query('INSERT INTO handling_reports_hotel_check_in SET handling_report_id = ?, ?', [handlingReportId, restSpecifics]);
            } else if (payload.reportType === 'Activity') {
                await connection.query('INSERT INTO handling_reports_activity SET handling_report_id = ?, ?', [handlingReportId, restSpecifics]);
                if (tujuanKegiatan && tujuanKegiatan.length > 0) {
                    const tujuanValues = tujuanKegiatan.map((t: string) => [uuidv4(), handlingReportId, t]);
                    await connection.query('INSERT INTO handling_report_activity_tujuan (id, activity_report_id, tujuan_kegiatan) VALUES ?', [tujuanValues]);
                }
                absensiToSave = absensiJemaahKeberangkatan; healthDetailsToSave = jemaahSakitDetails;
                absensiTypeForDb = 'ActivityDeparture'; healthContextForDb = 'Activity';
            } else if (payload.reportType === 'Departure') {
                await connection.query('INSERT INTO handling_reports_departure SET handling_report_id = ?, ?', [handlingReportId, restSpecifics]);
                absensiToSave = absensiJemaahCheckout; healthDetailsToSave = jemaahSakitDetailsCheckout;
                absensiTypeForDb = 'CheckoutHotel'; healthContextForDb = 'DepartureCheckout';
            }

            if (absensiToSave && Object.keys(absensiToSave).length > 0 && absensiTypeForDb) {
                const absensiValues = Object.entries(absensiToSave).map(([jemaahId, isPresent]) => [uuidv4(), handlingReportId, jemaahId, isPresent, absensiTypeForDb]);
                await connection.query('INSERT INTO handling_report_jemaah_absensi (id, handling_report_id, manifest_item_id, status_kehadiran, absensi_type) VALUES ?', [absensiValues]);
            }
            if (healthDetailsToSave && healthDetailsToSave.length > 0 && healthContextForDb) {
                const healthValues = healthDetailsToSave.map(j => [j.id || uuidv4(), handlingReportId, j.jemaahId, j.namaJemaah, j.nomorPaspor, j.nomorVisa, j.kotaAsal, j.keluhan, healthContextForDb]);
                await connection.query('INSERT INTO handling_report_jemaah_health (id, handling_report_id, manifest_item_id, nama_jemaah_snapshot, nomor_paspor_snapshot, nomor_visa_snapshot, kota_asal_snapshot, keluhan, health_detail_context) VALUES ?', [healthValues]);
            }
            
            await connection.commit();
        } catch (error) {
            await connection.rollback();
            console.error('Error saving handling report in model:', error);
            throw error;
        } finally {
            connection.release();
        }
    }
}
