
import pool from '../config/database';
import { v4 as uuidv4 } from 'uuid';
import { AdminBankAccountDbRecord } from '../types/order.types';

export class AdminBankAccountModel {
    static async create(data: Omit<AdminBankAccountDbRecord, 'id' | 'created_at' | 'updated_at'>): Promise<AdminBankAccountDbRecord | null> {
        const id = uuidv4();
        const sql = 'INSERT INTO admin_bank_accounts (id, bank_name, bank_code, account_number, account_holder_name, branch_name, logo_url) VALUES (?, ?, ?, ?, ?, ?, ?)';
        try {
            await pool.query(sql, [
                id,
                data.bank_name,
                data.bank_code,
                data.account_number,
                data.account_holder_name,
                data.branch_name,
                data.logo_url,
            ]);
            return this.findById(id);
        } catch (error) {
            console.error('Error creating admin bank account:', error);
            throw new Error('Gagal menyimpan rekening bank ke database.');
        }
    }

    static async findById(id: string): Promise<AdminBankAccountDbRecord | null> {
        const sql = 'SELECT * FROM admin_bank_accounts WHERE id = ?';
        try {
            const [rows] = await pool.query(sql, [id]);
            const accounts = rows as any[];
            return accounts.length > 0 ? (accounts[0] as AdminBankAccountDbRecord) : null;
        } catch (error) {
            console.error('Error finding admin bank account by ID:', error);
            throw new Error('Gagal mengambil data rekening bank dari database.');
        }
    }

    static async findAll(): Promise<AdminBankAccountDbRecord[]> {
        const sql = 'SELECT * FROM admin_bank_accounts ORDER BY bank_name ASC';
        try {
            const [rows] = await pool.query(sql);
            return rows as AdminBankAccountDbRecord[];
        } catch (error) {
            console.error('Error fetching all admin bank accounts:', error);
            throw new Error('Gagal mengambil daftar rekening bank dari database.');
        }
    }

    static async update(id: string, updates: Partial<Omit<AdminBankAccountDbRecord, 'id' | 'created_at' | 'updated_at'>>): Promise<AdminBankAccountDbRecord | null> {
        const setClauses = Object.keys(updates)
            .map(key => `${key} = ?`)
            .join(', ');
        if (!setClauses) return this.findById(id);

        const values = Object.values(updates);
        const sql = `UPDATE admin_bank_accounts SET ${setClauses}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;

        try {
            const [result] = await pool.query(sql, [...values, id]);
            const updateResult = result as any;
            if (updateResult.affectedRows === 0) {
                return null; 
            }
            return this.findById(id);
        } catch (error) {
            console.error('Error updating admin bank account:', error);
            throw new Error('Gagal memperbarui data rekening bank di database.');
        }
    }

    static async delete(id: string): Promise<boolean> {
        const sql = 'DELETE FROM admin_bank_accounts WHERE id = ?';
        try {
            const [result] = await pool.query(sql, [id]);
            const deleteResult = result as any;
            return deleteResult.affectedRows > 0;
        } catch (error) {
            console.error('Error deleting admin bank account:', error);
            throw new Error('Gagal menghapus rekening bank dari database.');
        }
    }
}