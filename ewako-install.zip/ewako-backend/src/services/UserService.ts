

import { UserModel } from '../models/UserModel';
import { User as BackendUserType, AuthenticatedUser } from '../types/user.types'; // Using backend specific types

// Helper to convert DB record (snake_case) to AuthenticatedUser (camelCase for frontend)
const mapUserToAuthenticatedUser = (userFromDb: BackendUserType): AuthenticatedUser => {
    return {
        id: userFromDb.id,
        email: userFromDb.email,
        phone: userFromDb.phone || undefined,
        name: userFromDb.name,
        role: userFromDb.role,
        ppiuName: userFromDb.ppiu_name || undefined,
        address: userFromDb.address || undefined,
        accountStatus: userFromDb.account_status,
        createdAt: userFromDb.created_at,
        updatedAt: userFromDb.updated_at,
    };
};


export class UserService {
    static async getAllUsers(roleFilter?: BackendUserType['role'] | BackendUserType['role'][]): Promise<AuthenticatedUser[]> {
        // In a real app, you might want pagination here.
        // UserModel should be adapted to handle filtering by role if the DB query needs it.
        // For now, assume UserModel.findAll() fetches all and we filter here or adapt UserModel.
        const usersFromDb = await UserModel.findAll(roleFilter); // Assuming UserModel.findAll exists and can filter
        return usersFromDb.map(mapUserToAuthenticatedUser);
    }

    static async getUserById(userId: string): Promise<AuthenticatedUser | null> {
        const userFromDb = await UserModel.findById(userId);
        return userFromDb ? mapUserToAuthenticatedUser(userFromDb as BackendUserType) : null;
    }

    static async updateUser(userId: string, updates: Partial<Omit<AuthenticatedUser, 'id' | 'role' | 'accountStatus' | 'password' | 'createdAt' | 'updatedAt'>>): Promise<AuthenticatedUser | null> {
        // Map camelCase keys from 'updates' to snake_case for the UserModel
        const updatesForDb: Partial<Pick<BackendUserType, 'name' | 'email' | 'phone' | 'ppiu_name' | 'address'>> = {};
        if (updates.name !== undefined) updatesForDb.name = updates.name;
        if (updates.email !== undefined) updatesForDb.email = updates.email;
        if (updates.phone !== undefined) updatesForDb.phone = updates.phone;
        if (updates.ppiuName !== undefined) updatesForDb.ppiu_name = updates.ppiuName;
        if (updates.address !== undefined) updatesForDb.address = updates.address;

        const updatedUserFromDb = await UserModel.update(userId, updatesForDb);
        return updatedUserFromDb ? mapUserToAuthenticatedUser(updatedUserFromDb) : null;
    }

    static async updateUserAccountStatus(userId: string, newStatus: BackendUserType['account_status']): Promise<AuthenticatedUser | null> {
        const updatedUserFromDb = await UserModel.updateAccountStatus(userId, newStatus);
        // TODO: Send notification to user about account status change (e.g., via WhatsApp or email)
        return updatedUserFromDb ? mapUserToAuthenticatedUser(updatedUserFromDb) : null;
    }
}