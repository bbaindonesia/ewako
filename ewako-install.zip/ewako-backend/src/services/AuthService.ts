

import bcrypt from 'bcryptjs';
import jwt, { SignOptions } from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid'; // Import uuid
import { UserModel } from '../models/UserModel';
import { UserCreationAttributes, User, UserPayload, UserDataForModel, AuthenticatedUser } from '../types/user.types'; // Updated import
import ENV from '../config/environment';

export class AuthService {
  static async registerUser(userDataFromController: UserCreationAttributes): Promise<AuthenticatedUser> { 
    const existingUserByEmail = await UserModel.findByEmailOrPhone(userDataFromController.email);
    if (existingUserByEmail) {
      throw new Error('Email sudah terdaftar.');
    }
    if (userDataFromController.phone) {
        const existingUserByPhone = await UserModel.findByEmailOrPhone(userDataFromController.phone);
        if (existingUserByPhone) {
            throw new Error('Nomor telepon sudah terdaftar.');
        }
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(userDataFromController.password, salt);

    const newUserId = uuidv4(); 

    const userDataForModel: UserDataForModel = {
      id: newUserId, 
      name: userDataFromController.name,
      email: userDataFromController.email,
      phone: userDataFromController.phone,
      ppiu_name: userDataFromController.ppiuName, 
      address: userDataFromController.address,
      password_hash: hashedPassword, 
      role: 'customer', 
      account_status: 'pending_approval' 
    };

    const newUserFromDb = await UserModel.create(userDataForModel); 
    if (!newUserFromDb) {
        throw new Error('Registrasi gagal, pengguna tidak dapat dibuat.');
    }
    
    const { password_hash, ...userWithoutPasswordSnakeCase } = newUserFromDb;
    
    const userToReturn: AuthenticatedUser = {
        id: userWithoutPasswordSnakeCase.id,
        email: userWithoutPasswordSnakeCase.email,
        phone: userWithoutPasswordSnakeCase.phone || undefined,
        name: userWithoutPasswordSnakeCase.name,
        role: userWithoutPasswordSnakeCase.role,
        ppiuName: userWithoutPasswordSnakeCase.ppiu_name || undefined,
        address: userWithoutPasswordSnakeCase.address || undefined,
        accountStatus: userWithoutPasswordSnakeCase.account_status,
        createdAt: userWithoutPasswordSnakeCase.created_at,
        updatedAt: userWithoutPasswordSnakeCase.updated_at,
    };
    return userToReturn;
  }

  static async loginUser(emailOrPhone: string, passwordInput: string): Promise<{ token: string; user: AuthenticatedUser }> { 
    const userRecord = await UserModel.findByEmailOrPhone(emailOrPhone); 

    if (!userRecord) {
      throw new Error('Email/No. HP atau kata sandi salah.');
    }

    if (!userRecord.password_hash) {
      throw new Error('Autentikasi gagal: data pengguna tidak lengkap.');
    }

    const isMatch = await bcrypt.compare(passwordInput, userRecord.password_hash);

    if (!isMatch) {
      throw new Error('Email/No. HP atau kata sandi salah.');
    }

    const accountStatus = userRecord.account_status;

    if (accountStatus !== 'active') {
        if (accountStatus === 'pending_approval') {
            throw new Error('Akun Anda sedang menunggu persetujuan Admin.');
        } else if (accountStatus === 'suspended') {
            throw new Error('Akun Anda telah ditangguhkan.');
        } else {
            throw new Error('Status akun tidak valid atau tidak aktif. Silakan hubungi Admin.');
        }
    }

    const payload: UserPayload = {
      id: userRecord.id,
      email: userRecord.email,
      role: userRecord.role,
    };

    const signOptions: SignOptions = {
      expiresIn: ENV.JWT_EXPIRES_IN,
    };

    const token = jwt.sign(payload, ENV.JWT_SECRET, signOptions);

    const { password_hash, ...userWithoutPasswordSnakeCase } = userRecord;
    
    const userToReturn: AuthenticatedUser = {
        id: userWithoutPasswordSnakeCase.id,
        email: userWithoutPasswordSnakeCase.email,
        phone: userWithoutPasswordSnakeCase.phone || undefined,
        name: userWithoutPasswordSnakeCase.name,
        role: userWithoutPasswordSnakeCase.role,
        ppiuName: userWithoutPasswordSnakeCase.ppiu_name || undefined,
        address: userWithoutPasswordSnakeCase.address || undefined,
        accountStatus: userWithoutPasswordSnakeCase.account_status,
        createdAt: userWithoutPasswordSnakeCase.created_at,
        updatedAt: userWithoutPasswordSnakeCase.updated_at,
    };
    
    return { token, user: userToReturn };
  }
}
