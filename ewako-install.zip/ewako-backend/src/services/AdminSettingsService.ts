


import { AdminBankAccountModel } from '../models/AdminBankAccountModel';
import { AdminManagedBankAccount as ApiAdminManagedBankAccount } from '../types'; // Use correct import path
import { AdminBankAccountDbRecord } from '../types/order.types'; // Use DB record type for model interaction

// Helper to map DB record (snake_case) to API type (camelCase)
const mapDbToApiBankAccount = (dbAccount: AdminBankAccountDbRecord): ApiAdminManagedBankAccount => {
    return {
        id: dbAccount.id,
        bankName: dbAccount.bank_name,
        bankCode: dbAccount.bank_code || undefined,
        accountNumber: dbAccount.account_number,
        accountHolderName: dbAccount.account_holder_name,
        branchName: dbAccount.branch_name || undefined,
        logoUrl: dbAccount.logo_url || undefined,
    };
};

export class AdminSettingsService {
    static async getBankAccounts(): Promise<ApiAdminManagedBankAccount[]> {
        const dbAccounts = await AdminBankAccountModel.findAll();
        return dbAccounts.map(mapDbToApiBankAccount);
    }

    static async addBankAccount(accountData: Omit<ApiAdminManagedBankAccount, 'id'>): Promise<ApiAdminManagedBankAccount> {
        const dataForDb: Omit<AdminBankAccountDbRecord, 'id' | 'created_at' | 'updated_at'> = {
            bank_name: accountData.bankName,
            bank_code: accountData.bankCode,
            account_number: accountData.accountNumber,
            account_holder_name: accountData.accountHolderName,
            branch_name: accountData.branchName,
            logo_url: accountData.logoUrl,
        };
        const newDbAccount = await AdminBankAccountModel.create(dataForDb);
        if (!newDbAccount) {
            throw new Error('Gagal membuat rekening bank di service.');
        }
        return mapDbToApiBankAccount(newDbAccount);
    }

    static async updateBankAccount(id: string, updates: Partial<Omit<ApiAdminManagedBankAccount, 'id'>>): Promise<ApiAdminManagedBankAccount | null> {
        const updatesForDb: Partial<Omit<AdminBankAccountDbRecord, 'id' | 'created_at' | 'updated_at'>> = {};
        if (updates.bankName !== undefined) updatesForDb.bank_name = updates.bankName;
        if (updates.bankCode !== undefined) updatesForDb.bank_code = updates.bankCode;
        if (updates.accountNumber !== undefined) updatesForDb.account_number = updates.accountNumber;
        if (updates.accountHolderName !== undefined) updatesForDb.account_holder_name = updates.accountHolderName;
        if (updates.branchName !== undefined) updatesForDb.branch_name = updates.branchName;
        if (updates.logoUrl !== undefined) updatesForDb.logo_url = updates.logoUrl;
        
        const updatedDbAccount = await AdminBankAccountModel.update(id, updatesForDb);
        return updatedDbAccount ? mapDbToApiBankAccount(updatedDbAccount) : null;
    }

    static async deleteBankAccount(id: string): Promise<boolean> {
        return AdminBankAccountModel.delete(id);
    }
}