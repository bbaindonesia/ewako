



import { OrderModel } from '../models/OrderModel';
import { 
    OrderWithDetails, OrderCreationAttributes, OrderDataUpdatePayload, PackageInfoData, 
    ManifestItem, Payment, AdminPriceDetailsPayload, OrderStatus, AddPaymentPayload
} from '../types/order.types'; 
import { AddHandlingReportPayload } from '../types/handling.types';
import { mapOrderDbToOrderWithDetails } from '../utils/orderMapping';
import { v4 as uuidv4 } from 'uuid';
import { sendNotificationToCustomer } from './whatsappService';
import { ADMIN_WHATSAPP_NUMBER } from '../constants';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MOCK_EXCHANGE_RATES_BACKEND = {
  USD_TO_IDR: 16250,
  SAR_TO_IDR: 4350,
};

export class OrderService {
    static async createOrder(orderData: OrderCreationAttributes): Promise<OrderWithDetails> {
        const orderId = uuidv4();
        await OrderModel.createOrder(orderId, orderData);
        const newOrder = await this.getOrderById(orderId);
        if (!newOrder) {
            throw new Error("Gagal membuat pesanan atau mengambil data pesanan yang baru dibuat.");
        }
        
        try {
            const customerName = (newOrder.data as any).customerName || 'Pelanggan Baru';
            const message = `Pesanan Baru Diterima!\nID: ${orderId.substring(0,8)}\nJenis: ${newOrder.serviceType}\nPemesan: ${customerName}\nSilakan periksa dashboard admin.`;
            sendNotificationToCustomer(ADMIN_WHATSAPP_NUMBER, message);
        } catch(e){
            console.error("Gagal mengirim notifikasi WhatsApp ke admin:", e);
        }

        return newOrder;
    }

    static async getOrders(userId?: string): Promise<OrderWithDetails[]> {
        const dbOrders = await OrderModel.findAllOrders(userId);
        const ordersWithDetails = await Promise.all(
            dbOrders.map(dbOrder => mapOrderDbToOrderWithDetails(dbOrder))
        );
        return ordersWithDetails;
    }
    
    static async getOrderById(orderId: string): Promise<OrderWithDetails | null> {
        const dbOrder = await OrderModel.findOrderById(orderId);
        if (!dbOrder) return null;
        return mapOrderDbToOrderWithDetails(dbOrder);
    }
    
    static async updateOrderStatus(orderId: string, status: OrderStatus, customerConfirmation?: boolean): Promise<OrderWithDetails | null> {
        await OrderModel.updateStatus(orderId, status, customerConfirmation);
        return this.getOrderById(orderId);
    }
    
    static async updateOrderData(orderId: string, data: OrderDataUpdatePayload): Promise<OrderWithDetails | null> {
        const currentOrder = await OrderModel.findOrderById(orderId);
        if (!currentOrder) throw new Error("Pesanan tidak ditemukan.");

        const currentData = JSON.parse(currentOrder.data || '{}');
        const newData = { ...currentData, ...data };
        await OrderModel.updateData(orderId, newData);
        return this.getOrderById(orderId);
    }
    
    static async updatePackageInfo(orderId: string, packageInfo: PackageInfoData): Promise<OrderWithDetails | null> {
        await OrderModel.savePackageInfo(orderId, packageInfo);
        return this.getOrderById(orderId);
    }

    static async updateOrderManifest(orderId: string, manifest: ManifestItem[]): Promise<OrderWithDetails | null> {
        await OrderModel.saveManifest(orderId, manifest);
        return this.getOrderById(orderId);
    }

    static async adminSetPriceAndDetails(orderId: string, details: AdminPriceDetailsPayload): Promise<OrderWithDetails | null> {
        const order = await this.getOrderById(orderId);
        if (!order) throw new Error("Pesanan tidak ditemukan.");

        const orderData = { ...order.data } as any; // Copy of data
        let totalIDR = 0;

        // Assign prices and names to the data object
        if (details.madinahHotelRoomPricesSAR) {
            if (!orderData.madinahHotel) orderData.madinahHotel = {};
            if (!orderData.madinahHotel.pricesSAR) orderData.madinahHotel.pricesSAR = {};
            Object.assign(orderData.madinahHotel.pricesSAR, details.madinahHotelRoomPricesSAR);
        }
        if (details.makkahHotelRoomPricesSAR) {
            if (!orderData.makkahHotel) orderData.makkahHotel = {};
            if (!orderData.makkahHotel.pricesSAR) orderData.makkahHotel.pricesSAR = {};
            Object.assign(orderData.makkahHotel.pricesSAR, details.makkahHotelRoomPricesSAR);
        }
        if (details.visaPricePerPaxUSD !== undefined) orderData.visaPricePerPaxUSD = details.visaPricePerPaxUSD;
        if (details.handlingPricePerPaxSAR !== undefined) orderData.handlingPricePerPaxSAR = details.handlingPricePerPaxSAR;
        if (details.busPriceTotalSAR !== undefined) orderData.busPriceTotalSAR = details.busPriceTotalSAR;
        if (details.muasasahName !== undefined) orderData.muasasahName = details.muasasahName;

        // Calculate total price in IDR
        const calc = (price: number | undefined, multiplier: number | undefined, rate: number) => ((price || 0) * (multiplier || 0)) * rate;

        if(orderData.madinahHotel?.pricesSAR && orderData.madinahHotel?.rooms) {
            totalIDR += calc(orderData.madinahHotel.pricesSAR.quad, orderData.madinahHotel.rooms.quad * orderData.madinahHotel.nights, MOCK_EXCHANGE_RATES_BACKEND.SAR_TO_IDR);
            totalIDR += calc(orderData.madinahHotel.pricesSAR.triple, orderData.madinahHotel.rooms.triple * orderData.madinahHotel.nights, MOCK_EXCHANGE_RATES_BACKEND.SAR_TO_IDR);
            totalIDR += calc(orderData.madinahHotel.pricesSAR.double, orderData.madinahHotel.rooms.double * orderData.madinahHotel.nights, MOCK_EXCHANGE_RATES_BACKEND.SAR_TO_IDR);
        }
        if(orderData.makkahHotel?.pricesSAR && orderData.makkahHotel?.rooms) {
            totalIDR += calc(orderData.makkahHotel.pricesSAR.quad, orderData.makkahHotel.rooms.quad * orderData.makkahHotel.nights, MOCK_EXCHANGE_RATES_BACKEND.SAR_TO_IDR);
            totalIDR += calc(orderData.makkahHotel.pricesSAR.triple, orderData.makkahHotel.rooms.triple * orderData.makkahHotel.nights, MOCK_EXCHANGE_RATES_BACKEND.SAR_TO_IDR);
            totalIDR += calc(orderData.makkahHotel.pricesSAR.double, orderData.makkahHotel.rooms.double * orderData.makkahHotel.nights, MOCK_EXCHANGE_RATES_BACKEND.SAR_TO_IDR);
        }
        if (orderData.includeVisa) totalIDR += calc(orderData.visaPricePerPaxUSD, orderData.visaPax, MOCK_EXCHANGE_RATES_BACKEND.USD_TO_IDR);
        if (orderData.includeHandling) totalIDR += calc(orderData.handlingPricePerPaxSAR, orderData.handlingPax, MOCK_EXCHANGE_RATES_BACKEND.SAR_TO_IDR);
        if (orderData.busPriceTotalSAR) totalIDR += orderData.busPriceTotalSAR * MOCK_EXCHANGE_RATES_BACKEND.SAR_TO_IDR;
        
        const finalTotalPrice = Math.round(totalIDR);

        await OrderModel.updatePricingAndData(orderId, orderData, finalTotalPrice);
        
        // If status was REQUEST_CONFIRMATION, move it to TENTATIVE
        if (order.status === OrderStatus.REQUEST_CONFIRMATION) {
            await OrderModel.updateStatus(orderId, OrderStatus.TENTATIVE_CONFIRMATION);
        }

        return this.getOrderById(orderId);
    }
    
    static async addPayment(orderId: string, paymentData: AddPaymentPayload, proofFile?: Express.Multer.File): Promise<OrderWithDetails | null> {
        const paymentId = uuidv4();
        const filePath = proofFile ? proofFile.path : undefined;
        await OrderModel.addPayment(orderId, paymentId, paymentData, filePath, proofFile?.originalname, proofFile?.mimetype);
        return this.getOrderById(orderId);
    }
    
    static async deletePayment(orderId: string, paymentId: string): Promise<OrderWithDetails | null> {
        const paymentToDelete = await OrderModel.findPaymentById(paymentId);
        await OrderModel.deletePayment(paymentId);
        if (paymentToDelete?.payment_proof_file_path) {
            const fullPath = path.join(__dirname, '../../', paymentToDelete.payment_proof_file_path);
            fs.unlink(fullPath, (err) => {
                if (err) {
                    console.error(`Failed to delete payment proof file: ${fullPath}`, err);
                } else {
                    console.log(`Successfully deleted payment proof file: ${fullPath}`);
                }
            });
        }
        return this.getOrderById(orderId);
    }
    
    static async updatePaymentApprovalStatus(orderId: string, paymentId: string, newStatus: "Pending" | "Approved" | "Rejected", approvedByUserId: string, adminActionNotes?: string): Promise<OrderWithDetails | null> {
        await OrderModel.updatePaymentStatus(paymentId, newStatus, approvedByUserId, adminActionNotes);
        return this.getOrderById(orderId);
    }
    
    static async getChatMessagesForOrder(orderId: string) {
        return OrderModel.findChatMessagesByOrderId(orderId);
    }

    static async sendChatMessage(orderId: string, senderName: string, senderId: string, text?: string, file?: Express.Multer.File) {
        const messageId = uuidv4();
        const filePath = file ? file.path : undefined;
        await OrderModel.addChatMessage(messageId, orderId, senderId, senderName, text, filePath, file?.originalname, file?.mimetype);
        return OrderModel.findChatMessageById(messageId);
    }

    static async addHandlingReport(orderId: string, payload: AddHandlingReportPayload): Promise<OrderWithDetails | null> {
        await OrderModel.saveHandlingReport(orderId, payload);
        return this.getOrderById(orderId);
    }
}