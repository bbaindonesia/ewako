

import { VehicleModel } from '../models/VehicleModel';
import { Vehicle, VehicleDbRecord } from '../types/vehicle.types'; // Using backend Vehicle types

// Helper to map DB record (snake_case) to frontend/API Vehicle (camelCase)
const mapDbVehicleToApiVehicle = (dbVehicle: VehicleDbRecord): Vehicle => {
    return {
        id: dbVehicle.id,
        type: dbVehicle.type,
        name: dbVehicle.name,
        plateNumber: dbVehicle.plate_number,
        driverName: dbVehicle.driver_name || undefined,
        driverPhone: dbVehicle.driver_phone || undefined,
        companyName: dbVehicle.company_name || undefined,
    };
};

export class VehicleService {
    static async getAllVehicles(): Promise<Vehicle[]> {
        const dbVehicles = await VehicleModel.findAll();
        return dbVehicles.map(mapDbVehicleToApiVehicle);
    }

    static async getVehicleById(id: string): Promise<Vehicle | null> {
        const dbVehicle = await VehicleModel.findById(id);
        return dbVehicle ? mapDbVehicleToApiVehicle(dbVehicle) : null;
    }

    static async createVehicle(vehicleData: Omit<Vehicle, 'id'>): Promise<Vehicle> {
        // Map camelCase from API/frontend to snake_case for DB model
        const dataForDb: Omit<VehicleDbRecord, 'id' | 'created_at' | 'updated_at'> = {
            type: vehicleData.type,
            name: vehicleData.name,
            plate_number: vehicleData.plateNumber,
            driver_name: vehicleData.driverName,
            driver_phone: vehicleData.driverPhone,
            company_name: vehicleData.companyName,
        };
        const newDbVehicle = await VehicleModel.create(dataForDb);
        if (!newDbVehicle) {
            throw new Error('Gagal membuat kendaraan di service.'); // Should ideally be caught by model
        }
        return mapDbVehicleToApiVehicle(newDbVehicle);
    }

    static async updateVehicle(id: string, updates: Partial<Omit<Vehicle, 'id'>>): Promise<Vehicle | null> {
        const updatesForDb: Partial<Omit<VehicleDbRecord, 'id' | 'created_at' | 'updated_at'>> = {};
        if (updates.type !== undefined) updatesForDb.type = updates.type;
        if (updates.name !== undefined) updatesForDb.name = updates.name;
        if (updates.plateNumber !== undefined) updatesForDb.plate_number = updates.plateNumber;
        if (updates.driverName !== undefined) updatesForDb.driver_name = updates.driverName;
        if (updates.driverPhone !== undefined) updatesForDb.driver_phone = updates.driverPhone;
        if (updates.companyName !== undefined) updatesForDb.company_name = updates.companyName;

        const updatedDbVehicle = await VehicleModel.update(id, updatesForDb);
        return updatedDbVehicle ? mapDbVehicleToApiVehicle(updatedDbVehicle) : null;
    }

    static async deleteVehicle(id: string): Promise<boolean> {
        return VehicleModel.delete(id);
    }
}