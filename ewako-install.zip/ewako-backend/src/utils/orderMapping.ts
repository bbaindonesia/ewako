
import {
    OrderDbRecord,
    OrderWithDetails,
    PackageInfoDbRecord,
    ManifestItemDbRecord,
    PaymentDbRecord,
    HotelInfo as BackendHotelInfo, 
    ServiceType,
    PackageInfoData,
    ManifestItem,
    Payment,
    ChatMessage,
    HandlingReport,
    BusRouteItem, 
    ZiarahRouteItem, 
    ChatParty 
} from '../types/order.types';
import {
    HandlingReportDbBase,
    HandlingArrivalReportDataSpecifics,
    HandlingHotelCheckInReportDataSpecifics,
    HandlingActivityReportDataSpecifics,
    HandlingDepartureReportDataSpecifics,
    HandlingReportJemaahHealth
} from '../types/handling.types';
import pool from '../config/database';

const dateToISO = (date: Date | string | null | undefined): string | undefined => {
    if (!date) return undefined;
    try {
        const d = new Date(date);
        if (isNaN(d.getTime())) return undefined;
        return d.toISOString();
    } catch {
        return undefined;
    }
};

const mapDbPackageHotelToFrontendHotel = (dbPackageInfo: PackageInfoDbRecord, type: 'madinah' | 'makkah'): BackendHotelInfo | undefined => {
    const prefix = type === 'madinah' ? 'madinah_' : 'makkah_';

    const nameKey = `${prefix}hotel_name` as keyof PackageInfoDbRecord;
    const nightsKey = `${prefix}hotel_nights` as keyof PackageInfoDbRecord;
    const checkInKey = `${prefix}hotel_check_in` as keyof PackageInfoDbRecord;
    const checkOutKey = `${prefix}hotel_check_out` as keyof PackageInfoDbRecord;
    const roomsQuadKey = `${prefix}rooms_quad` as keyof PackageInfoDbRecord;
    const roomsTripleKey = `${prefix}rooms_triple` as keyof PackageInfoDbRecord;
    const roomsDoubleKey = `${prefix}rooms_double` as keyof PackageInfoDbRecord;
    const pricesQuadKey = `${prefix}prices_sar_quad` as keyof PackageInfoDbRecord;
    const pricesTripleKey = `${prefix}prices_sar_triple` as keyof PackageInfoDbRecord;
    const pricesDoubleKey = `${prefix}prices_sar_double` as keyof PackageInfoDbRecord;

    if (!dbPackageInfo[nameKey]) return undefined;

    return {
        name: dbPackageInfo[nameKey] as string,
        nights: (dbPackageInfo[nightsKey] as number | null) ?? 0,
        checkIn: dateToISO(dbPackageInfo[checkInKey] as Date | null)?.split('T')[0] || '',
        checkOut: dateToISO(dbPackageInfo[checkOutKey] as Date | null)?.split('T')[0] || '',
        rooms: {
            quad: (dbPackageInfo[roomsQuadKey] as number | null) ?? 0,
            triple: (dbPackageInfo[roomsTripleKey] as number | null) ?? 0,
            double: (dbPackageInfo[roomsDoubleKey] as number | null) ?? 0,
        },
        pricesSAR: {
            quad: dbPackageInfo[pricesQuadKey] !== null ? Number(dbPackageInfo[pricesQuadKey]) : undefined,
            triple: dbPackageInfo[pricesTripleKey] !== null ? Number(dbPackageInfo[pricesTripleKey]) : undefined,
            double: dbPackageInfo[pricesDoubleKey] !== null ? Number(dbPackageInfo[pricesDoubleKey]) : undefined,
        }
    };
};

export const mapOrderDbToOrderWithDetails = async (dbOrder: OrderDbRecord): Promise<OrderWithDetails> => {
    let parsedData: any;
    try {
        parsedData = JSON.parse(dbOrder.data || '{}');
    } catch (e) {
        console.error(`Error parsing order data JSON for order ID ${dbOrder.id}:`, e);
        parsedData = {};
    }

    const [[pkgRows], [manifestRows], [paymentRows], [chatRows], [reportBaseRows]] = await Promise.all([
        pool.query('SELECT * FROM order_package_info WHERE order_id = ?', [dbOrder.id]),
        pool.query('SELECT * FROM order_manifest_items WHERE order_id = ? ORDER BY created_at ASC', [dbOrder.id]),
        pool.query('SELECT * FROM order_payments WHERE order_id = ? ORDER BY payment_date DESC, created_at DESC', [dbOrder.id]),
        pool.query('SELECT * FROM order_chat_history WHERE order_id = ? ORDER BY timestamp ASC', [dbOrder.id]),
        pool.query('SELECT * FROM handling_reports WHERE order_id = ? ORDER BY created_at ASC', [dbOrder.id]),
    ]);

    let packageInfo: PackageInfoData | undefined = undefined;
    const dbPackageInfo = (pkgRows as any[])[0] as PackageInfoDbRecord | undefined;

    if (dbPackageInfo) {
        const [[busRouteRows], [ziarahRouteRows]] = await Promise.all([
            pool.query('SELECT * FROM order_package_bus_routes WHERE package_info_order_id = ? ORDER BY date ASC, created_at ASC', [dbOrder.id]),
            pool.query('SELECT * FROM order_package_ziarah_routes WHERE package_info_order_id = ? ORDER BY tanggal ASC, waktu ASC', [dbOrder.id])
        ]);
        
        const busRoutes: BusRouteItem[] = (busRouteRows as any[]).map((br: any) => ({
            id: br.id,
            date: dateToISO(br.date)?.split('T')[0] || '',
            from: br.from_location,
            to: br.to_location,
            routeVehicleId: br.route_vehicle_id,
            vehicleDetails: br.vehicle_details,
        }));
        
        const ziarahRoutes: ZiarahRouteItem[] = (ziarahRouteRows as any[]).map((zr: any) => ({
            id: zr.id,
            tujuan: zr.tujuan,
            kota: zr.kota,
            tanggal: dateToISO(zr.tanggal)?.split('T')[0] || '',
            waktu: zr.waktu,
            remake: zr.remake,
        }));

        packageInfo = {
            groupCode: dbPackageInfo.group_code ?? undefined,
            ppiuName: dbPackageInfo.ppiu_name ?? '',
            ppiuPhone: dbPackageInfo.ppiu_phone ?? '',
            paxCount: dbPackageInfo.pax_count ?? 0,
            madinahHotelInfo: dbPackageInfo.madinah_hotel_info_legacy ?? undefined,
            makkahHotelInfo: dbPackageInfo.makkah_hotel_info_legacy ?? undefined,
            madinahHotelStructured: mapDbPackageHotelToFrontendHotel(dbPackageInfo, 'madinah'),
            makkahHotelStructured: mapDbPackageHotelToFrontendHotel(dbPackageInfo, 'makkah'),
            busVehicleId: dbPackageInfo.bus_vehicle_id ?? undefined,
            busName: dbPackageInfo.bus_name ?? undefined,
            busVehicleType: dbPackageInfo.bus_vehicle_type ?? undefined,
            busDriverName: dbPackageInfo.bus_driver_name ?? undefined,
            busDriverPhone: dbPackageInfo.bus_driver_phone ?? undefined,
            busSyarikahNumber: dbPackageInfo.bus_syarikah_number ?? undefined,
            busRoutes: busRoutes,
            ziarahRoutes: ziarahRoutes,
            mutowifName: dbPackageInfo.mutowif_name ?? undefined,
            mutowifPhone: dbPackageInfo.mutowif_phone ?? undefined,
            representativeName: dbPackageInfo.representative_name ?? undefined,
            representativePhone: dbPackageInfo.representative_phone ?? undefined,
            ewakoRoyalPhone: dbPackageInfo.ewako_royal_phone ?? undefined,
            airlineName: dbPackageInfo.airline_name ?? undefined,
            airlineCode: dbPackageInfo.airline_code ?? undefined,
            pnrCode: dbPackageInfo.pnr_code ?? undefined,
            arrivalDateTime: dateToISO(dbPackageInfo.arrival_date_time),
            arrivalTerminal: dbPackageInfo.arrival_terminal ?? undefined,
            departureDateTime: dateToISO(dbPackageInfo.departure_date_time),
            departureTerminal: dbPackageInfo.departure_terminal ?? undefined,
            tourLeaderName: dbPackageInfo.tour_leader_name ?? undefined,
            tourLeaderPhone: dbPackageInfo.tour_leader_phone ?? undefined,
            tourGuideName: dbPackageInfo.tour_guide_name ?? undefined,
            tourGuidePhone: dbPackageInfo.tour_guide_phone ?? undefined,
        };
    }
    
    const manifest: ManifestItem[] = (manifestRows as ManifestItemDbRecord[]).map(item => ({
        id: item.id,
        namaJemaah: item.nama_jemaah,
        jenisKelamin: item.jenis_kelamin || '',
        tanggalLahir: dateToISO(item.tanggal_lahir)?.split('T')[0] || '',
        nomorVisa: item.nomor_visa ?? undefined,
        namaDiPaspor: item.nama_di_paspor || '',
        nomorPaspor: item.nomor_paspor || '',
        tanggalTerbitPaspor: dateToISO(item.tanggal_terbit_paspor)?.split('T')[0] || '',
        tanggalExpiredPaspor: dateToISO(item.tanggal_expired_paspor)?.split('T')[0] || '',
        kotaTempatIssuedPaspor: item.kota_tempat_issued_paspor ?? undefined,
        kotaAsalKeberangkatan: item.kota_asal_keberangkatan ?? undefined,
    }));

    const payments: Payment[] = (paymentRows as PaymentDbRecord[]).map(p => ({
        id: p.id,
        orderId: p.order_id,
        userId: p.user_id,
        amount: Number(p.amount),
        paymentDate: dateToISO(p.payment_date)!.split('T')[0],
        paymentType: p.payment_type,
        paymentMethod: p.payment_method,
        notes: p.notes ?? undefined,
        createdAt: dateToISO(p.created_at)!,
        paymentProofFileName: p.payment_proof_file_name ?? undefined,
        paymentProofFileType: p.payment_proof_file_type ?? undefined,
        paymentProofFileDataUrl: p.payment_proof_file_path ? `/uploads/${p.payment_proof_file_path.replace(/\\/g, '/')}` : undefined,
        senderAccountName: p.sender_account_name ?? undefined,
        senderAccountNumber: p.sender_account_number ?? undefined,
        senderBankName: p.sender_bank_name ?? undefined,
        senderTransferMethod: p.sender_transfer_method ?? undefined,
        destinationBankName: p.destination_bank_name ?? undefined,
        destinationAccountNumber: p.destination_account_number ?? undefined,
        paymentGatewayType: p.payment_gateway_type ?? undefined,
        paymentApprovalStatus: p.payment_approval_status,
        approvedAt: dateToISO(p.approved_at),
        rejectedAt: dateToISO(p.rejected_at),
        approvedByUserId: p.approved_by_user_id ?? undefined,
        adminActionNotes: p.admin_action_notes ?? undefined,
    }));

    const chatHistory: ChatMessage[] = (chatRows as any[]).map(msg => ({
        id: msg.id,
        orderId: msg.order_id,
        timestamp: dateToISO(msg.timestamp)!,
        sender: msg.sender_name as ChatParty | string,
        senderId: msg.sender_id,
        text: msg.text_message ?? undefined,
        fileName: msg.file_name ?? undefined,
        fileType: msg.file_type ?? undefined,
        fileDataUrl: msg.file_path ? `/uploads/${msg.file_path.replace(/\\/g, '/')}`: undefined,
        isRead: msg.is_read,
    }));

    const handlingReports: HandlingReport[] = await Promise.all(
        (reportBaseRows as HandlingReportDbBase[]).map(async (baseReport) => {
            let specificData: any = {};
            // Fetch specific data based on report type
            if (baseReport.report_type === 'Arrival') {
                const [[data]] = await pool.query('SELECT * FROM handling_reports_arrival WHERE handling_report_id = ?', [baseReport.id]);
                specificData = data;
            } else if (baseReport.report_type === 'HotelCheckIn') {
                const [[data]] = await pool.query('SELECT * FROM handling_reports_hotel_check_in WHERE handling_report_id = ?', [baseReport.id]);
                specificData = data;
            } else if (baseReport.report_type === 'Activity') {
                const [[data]] = await pool.query('SELECT * FROM handling_reports_activity WHERE handling_report_id = ?', [baseReport.id]);
                specificData = data || {};
                const [tujuanRows] = await pool.query('SELECT tujuan_kegiatan FROM handling_report_activity_tujuan WHERE activity_report_id = ?', [baseReport.id]);
                specificData.tujuanKegiatan = (tujuanRows as any[]).map(t => t.tujuan_kegiatan);
            } else if (baseReport.report_type === 'Departure') {
                const [[data]] = await pool.query('SELECT * FROM handling_reports_departure WHERE handling_report_id = ?', [baseReport.id]);
                specificData = data;
            }
            
            // Attach absensi & health details
            const [absensiRows] = await pool.query('SELECT manifest_item_id, status_kehadiran FROM handling_report_jemaah_absensi WHERE handling_report_id = ?', [baseReport.id]);
            const absensiMap = (absensiRows as any[]).reduce((acc, row) => {
                acc[row.manifest_item_id] = !!row.status_kehadiran;
                return acc;
            }, {});

            const [healthRows] = await pool.query('SELECT * FROM handling_report_jemaah_health WHERE handling_report_id = ?', [baseReport.id]);
            const healthDetails: HandlingReportJemaahHealth[] = (healthRows as any[]).map(row => ({
                id: row.id,
                jemaahId: row.manifest_item_id,
                namaJemaah: row.nama_jemaah_snapshot,
                nomorPaspor: row.nomor_paspor_snapshot,
                keluhan: row.keluhan,
                kotaAsal: row.kota_asal_snapshot ?? undefined,
                nomorVisa: row.nomor_visa_snapshot ?? undefined,
            }));
            
            if (baseReport.report_type === 'Arrival') {
                specificData.absensiJemaah = absensiMap;
                specificData.jemaahSakitDetails = healthDetails;
            } else if (baseReport.report_type === 'Activity') {
                specificData.absensiJemaahKeberangkatan = absensiMap;
                specificData.jemaahSakitDetails = healthDetails;
            } else if (baseReport.report_type === 'Departure') {
                specificData.absensiJemaahCheckout = absensiMap;
                specificData.jemaahSakitDetailsCheckout = healthDetails;
            }
            
            delete specificData.handling_report_id;
            delete specificData.id;

            return {
                id: baseReport.id,
                orderId: baseReport.order_id,
                reportType: baseReport.report_type,
                createdByUserId: baseReport.created_by_user_id,
                petugasPJId: baseReport.petugas_pj_id || '',
                petugasPJName: baseReport.petugas_pj_name || undefined,
                createdAt: dateToISO(baseReport.created_at)!,
                data: specificData,
            };
        })
    );
    
    return {
        id: dbOrder.id,
        userId: dbOrder.user_id,
        serviceType: dbOrder.service_type,
        data: parsedData,
        status: dbOrder.status,
        adminNotes: dbOrder.admin_notes ?? undefined,
        customerConfirmation: dbOrder.customer_confirmation ?? undefined,
        totalPrice: dbOrder.total_price === null ? undefined : Number(dbOrder.total_price),
        createdAt: dateToISO(dbOrder.created_at)!,
        updatedAt: dateToISO(dbOrder.updated_at)!,
        packageInfo,
        manifest,
        payments,
        chatHistory,
        handlingReports,
    };
};
