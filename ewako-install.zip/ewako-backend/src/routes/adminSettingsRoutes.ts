
import { Router } from 'express';
import { AdminSettingsController } from '../controllers/AdminSettingsController';
import { authenticateToken } from '../middlewares/authMiddleware';
import { authorizeRoles } from '../middlewares/authorizeRolesMiddleware';

const router = Router();

// Bank Account Management (Admin only)
router.get(
    '/bank-accounts',
    authenticateToken,
    authorizeRoles(['admin']),
    AdminSettingsController.getBankAccounts
);

router.post(
    '/bank-accounts',
    authenticateToken,
    authorizeRoles(['admin']),
    AdminSettingsController.addBankAccount
);

router.put(
    '/bank-accounts/:accountId',
    authenticateToken,
    authorizeRoles(['admin']),
    AdminSettingsController.updateBankAccount
);

router.delete(
    '/bank-accounts/:accountId',
    authenticateToken,
    authorizeRoles(['admin']),
    AdminSettingsController.deleteBankAccount
);

// Placeholder for other admin settings like Midtrans API Key
router.get(
    '/midtrans-settings', // Example
    authenticateToken,
    authorizeRoles(['admin']),
    (req, res) => res.status(501).json({ message: 'Midtrans settings endpoint not implemented yet.'})
);
router.put(
    '/midtrans-settings', // Example
    authenticateToken,
    authorizeRoles(['admin']),
    (req, res) => res.status(501).json({ message: 'Update Midtrans settings endpoint not implemented yet.'})
);


export default router;