
import { Router } from 'express';
import { VehicleController } from '../controllers/VehicleController';
import { authenticateToken } from '../middlewares/authMiddleware';
import { authorizeRoles } from '../middlewares/authorizeRolesMiddleware';

const router = Router();

// GET all vehicles (public or for authenticated users, depending on app logic)
router.get('/', authenticateToken, VehicleController.getAllVehicles);

// POST create a new vehicle (Admin, Tim Staff)
router.post(
    '/', 
    authenticateToken, 
    authorizeRoles(['admin', 'tim_staff']), 
    VehicleController.createVehicle
);

// GET vehicle by ID
router.get('/:vehicleId', authenticateToken, VehicleController.getVehicleById);

// PUT update vehicle (Admin, Tim Staff)
router.put(
    '/:vehicleId', 
    authenticateToken, 
    authorizeRoles(['admin', 'tim_staff']), 
    VehicleController.updateVehicle
);

// DELETE vehicle (Admin, Tim Staff)
router.delete(
    '/:vehicleId', 
    authenticateToken, 
    authorizeRoles(['admin', 'tim_staff']), 
    VehicleController.deleteVehicle
);

export default router;