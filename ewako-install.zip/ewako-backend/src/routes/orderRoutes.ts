
import express from 'express';
import { OrderController } from '../controllers/OrderController';
import { authenticateToken } from '../middlewares/authMiddleware'; 
import { authorizeRoles } from '../middlewares/authorizeRolesMiddleware';
import { uploadChatFile, uploadPaymentProof } from '../middlewares/uploadMiddleware';

const router = express.Router();

// Create a new order
router.post('/', authenticateToken, OrderController.createOrder);

// Get all orders (admin/staff) or filtered by userId (customer)
router.get('/', authenticateToken, OrderController.getOrders);

// Get a single order by ID
router.get('/:orderId', authenticateToken, OrderController.getOrderById);

// Update order status
router.put('/:orderId/status', authenticateToken, OrderController.updateStatus); // Role logic in controller

// Update order's main data block
router.put('/:orderId/data', authenticateToken, OrderController.updateOrderData); // Role logic in controller

// Update order's package info
router.put('/:orderId/package-info', authenticateToken, authorizeRoles(['admin', 'tim_staff', 'customer']), OrderController.updatePackageInfo);

// Update order's manifest
router.put('/:orderId/manifest', authenticateToken, authorizeRoles(['admin', 'tim_staff', 'customer']), OrderController.updateManifest);

// Admin sets pricing details for an order
router.put('/:orderId/pricing-details', authenticateToken, authorizeRoles(['admin']), OrderController.setPricingDetails);

// --- Payment Routes ---
router.post(
    '/:orderId/payments',
    authenticateToken,
    uploadPaymentProof, // Multer middleware for file upload
    OrderController.addPayment
);

router.delete(
    '/:orderId/payments/:paymentId',
    authenticateToken,
    authorizeRoles(['admin']),
    OrderController.deletePayment
);

router.put(
    '/:orderId/payments/:paymentId/approval',
    authenticateToken,
    authorizeRoles(['admin']),
    OrderController.updatePaymentApproval
);

// --- Chat Routes ---
router.get(
    '/:orderId/chat',
    authenticateToken,
    OrderController.getChatMessages
);

router.post(
    '/:orderId/chat',
    authenticateToken,
    uploadChatFile, // Multer middleware for file upload
    OrderController.sendChatMessage
);

// --- Handling Reports Route ---
router.post(
    '/:orderId/handling-reports',
    authenticateToken, 
    authorizeRoles(['admin', 'tim_staff']), 
    OrderController.addHandlingReport
);

export default router;