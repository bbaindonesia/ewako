
import { Router } from 'express';
import { UserController } from '../controllers/UserController';
import { authenticateToken } from '../middlewares/authMiddleware';
import { authorizeRoles } from '../middlewares/authorizeRolesMiddleware';

const router = Router();

// GET all users (Admin, Tim Staff)
router.get(
    '/', 
    authenticateToken, 
    authorizeRoles(['admin', 'tim_staff']), 
    UserController.getAllUsers
);

// GET user by ID (Admin, Tim Staff, or self)
router.get(
    '/:userId', 
    authenticateToken, 
    UserController.getUserById // Authorization logic handled in controller/service for self-access
);

// PUT update user details (Admin or self)
router.put(
    '/:userId', 
    authenticateToken, 
    UserController.updateUser // Authorization logic handled in controller/service
);

// PUT update user account status (Admin only)
router.put(
    '/:userId/account-status', 
    authenticateToken, 
    authorizeRoles(['admin']), 
    UserController.updateUserAccountStatus
);

export default router;