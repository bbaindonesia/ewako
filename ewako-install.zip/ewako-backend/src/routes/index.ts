
import { Router } from 'express';
import authRoutes from './authRoutes';
import orderRoutes from './orderRoutes'; 
import userRoutes from './userRoutes';
import vehicleRoutes from './vehicleRoutes';
import adminSettingsRoutes from './adminSettingsRoutes';

const router = Router();

// Auth Routes
router.use('/auth', authRoutes);

// Order Routes (including handling reports, payments, chat under orders)
router.use('/orders', orderRoutes);

// User Routes
router.use('/users', userRoutes);

// Vehicle Routes
router.use('/vehicles', vehicleRoutes);

// Admin Settings Routes (Bank Accounts, etc.)
router.use('/admin', adminSettingsRoutes);


// API Root
router.get('/', (req, res) => {
  res.json({ 
    message: 'Ewako Royal Backend API is running!',
    timestamp: new Date().toISOString(),
    implementedRoutes: {
      auth: '/api/auth (Implemented)',
      orders: '/api/orders (Implemented)',
      users: '/api/users (Implemented)',
      vehicles: '/api/vehicles (Implemented)',
      adminSettings: '/api/admin (Implemented for bank-accounts)',
    },
    notes: "This is a dynamic list. Check specific route files for all sub-routes."
  });
});

export default router;