import dotenv from 'dotenv';

dotenv.config();

const ENV = {
  PORT: process.env.PORT || '3002', // Default to 3002 if not set
  DB_HOST: process.env.DB_HOST || 'localhost',
  DB_USER: process.env.DB_USER || 'root',
  DB_PASSWORD: process.env.DB_PASSWORD || '',
  DB_NAME: process.env.DB_NAME || 'ewako_royal_backend_db',
  DB_PORT: parseInt(process.env.DB_PORT || '3306', 10),
  JWT_SECRET: process.env.JWT_SECRET || 'fallback_secret_key',
  JWT_EXPIRES_IN: parseInt(process.env.JWT_EXPIRES_IN || '3600', 10), // 1 hour in seconds
  CORS_ORIGIN: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : ['http://localhost:5173'], // Default for dev
};

if (ENV.JWT_SECRET === 'fallback_secret_key') {
  console.warn("Warning: JWT_SECRET is using a fallback value. Set a strong secret in your .env file for production.");
}
if (!process.env.DB_NAME) {
    console.warn("Warning: DB_NAME is not set in .env. Using default 'ewako_royal_backend_db'.");
}


export default ENV;
