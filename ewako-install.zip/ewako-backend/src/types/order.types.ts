

import { 
    ServiceType, OrderStatus, 
    HotelBookingData as OriginalHotelBookingData, 
    VisaBookingData as OriginalVisaBookingData, 
    HandlingBookingData as OriginalHandlingBookingData, 
    JastipBookingData as OriginalJastipBookingData, 
    PackageInfoData as OriginalPackageInfoData, 
    ManifestItem as OriginalManifestItem, 
    Payment as OriginalPayment, 
    ChatMessage as OriginalChatMessage, 
    HandlingReport as OriginalHandlingReport, 
    HotelInfo as OriginalHotelInfo,
    RoomBooking as OriginalRoomBooking,
    BusRouteItem as OriginalBusRouteItem, // Import for re-export
    ZiarahRouteItem as OriginalZiarahRouteItem, // Import for re-export
    ChatParty as OriginalChatParty, // Import for re-export
    AddPaymentPayload as OriginalAddPaymentPayload,
    AdminManagedBankAccount as OriginalAdminManagedBankAccount
} from './shared.types';

// Export RoomBooking so it can be used by other backend modules if needed
export type RoomBooking = OriginalRoomBooking;

// Define HotelInfo for backend use, mirroring frontend structure but can be extended
export interface HotelInfo extends OriginalHotelInfo {}


// --- ORDER ---
export interface OrderDbRecord {
    id: string;
    user_id: string;
    service_type: ServiceType;
    data: string; // JSON string from DB for HotelBookingData, VisaBookingData etc.
    status: OrderStatus;
    admin_notes?: string | null;
    customer_confirmation?: boolean | null;
    total_price?: number | null; // DECIMAL in DB
    created_at: Date;
    updated_at: Date;
}

// For creating an order
export interface OrderCreationAttributes {
    userId: string;
    serviceType: ServiceType;
    data: OriginalHotelBookingData | OriginalVisaBookingData | OriginalHandlingBookingData | OriginalJastipBookingData;
    status?: OrderStatus; 
    totalPrice?: number;  
}

// For updating order data (original booking data)
export type OrderDataUpdatePayload = Partial<OriginalHotelBookingData | OriginalVisaBookingData | OriginalHandlingBookingData | OriginalJastipBookingData>;


// --- PACKAGE INFO ---
// Matches frontend PackageInfoData for structure, but DB might use snake_case for columns
export interface PackageInfoDbRecord {
    order_id: string;
    group_code?: string | null;
    ppiu_name?: string | null;
    ppiu_phone?: string | null;
    pax_count?: number | null;
    madinah_hotel_info_legacy?: string | null;
    makkah_hotel_info_legacy?: string | null;
    madinah_hotel_name?: string | null;
    madinah_hotel_nights?: number | null;
    madinah_hotel_check_in?: Date | null;
    madinah_hotel_check_out?: Date | null;
    madinah_rooms_quad?: number | null;
    madinah_rooms_triple?: number | null;
    madinah_rooms_double?: number | null;
    madinah_prices_sar_quad?: number | null; // DECIMAL
    madinah_prices_sar_triple?: number | null; // DECIMAL
    madinah_prices_sar_double?: number | null; // DECIMAL
    makkah_hotel_name?: string | null;
    makkah_hotel_nights?: number | null;
    makkah_hotel_check_in?: Date | null;
    makkah_hotel_check_out?: Date | null;
    makkah_rooms_quad?: number | null;
    makkah_rooms_triple?: number | null;
    makkah_rooms_double?: number | null;
    makkah_prices_sar_quad?: number | null; // DECIMAL
    makkah_prices_sar_triple?: number | null; // DECIMAL
    makkah_prices_sar_double?: number | null; // DECIMAL
    bus_vehicle_id?: string | null;
    bus_name?: string | null;
    bus_vehicle_type?: 'Bus' | 'HiAce' | 'SUV' | '' | null;
    bus_driver_name?: string | null;
    bus_driver_phone?: string | null;
    bus_syarikah_number?: string | null;
    mutowif_name?: string | null;
    mutowif_phone?: string | null;
    representative_name?: string | null;
    representative_phone?: string | null;
    ewako_royal_phone?: string | null;
    airline_name?: string | null;
    airline_code?: string | null;
    pnr_code?: string | null;
    arrival_date_time?: Date | null;
    arrival_terminal?: string | null;
    departure_date_time?: Date | null;
    departure_terminal?: string | null;
    tour_leader_name?: string | null;
    tour_leader_phone?: string | null;
    tour_guide_name?: string | null;
    tour_guide_phone?: string | null;
    created_at: Date;
    updated_at: Date;
}

// --- MANIFEST ITEM ---
export interface ManifestItemDbRecord {
    id: string;
    order_id: string;
    nama_jemaah: string;
    jenis_kelamin?: 'Laki-laki' | 'Perempuan' | '' | null;
    tanggal_lahir?: Date | null;
    nomor_visa?: string | null;
    nama_di_paspor?: string | null;
    nomor_paspor?: string | null;
    tanggal_terbit_paspor?: Date | null;
    tanggal_expired_paspor?: Date | null;
    kota_tempat_issued_paspor?: string | null;
    kota_asal_keberangkatan?: string | null;
    created_at: Date;
    updated_at: Date;
}

// --- PAYMENT ---
export interface PaymentDbRecord {
    id: string;
    order_id: string;
    user_id: string;
    amount: number; // DECIMAL
    payment_date: Date;
    payment_type: 'DP' | 'LUNAS' | 'LAINNYA';
    payment_method: 'Transfer' | 'Midtrans VA' | 'Cash' | 'Lainnya';
    notes?: string | null;
    payment_proof_file_name?: string | null;
    payment_proof_file_type?: string | null;
    payment_proof_file_path?: string | null; // Path on server
    sender_account_name?: string | null;
    sender_account_number?: string | null;
    sender_bank_name?: string | null;
    sender_transfer_method?: 'Teller' | 'ATM' | 'MobileBanking' | 'InternetBanking' | '' | null;
    destination_bank_name?: string | null;
    destination_account_number?: string | null;
    payment_gateway_type?: string | null;
    payment_approval_status: 'Pending' | 'Approved' | 'Rejected';
    approved_at?: Date | null;
    rejected_at?: Date | null;
    approved_by_user_id?: string | null;
    admin_action_notes?: string | null;
    created_at: Date;
    updated_at: Date;
}

// --- ADMIN BANK ACCOUNT ---
export interface AdminBankAccountDbRecord {
    id: string;
    bank_name: string;
    bank_code?: string | null;
    account_number: string;
    account_holder_name: string;
    branch_name?: string | null;
    logo_url?: string | null;
    created_at: Date;
    updated_at: Date;
}

// Used by OrderService to structure the full order object for API responses
export interface OrderWithDetails {
    id: string;
    userId: string; // Changed from user_id to userId (camelCase)
    serviceType: ServiceType;
    data: OriginalHotelBookingData | OriginalVisaBookingData | OriginalHandlingBookingData | OriginalJastipBookingData; // Parsed JSON
    status: OrderStatus;
    adminNotes?: string;
    customerConfirmation?: boolean;
    totalPrice?: number; 
    createdAt: string; // ISO string
    updatedAt: string; // ISO string
    packageInfo?: OriginalPackageInfoData; 
    manifest?: OriginalManifestItem[];       
    payments?: OriginalPayment[];          
    chatHistory?: OriginalChatMessage[];   
    handlingReports?: OriginalHandlingReport[]; 
}


// This is the payload structure frontend sends for pricing and some details
export interface AdminPriceDetailsPayload {
    madinahHotelRoomPricesSAR?: { quad?: number; triple?: number; double?: number };
    makkahHotelRoomPricesSAR?: { quad?: number; triple?: number; double?: number };
    visaPricePerPaxUSD?: number;
    handlingPricePerPaxSAR?: number;
    busPriceTotalSAR?: number;
    muasasahName?: string;
    jastipPriceIDR?: number; 
}

// Structure to update order data and potentially calculate total_price
export interface OrderDataForPricingUpdate {
    madinahHotel?: Partial<OriginalHotelInfo>; 
    makkahHotel?: Partial<OriginalHotelInfo>;  
    visaPricePerPaxUSD?: number;
    handlingPricePerPaxSAR?: number;
    busPriceTotalSAR?: number;
    muasasahName?: string;
    jastipPriceIDR?: number;
}

// Re-exporting original frontend types for direct use within backend if preferred,
// or use the Original* aliased versions.
export { 
    ServiceType, OrderStatus, 
    OriginalHotelBookingData as HotelBookingData, 
    OriginalVisaBookingData as VisaBookingData, 
    OriginalHandlingBookingData as HandlingBookingData, 
    OriginalJastipBookingData as JastipBookingData, 
    OriginalPackageInfoData as PackageInfoData, 
    OriginalManifestItem as ManifestItem, 
    OriginalPayment as Payment, 
    OriginalChatMessage as ChatMessage, 
    OriginalHandlingReport as HandlingReport,
    OriginalBusRouteItem as BusRouteItem, // Added re-export
    OriginalZiarahRouteItem as ZiarahRouteItem, // Added re-export
    OriginalChatParty as ChatParty, // Added re-export
    OriginalAddPaymentPayload as AddPaymentPayload,
    OriginalAdminManagedBankAccount as AdminManagedBankAccount
};
