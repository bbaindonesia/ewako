
// Type for API and frontend usage (camelCase)
export interface Vehicle {
  id: string;
  type: 'Bus' | 'HiAce' | 'SUV' | ''; 
  name: string;                         
  plateNumber: string;                  
  driverName?: string;
  driverPhone?: string;                  
  companyName?: string;                  
}

// Type for Database record (snake_case)
export interface VehicleDbRecord {
  id: string;
  type: 'Bus' | 'HiAce' | 'SUV' | '';
  name: string;
  plate_number: string;
  driver_name?: string | null;
  driver_phone?: string | null;
  company_name?: string | null;
  created_at: Date;
  updated_at: Date;
}
