
import { UserPayload } from '../user.types';

// Augment the Express Request interface to include the 'user' property.
declare global {
  namespace Express {
    export interface Request {
      user?: UserPayload;
      file?: Multer.File; // For single file uploads
      files?: Multer.File[] | { [fieldname: string]: Multer.File[] }; // For multiple file uploads
    }
  }
}
