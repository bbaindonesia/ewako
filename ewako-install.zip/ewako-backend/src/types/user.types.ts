// For creating a user - data from frontend/controller
export interface UserCreationAttributes { 
  email: string;
  phone?: string;
  name: string;
  password: string; // Plain password, will be hashed
  ppiuName?: string; 
  address?: string;
}

// Represents a user record from the database (matches SQL schema)
export interface UserDbRecord {
  id: string;
  email: string;
  phone?: string | null; 
  name: string;
  role: 'customer' | 'admin' | 'tim_staff';
  ppiu_name?: string | null; 
  address?: string | null;   
  password_hash?: string; // Made optional, though typically present for active users
  account_status: 'pending_approval' | 'active' | 'suspended'; 
  created_at: Date; 
  updated_at: Date; 
}

export type User = UserDbRecord;


// For JWT payload
export interface UserPayload {
  id: string; 
  email: string;
  role: 'customer' | 'admin' | 'tim_staff';
}

// Data structure for creating a user in the UserModel, matching DB columns
export interface UserDataForModelCreate {
    id: string; 
    name: string;
    email: string;
    phone?: string | null;
    ppiu_name?: string | null; 
    address?: string | null;
    password_hash: string; 
    role: User['role']; 
    account_status: User['account_status']; 
}

export type UserDataForModel = UserDataForModelCreate;

// Type for user object returned by AuthService (camelCased for frontend)
export interface AuthenticatedUser {
  id: string;
  email: string;
  phone?: string;
  name: string;
  role: 'customer' | 'admin' | 'tim_staff';
  ppiuName?: string; 
  address?: string;
  accountStatus: 'pending_approval' | 'active' | 'suspended';
  createdAt: Date; 
  updatedAt: Date; 
}
