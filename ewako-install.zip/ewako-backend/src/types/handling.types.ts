

import { 
    HandlingArrivalReportDataSpecifics, 
    HandlingHotelCheckInReportDataSpecifics, 
    HandlingActivityReportDataSpecifics, 
    HandlingDepartureReportDataSpecifics,
    AddHandlingReportServicePayload, // Use payload from frontend
    HandlingReportJemaahHealth // This is the key import from frontend types
} from './shared.types'; // Re-use frontend specifics directly

// This is the payload structure the frontend will send to the backend
// It's now imported and re-exported for use within the backend.
export type AddHandlingReportPayload = AddHandlingReportServicePayload;


// --- DB Record Types for Handling Reports ---

// Base record in `handling_reports` table
export interface HandlingReportDbBase {
    id: string; // Primary key, UUID
    order_id: string;
    report_type: 'Arrival' | 'HotelCheckIn' | 'Activity' | 'Departure';
    created_by_user_id: string;
    petugas_pj_id?: string | null;
    petugas_pj_name?: string | null;
    created_at: Date;
    updated_at: Date;
}

// Specifics for `handling_reports_arrival`
export interface HandlingArrivalReportDbSpecifics extends HandlingArrivalReportDataSpecifics {
    handling_report_id: string; // Foreign key to handling_reports.id
}

// Specifics for `handling_reports_hotel_check_in`
export interface HandlingHotelCheckInReportDbSpecifics extends HandlingHotelCheckInReportDataSpecifics {
    handling_report_id: string;
}

// Specifics for `handling_reports_activity`
export interface HandlingActivityReportDbSpecifics extends HandlingActivityReportDataSpecifics {
    handling_report_id: string;
}
// For `handling_report_activity_tujuan`
export interface HandlingReportActivityTujuanDbRecord {
    id: string; // PK
    activity_report_id: string; // FK to handling_reports_activity.handling_report_id
    tujuan_kegiatan: string;
}


// Specifics for `handling_reports_departure`
export interface HandlingDepartureReportDbSpecifics extends HandlingDepartureReportDataSpecifics {
    handling_report_id: string;
}

// For `handling_report_jemaah_absensi`
export interface HandlingReportJemaahAbsensiDbRecord {
    id: string; // PK
    handling_report_id: string; // FK to handling_reports.id
    manifest_item_id: string; // FK to order_manifest_items.id
    status_kehadiran: boolean;
    absensi_type: 'Arrival' | 'ActivityDeparture' | 'CheckoutHotel';
}

// For `handling_report_jemaah_health`
// Re-using HandlingReportJemaahHealth from frontend for common fields
// Add a keluhan property to this type as it's expected in `orderMapping.ts`
export interface HandlingReportJemaahHealthDbRecord extends HandlingReportJemaahHealth {
    id: string; // PK, (matches frontend HandlingReportJemaahHealth.id if it had one, else new UUID)
    handling_report_id: string; // FK to handling_reports.id
    manifest_item_id: string; // FK to order_manifest_items.id
    nama_jemaah_snapshot: string;
    nomor_paspor_snapshot: string;
    nomor_visa_snapshot?: string | null;
    kota_asal_snapshot?: string | null;
    // keluhan is inherited from HandlingReportJemaahHealth
    health_detail_context: 'Arrival' | 'Activity' | 'DepartureCheckout';
}

// Re-exporting these specific types for clarity in services/models
// Also ensuring HandlingReportJemaahHealth is re-exported for use in other backend modules.
export type {
    HandlingArrivalReportDataSpecifics, 
    HandlingHotelCheckInReportDataSpecifics, 
    HandlingActivityReportDataSpecifics, 
    HandlingDepartureReportDataSpecifics,
    HandlingReportJemaahHealth // Explicitly re-export
};
