
import { Request, Response, NextFunction } from 'express';
import { OrderService } from '../services/OrderService';
import { 
    OrderCreationAttributes, OrderStatus, AddPaymentPayload, AdminPriceDetailsPayload, ManifestItem 
} from '../types/order.types';
import { AddHandlingReportPayload } from '../types/handling.types';

export class OrderController {
    static async createOrder(req: Request, res: Response, next: NextFunction) {
        try {
            const user = req.user;
            if (!user) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            const orderData: OrderCreationAttributes = { ...req.body, userId: user.id };
            
            if (!orderData.serviceType || !orderData.data) {
                return res.status(400).json({ message: 'Jenis layanan dan data pesanan wajib diisi.'});
            }
            const newOrder = await OrderService.createOrder(orderData);
            return res.status(201).json(newOrder);
        } catch(error) {
            next(error);
        }
    }

    static async getOrders(req: Request, res: Response, next: NextFunction) {
        try {
            const user = req.user;
             if (!user) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            const { userId } = req.query as { userId?: string };

            // Admin/staff can see all, or filter by userId. Customer can only see their own.
            if (user.role === 'customer' && userId && userId !== user.id) {
                return res.status(403).json({ message: 'Akses ditolak.' });
            }

            const orders = await OrderService.getOrders(userId || (user.role === 'customer' ? user.id : undefined));
            return res.status(200).json(orders);
        } catch(error) {
            next(error);
        }
    }
    
    static async getOrderById(req: Request, res: Response, next: NextFunction) {
        try {
            const user = req.user;
            if (!user) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            const { orderId } = req.params as { orderId: string };
            const order = await OrderService.getOrderById(orderId);

            if (!order) {
                return res.status(404).json({ message: 'Pesanan tidak ditemukan.' });
            }

            // Admin/staff can see any order. Customer can only see their own.
            if (user.role === 'customer' && order.userId !== user.id) {
                return res.status(403).json({ message: 'Akses ditolak.' });
            }
            return res.status(200).json(order);
        } catch(error) {
            next(error);
        }
    }

    static async updateStatus(req: Request, res: Response, next: NextFunction) {
        try {
            const user = req.user;
            if (!user) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            const { orderId } = req.params as { orderId: string };
            const { status, customerConfirmation } = req.body as { status: OrderStatus, customerConfirmation?: boolean };
            
            const order = await OrderService.getOrderById(orderId);
            if (!order) {
                return res.status(404).json({ message: "Pesanan tidak ditemukan." });
            }
            
            // Allow only admin/staff to change status, unless it's a customer confirmation
            if (user.role === 'customer' && order.userId === user.id) {
                if (customerConfirmation === undefined) {
                    return res.status(403).json({ message: 'Pelanggan hanya diizinkan untuk mengkonfirmasi pesanan.'});
                }
            } else if (user.role !== 'admin' && user.role !== 'tim_staff') {
                return res.status(403).json({ message: 'Akses ditolak.' });
            }
            
            const updatedOrder = await OrderService.updateOrderStatus(orderId, status, customerConfirmation);
            return res.status(200).json(updatedOrder);
        } catch(error) {
            next(error);
        }
    }
    
    static async updateOrderData(req: Request, res: Response, next: NextFunction) {
        try {
            const user = req.user;
            if (!user) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            const { orderId } = req.params as { orderId: string };
            const data = req.body;
            
             const order = await OrderService.getOrderById(orderId);
            if (!order) {
                return res.status(404).json({ message: "Pesanan tidak ditemukan." });
            }
            if (user.role === 'customer' && order.userId !== user.id) {
                 return res.status(403).json({ message: 'Akses ditolak. Anda hanya bisa mengubah pesanan sendiri.' });
            }
            
            const updatedOrder = await OrderService.updateOrderData(orderId, data);
            return res.status(200).json(updatedOrder);
        } catch (error) {
            next(error);
        }
    }
    
    static async updatePackageInfo(req: Request, res: Response, next: NextFunction) {
        try {
            const { orderId } = req.params as { orderId: string };
            const packageInfo = req.body;
            const updatedOrder = await OrderService.updatePackageInfo(orderId, packageInfo);
            return res.status(200).json(updatedOrder);
        } catch (error) {
            next(error);
        }
    }
    
    static async updateManifest(req: Request, res: Response, next: NextFunction) {
        try {
            const { orderId } = req.params as { orderId: string };
            const manifest: ManifestItem[] = req.body;
            const updatedOrder = await OrderService.updateOrderManifest(orderId, manifest);
            return res.status(200).json(updatedOrder);
        } catch (error) {
            next(error);
        }
    }

    static async setPricingDetails(req: Request, res: Response, next: NextFunction) {
        try {
            const { orderId } = req.params as { orderId: string };
            const details: AdminPriceDetailsPayload = req.body;
            const updatedOrder = await OrderService.adminSetPriceAndDetails(orderId, details);
            return res.status(200).json(updatedOrder);
        } catch (error) {
            next(error);
        }
    }

    static async addPayment(req: Request, res: Response, next: NextFunction) {
        try {
            const user = req.user;
            if (!user) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            const { orderId } = req.params as { orderId: string };
            const paymentDetails: AddPaymentPayload = JSON.parse(req.body.paymentDetails);
            const proofFile = req.file;

            if (user.role === 'customer' && paymentDetails.userId !== user.id) {
                return res.status(403).json({ message: "Akses ditolak. Anda hanya bisa menambahkan pembayaran untuk pesanan Anda." });
            }
            
            const updatedOrder = await OrderService.addPayment(orderId, paymentDetails, proofFile);
            return res.status(201).json(updatedOrder);

        } catch (error) {
            next(error);
        }
    }
    
    static async deletePayment(req: Request, res: Response, next: NextFunction) {
        try {
            const { orderId, paymentId } = req.params as { orderId: string, paymentId: string };
            const updatedOrder = await OrderService.deletePayment(orderId, paymentId);
            return res.status(200).json(updatedOrder);
        } catch (error) {
            next(error);
        }
    }

    static async updatePaymentApproval(req: Request, res: Response, next: NextFunction) {
        try {
            const { orderId, paymentId } = req.params as { orderId: string, paymentId: string };
            const user = req.user;
            if (!user) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            const { newStatus, adminActionNotes } = req.body;

            const updatedOrder = await OrderService.updatePaymentApprovalStatus(orderId, paymentId, newStatus, user.id, adminActionNotes);
            return res.status(200).json(updatedOrder);

        } catch (error) {
            next(error);
        }
    }

    static async getChatMessages(req: Request, res: Response, next: NextFunction) {
        try {
            const { orderId } = req.params as { orderId: string };
            const messages = await OrderService.getChatMessagesForOrder(orderId);
            return res.status(200).json(messages);
        } catch (error) {
            next(error);
        }
    }
    
    static async sendChatMessage(req: Request, res: Response, next: NextFunction) {
        try {
            const user = req.user;
            if (!user) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            const { orderId } = req.params as { orderId: string };
            const { senderName, text } = req.body;
            const chatFile = req.file;
            
            const newMessage = await OrderService.sendChatMessage(orderId, senderName, user.id, text, chatFile);
            return res.status(201).json(newMessage);

        } catch (error) {
            next(error);
        }
    }

    static async addHandlingReport(req: Request, res: Response, next: NextFunction) {
        try {
            const orderId = (req.params as { orderId: string }).orderId; 
            const reportPayloadFromRequest = req.body as Omit<AddHandlingReportPayload, 'createdByUserId'>;

            const user = req.user; 
            if (!user || !user.id) {
                 return res.status(401).json({ message: 'Otentikasi pengguna gagal untuk membuat laporan.' });
            }
            const createdByUserId = user.id;

            if (!reportPayloadFromRequest.reportType || !reportPayloadFromRequest.petugasPJId || !reportPayloadFromRequest.data) {
                return res.status(400).json({ message: 'Jenis laporan, Petugas PJ, dan data laporan wajib diisi.' });
            }

            const payloadForService: AddHandlingReportPayload = {
                ...reportPayloadFromRequest,
                createdByUserId: createdByUserId,
            };

            const updatedOrder = await OrderService.addHandlingReport(orderId, payloadForService);
            return res.status(201).json(updatedOrder);
        } catch (error) {
            next(error);
        }
    }
}
