
import { Request, Response, NextFunction } from 'express';
import { VehicleService } from '../services/VehicleService';
import { Vehicle } from '../types/vehicle.types'; // Use backend Vehicle type

export class VehicleController {
    static async getAllVehicles(req: Request, res: Response, next: NextFunction) {
        try {
            const vehicles = await VehicleService.getAllVehicles();
            return res.status(200).json(vehicles);
        } catch (error) {
            next(error);
        }
    }

    static async getVehicleById(req: Request, res: Response, next: NextFunction) {
        try {
            const { vehicleId } = req.params as { vehicleId: string };
            const vehicle = await VehicleService.getVehicleById(vehicleId);
            if (!vehicle) {
                return res.status(404).json({ message: 'Kendaraan tidak ditemukan.' });
            }
            return res.status(200).json(vehicle);
        } catch (error) {
            next(error);
        }
    }

    static async createVehicle(req: Request, res: Response, next: NextFunction) {
        try {
            const vehicleData = req.body as Omit<Vehicle, 'id'>;
            if (!vehicleData.name || !vehicleData.type || !vehicleData.plateNumber) {
                return res.status(400).json({ message: 'Nama, Tipe, dan Nomor Plat Kendaraan wajib diisi.' });
            }
            const newVehicle = await VehicleService.createVehicle(vehicleData);
            return res.status(201).json(newVehicle);
        } catch (error) {
            if ((error as Error).message.includes('sudah terdaftar')) {
                return res.status(409).json({ message: (error as Error).message });
            } else {
                next(error);
            }
        }
    }

    static async updateVehicle(req: Request, res: Response, next: NextFunction) {
        try {
            const { vehicleId } = req.params as { vehicleId: string };
            const updates = req.body as Partial<Omit<Vehicle, 'id'>>;
            const updatedVehicle = await VehicleService.updateVehicle(vehicleId, updates);
            if (!updatedVehicle) {
                return res.status(404).json({ message: 'Kendaraan tidak ditemukan atau gagal diperbarui.' });
            }
            return res.status(200).json(updatedVehicle);
        } catch (error) {
             if ((error as Error).message.includes('sudah terdaftar')) {
                return res.status(409).json({ message: (error as Error).message });
            } else {
                next(error);
            }
        }
    }

    static async deleteVehicle(req: Request, res: Response, next: NextFunction) {
        try {
            const { vehicleId } = req.params as { vehicleId: string };
            const success = await VehicleService.deleteVehicle(vehicleId);
            if (!success) {
                return res.status(404).json({ message: 'Kendaraan tidak ditemukan atau gagal dihapus.' });
            }
            return res.status(204).send(); // No content on successful deletion
        } catch (error) {
            next(error);
        }
    }
}
