
import { Request, Response, NextFunction } from 'express';
import { AuthService } from '../services/AuthService';
import { UserCreationAttributes, AuthenticatedUser } from '../types/user.types';

export class AuthController {
  static async register(req: Request, res: Response, next: NextFunction) {
    try {
      const { ppiuName, password, name, email, phone, address } = req.body as UserCreationAttributes;

      const userData: UserCreationAttributes = {
        name,
        email,
        phone,
        password,
        ppiuName, 
        address,
      };

      if (!userData.email || !userData.password || !userData.name) {
        return res.status(400).json({ message: 'Nama, Email, dan Sandi wajib diisi.' });
      }
      const newUser: AuthenticatedUser = await AuthService.registerUser(userData);

      return res.status(201).json({ message: 'Registrasi berhasil! Akun Anda menunggu persetujuan Admin.', user: newUser });
    } catch (error: any) {
      if (error.message.includes('sudah terdaftar') || error.message.includes('ID Pengguna sudah ada')) {
        return res.status(409).json({ message: error.message });
      } else {
        next(error);
      }
    }
  }

  static async login(req: Request, res: Response, next: NextFunction) {
    try {
      const { emailOrPhone, password } = req.body as {emailOrPhone: string, password: string};
      if (!emailOrPhone || !password) {
        return res.status(400).json({ message: 'Email/No. HP dan Sandi wajib diisi.' });
      }
      const { token, user } : { token: string; user: AuthenticatedUser } = await AuthService.loginUser(emailOrPhone, password);

      return res.status(200).json({ token, user });
    } catch (error: any) {
        if (error.message.includes('salah') ||
            error.message.includes('menunggu persetujuan') ||
            error.message.includes('ditangguhkan') ||
            error.message.includes('tidak aktif') ||
            error.message.includes('tidak lengkap')) {
            return res.status(401).json({ message: error.message });
        } else {
            next(error);
        }
    }
  }
}
