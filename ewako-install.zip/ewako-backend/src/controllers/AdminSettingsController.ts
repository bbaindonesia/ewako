
import { Request, Response, NextFunction } from 'express';
import { AdminSettingsService } from '../services/AdminSettingsService';
import { AdminManagedBankAccount } from '../types/order.types'; // Re-using the frontend type is fine here, or create a backend specific one

export class AdminSettingsController {
    static async getBankAccounts(req: Request, res: Response, next: NextFunction) {
        try {
            const accounts = await AdminSettingsService.getBankAccounts();
            return res.status(200).json(accounts);
        } catch (error) {
            next(error);
        }
    }

    static async addBankAccount(req: Request, res: Response, next: NextFunction) {
        try {
            const accountData = req.body as Omit<AdminManagedBankAccount, 'id'>;
            if (!accountData.bankName || !accountData.accountNumber || !accountData.accountHolderName) {
                return res.status(400).json({ message: 'Nama Bank, Nomor Rekening, dan Atas Nama wajib diisi.' });
            }
            const newAccount = await AdminSettingsService.addBankAccount(accountData);
            return res.status(201).json(newAccount);
        } catch (error) {
            next(error);
        }
    }

    static async updateBankAccount(req: Request, res: Response, next: NextFunction) {
        try {
            const { accountId } = req.params as { accountId: string };
            const updates = req.body as Partial<Omit<AdminManagedBankAccount, 'id'>>;
            const updatedAccount = await AdminSettingsService.updateBankAccount(accountId, updates);
            if (!updatedAccount) {
                return res.status(404).json({ message: 'Rekening bank tidak ditemukan atau gagal diperbarui.' });
            }
            return res.status(200).json(updatedAccount);
        } catch (error) {
            next(error);
        }
    }

    static async deleteBankAccount(req: Request, res: Response, next: NextFunction) {
        try {
            const { accountId } = req.params as { accountId: string };
            const success = await AdminSettingsService.deleteBankAccount(accountId);
            if (!success) {
                return res.status(404).json({ message: 'Rekening bank tidak ditemukan atau gagal dihapus.' });
            }
            return res.status(204).send(); // No content
        } catch (error) {
            next(error);
        }
    }
}
