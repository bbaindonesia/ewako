
import { Request, Response, NextFunction } from 'express';
import { UserService } from '../services/UserService';
import { User as BackendUserType, AuthenticatedUser } from '../types/user.types'; 

export class UserController {
    static async getAllUsers(req: Request, res: Response, next: NextFunction) {
        try {
            const roleFilter = req.query.role as BackendUserType['role'] | BackendUserType['role'][] | undefined;
            const users = await UserService.getAllUsers(roleFilter);
            return res.status(200).json(users);
        } catch (error) {
            next(error);
        }
    }

    static async getUserById(req: Request, res: Response, next: NextFunction) {
        try {
            const { userId } = req.params as { userId: string };
            const requestingUser = req.user;

            if (!requestingUser) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }

            const user = await UserService.getUserById(userId);
            if (!user) {
                return res.status(404).json({ message: 'Pengguna tidak ditemukan.' });
            }

            // Allow admin/tim_staff to fetch any user, or user to fetch self
            if (requestingUser.role === 'admin' || requestingUser.role === 'tim_staff' || requestingUser.id === userId) {
                return res.status(200).json(user);
            } else {
                return res.status(403).json({ message: 'Akses ditolak.' });
            }
        } catch (error) {
            next(error);
        }
    }

    static async updateUser(req: Request, res: Response, next: NextFunction) {
        try {
            const { userId } = req.params as { userId: string };
            const updates = req.body as Partial<Omit<AuthenticatedUser, 'id' | 'role' | 'accountStatus' | 'password' | 'createdAt' | 'updatedAt'>>;
            const requestingUser = req.user;

            if (!requestingUser) {
                return res.status(401).json({ message: 'Otentikasi pengguna gagal.' });
            }
            if (requestingUser.role !== 'admin' && requestingUser.id !== userId) {
                return res.status(403).json({ message: 'Akses ditolak. Anda hanya dapat memperbarui profil sendiri.' });
            }
            
            const updatedUser = await UserService.updateUser(userId, updates);
            if (!updatedUser) {
                return res.status(404).json({ message: 'Pengguna tidak ditemukan atau gagal diperbarui.' });
            }
            return res.status(200).json(updatedUser);
        } catch (error) {
            next(error);
        }
    }

    static async updateUserAccountStatus(req: Request, res: Response, next: NextFunction) {
        try {
            const { userId } = req.params as { userId: string };
            const { accountStatus } = req.body as { accountStatus: BackendUserType['account_status'] };

            if (!accountStatus || !['pending_approval', 'active', 'suspended'].includes(accountStatus)) {
                return res.status(400).json({ message: 'Status akun tidak valid.' });
            }

            const updatedUser = await UserService.updateUserAccountStatus(userId, accountStatus);
            if (!updatedUser) {
                return res.status(404).json({ message: 'Pengguna tidak ditemukan atau gagal memperbarui status akun.' });
            }
            return res.status(200).json(updatedUser);
        } catch (error) {
            next(error);
        }
    }
}
