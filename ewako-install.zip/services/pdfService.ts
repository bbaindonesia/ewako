
import jsPDF, { TextOptionsLight } from 'jspdf'; 
import autoTable, { CellHookData, ColumnInput, RowInput, Styles } from 'jspdf-autotable';
import { Order, OrderStatus, ServiceType, HotelBookingData, VisaBookingData, HandlingBookingData, JastipBookingData, PackageInfoData, HotelInfo, RoomBooking, ManifestItem, HandlingReport, HandlingArrivalReportData, HandlingHotelCheckInReportData, HandlingActivityReportData, HandlingDepartureReportData, HandlingReportJemaahHealth, ZiarahRouteItem } from '../types';
import { APP_NAME, ADMIN_WHATSAPP_NUMBER, DEFAULT_SUPPORT_PHONE, DEFAULT_SUPPORT_EMAIL } from '../constants'; 
import { formatCurrency, convertToIDR, MOCK_EXCHANGE_RATES } from './currencyService';


const PDF_PAGE_WIDTH = 210;
const PDF_PAGE_HEIGHT = 297;
const PDF_MARGIN = 10;
const PDF_CONTENT_WIDTH = PDF_PAGE_WIDTH - 2 * PDF_MARGIN;

const formatDateForPdf = (dateString?: string): string => {
  if (!dateString) return 'N/A';
  const date = new Date(dateString.split('T')[0]); 
  if (isNaN(date.getTime())) return 'N/A';
  const day = String(date.getDate()).padStart(2, '0');
  const month = date.toLocaleDateString('id-ID', { month: 'short' }).replace('.', ''); 
  const year = date.getFullYear();
  return `${day}.${month}.${year}`;
};

const formatFullDateForPdf = (dateString?: string): string => {
  if (!dateString) return 'N/A';
  const date = new Date(dateString.split('T')[0]);
  if (isNaN(date.getTime())) return 'N/A';
  return date.toLocaleDateString('id-ID', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });
};

const formatFullDateTimeForPdf = (dateTimeString?: string): string => {
  if (!dateTimeString) return 'N/A';
  const date = new Date(dateTimeString);
  if (isNaN(date.getTime())) return 'N/A';
  return date.toLocaleString('id-ID', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit', timeZoneName: 'short'
  }).replace(/\./g, ':');
};


const formatTimeForPdf = (dateTimeStringOrTime: string | undefined): string => {
    if (!dateTimeStringOrTime) return 'N/A';
    if (dateTimeStringOrTime.includes('T')) {
        const date = new Date(dateTimeStringOrTime);
        if (isNaN(date.getTime())) return 'N/A';
        return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', hour12: false }).replace(/\./g, ':');
    }
    return dateTimeStringOrTime;
};

const getDayNameFromDateForPdf = (dateString?: string): string => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString.split('T')[0]);
    if (isNaN(date.getTime())) return 'N/A';
    return date.toLocaleDateString('en-US', { weekday: 'long' }).toUpperCase();
};


export const generatePackageInfoPdf = (order: Order): void => {
  const doc = new jsPDF();
  const packageInfo = order.packageInfo;
  const orderData = order.data; 

  if (!packageInfo) {
    doc.text("Informasi Paket tidak tersedia.", PDF_MARGIN, PDF_MARGIN + 10);
    doc.save(`package_info_error_${order.id.substring(0,8)}.pdf`);
    return;
  }

  let yPos = PDF_MARGIN;

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 0, 0); 
  doc.text("ARRIVAL INFORMATION FORM", PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 8; 

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0); 

  const redColor: [number, number, number] = [255, 0, 0];
  const yellowColor: [number, number, number] = [255, 255, 0]; 
  const whiteColor: [number, number, number] = [255, 255, 255];
  const blackColor: [number, number, number] = [0, 0, 0];

  const commonStyles: Partial<Styles> = {
    lineWidth: 0.1,
    lineColor: blackColor,
    fontSize: 7, 
    cellPadding: 1.5, 
  };

  const headStylesRed: Partial<Styles> = {
    fillColor: redColor,
    textColor: whiteColor,
    fontStyle: 'bold' as const, 
    halign: 'center' as const,
    valign: 'middle' as const,
  };
  
  const dataStylesWhiteLeft: Partial<Styles> = { 
    fillColor: whiteColor,
    textColor: blackColor,
    halign: 'left' as const,
    valign: 'middle' as const,
  };
   const dataStylesWhiteCenter: Partial<Styles> = { 
    fillColor: whiteColor,
    textColor: blackColor,
    halign: 'center' as const,
    valign: 'middle' as const,
  };
  const dataStylesYellowCenter: Partial<Styles> = { 
    fillColor: yellowColor,
    textColor: blackColor,
    halign: 'center' as const,
    valign: 'middle' as const,
  };
  const dataStylesYellowLeft: Partial<Styles> = {
    fillColor: yellowColor,
    textColor: blackColor,
    halign: 'left' as const,
    valign: 'middle' as const,
  };

  const getPpiuNameFromOrderData = (data: Order['data'], serviceType: ServiceType ): string | undefined => {
    if (serviceType === ServiceType.HOTEL || serviceType === ServiceType.VISA || serviceType === ServiceType.HANDLING) {
      return (data as HotelBookingData | VisaBookingData | HandlingBookingData).ppiuName;
    }
    return undefined;
  }
  const ppiuNameFromData = getPpiuNameFromOrderData(orderData, order.serviceType);


  autoTable(doc, {
    startY: yPos,
    head: [
      [
        { content: 'GROUP NAME', styles: headStylesRed },
        { content: packageInfo.ppiuName || ppiuNameFromData || (orderData as any).customerName || 'N/A', colSpan: 3, styles: dataStylesWhiteLeft },
        { content: 'GROUP CODE', styles: headStylesRed },
        { content: packageInfo.groupCode || 'N/A', styles: dataStylesWhiteCenter },
      ],
      [
        { content: 'AGEN / TOUR LEADER', styles: headStylesRed },
        { content: packageInfo.tourLeaderName || (orderData as any)?.customerName || 'N/A', colSpan: 3, styles: dataStylesWhiteLeft },
        { content: 'MUTAWIF NAME', styles: headStylesRed },
        { content: packageInfo.mutowifName || 'N/A', styles: dataStylesWhiteLeft },
      ],
      [
        { content: 'CONTACT NO', styles: headStylesRed },
        { content: packageInfo.tourLeaderPhone || (orderData as any)?.phone || 'N/A', colSpan: 3, styles: dataStylesWhiteCenter },
        { content: 'CONTACT NO', styles: headStylesRed },
        { content: packageInfo.mutowifPhone || 'N/A', styles: dataStylesWhiteCenter },
      ],
      [
        { content: 'TOTAL PAX', styles: headStylesRed },
        { content: `${packageInfo.paxCount || 0} pax`, colSpan: 5, styles: dataStylesWhiteCenter },
      ],
    ],
    theme: 'grid',
    styles: commonStyles,
    columnStyles: { 
        0: { cellWidth: 38 }, 
        1: { cellWidth: 30 }, 
        2: { cellWidth: 30 }, 
        3: { cellWidth: 30 }, 
        4: { cellWidth: 25 }, 
        5: { cellWidth: 37 }, 
    },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 4; 

  autoTable(doc, {
    startY: yPos,
    head: [
      [
        { content: '', styles: { ...headStylesRed, cellWidth: 25, fillColor: whiteColor, lineColor: whiteColor } as Partial<Styles> }, 
        { content: 'DATE', styles: headStylesRed },
        { content: 'FLIGHT NO', styles: headStylesRed },
        { content: 'FROM', styles: headStylesRed },
        { content: 'TO', styles: headStylesRed },
        { content: 'ETD', styles: headStylesRed },
        { content: 'ETA', styles: headStylesRed },
      ]
    ],
    body: [ 
      [ 
        { content: 'ARRIVAL', styles: { ...headStylesRed, halign:'left' as const } }, 
        { content: formatDateForPdf(packageInfo.arrivalDateTime), styles: dataStylesYellowCenter },
        { content: `${packageInfo.airlineCode || 'N/A'} ${packageInfo.pnrCode ? '/ '+packageInfo.pnrCode : ''}`.trim(), styles: dataStylesYellowCenter },
        { content: 'CGK (Jakarta)', styles: dataStylesYellowCenter }, 
        { content: 'JEDD', styles: dataStylesYellowCenter },          
        { content: '12.00', styles: dataStylesYellowCenter },         
        { content: formatTimeForPdf(packageInfo.arrivalDateTime), styles: dataStylesYellowCenter }, 
      ],
      [ 
        { content: 'DEPARTURE', styles: { ...headStylesRed, halign:'left' as const } }, 
        { content: formatDateForPdf(packageInfo.departureDateTime), styles: dataStylesYellowCenter },
        { content: `${packageInfo.airlineCode || 'N/A'} ${packageInfo.pnrCode ? '/ '+packageInfo.pnrCode : ''}`.trim(), styles: dataStylesYellowCenter }, 
        { content: 'JED', styles: dataStylesYellowCenter },          
        { content: 'CGK', styles: dataStylesYellowCenter },          
        { content: formatTimeForPdf(packageInfo.departureDateTime), styles: dataStylesYellowCenter }, 
        { content: '17.00', styles: dataStylesYellowCenter },         
      ]
    ],
    theme: 'grid',
    styles: commonStyles,
    columnStyles: { 
        0: { cellWidth: 25, fontStyle: 'bold' as const }, 
        1: { cellWidth: 25 }, 
        2: { cellWidth: 30 }, 
        3: { cellWidth: 25 }, 
        4: { cellWidth: 25 }, 
        5: { cellWidth: 25 }, 
        6: { cellWidth: 25 }, 
    },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 4;

  autoTable(doc, {
    startY: yPos,
    head: [[{ content: 'DETAIL MASKAPAI (KEDATANGAN)', colSpan: 2, styles: headStylesRed }]],
    body: [
        ['Nama Maskapai:', packageInfo.airlineName || 'N/A'],
        ['Kode Penerbangan:', `${packageInfo.airlineCode || 'N/A'} ${packageInfo.pnrCode ? '/ '+packageInfo.pnrCode : ''}`.trim()],
        ['Tgl. Keberangkatan (Take Off):', formatDateForPdf(packageInfo.arrivalDateTime)],
        ['Start From:', 'CGK (Jakarta)'], 
        ['To:', 'JEDD'], 
        ['ETD (Waktu Take Off):', '12.00'], 
        ['ETA (Waktu Landing):', formatTimeForPdf(packageInfo.arrivalDateTime)], 
    ],
    theme: 'grid',
    styles: { ...commonStyles, fontSize: 8, cellPadding: 2 },
    headStyles: { ...headStylesRed, halign: 'left' as const, fontSize: 9 },
    columnStyles: {
        0: { fontStyle: 'bold' as const, cellWidth: 60, halign: 'left' as const },
        1: { halign: 'left' as const }
    },
    alternateRowStyles: { fillColor: yellowColor },
    bodyStyles: {textColor: blackColor, halign: 'left' as const, valign: 'middle' as const },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 4;

  const getRoomDetailsString = (hotel?: HotelInfo): string => {
    if (!hotel || !hotel.rooms) return 'N/A';
    const parts: string[] = [];
    if (hotel.rooms.quad > 0) parts.push(`Quad: ${hotel.rooms.quad}`);
    if (hotel.rooms.triple > 0) parts.push(`Triple: ${hotel.rooms.triple}`);
    if (hotel.rooms.double > 0) parts.push(`Double: ${hotel.rooms.double}`);
    return parts.length > 0 ? parts.join(' | ') : 'Detail kamar tidak tersedia';
  };
  
  autoTable(doc, {
    startY: yPos,
    head: [ 
      [
        { content: 'HOTEL MADINAH', rowSpan: 4, styles: { ...headStylesRed, valign: 'middle' as const } }, 
        { content: 'NAME', styles: headStylesRed },
        { content: packageInfo.madinahHotelStructured?.name || 'N/A', styles: dataStylesYellowLeft, colSpan: 2 },
        { content: 'CHECK IN', styles: headStylesRed },
        { content: formatDateForPdf(packageInfo.madinahHotelStructured?.checkIn), styles: dataStylesYellowCenter },
      ],
      [ 
        { content: 'ROOMS', styles: headStylesRed },
        { content: getRoomDetailsString(packageInfo.madinahHotelStructured), styles: dataStylesYellowLeft, colSpan: 4 },
      ],
      [
        { content: 'BOOKING BY', styles: headStylesRed },
        { content: 'EWAKO ROYAL GROUP', styles: dataStylesYellowLeft, colSpan: 2 },
        { content: 'CHECK OUT', styles: headStylesRed },
        { content: formatDateForPdf(packageInfo.madinahHotelStructured?.checkOut), styles: dataStylesYellowCenter },
      ],
      [
        { content: 'CONTACT NO', styles: headStylesRed },
        { content: ADMIN_WHATSAPP_NUMBER, styles: dataStylesYellowCenter, colSpan: 4 }, 
      ]
    ],
    theme: 'grid',
    styles: commonStyles,
    columnStyles: { 
        0: { cellWidth: 35 }, 1: { cellWidth: 30 }, 2: { cellWidth: 45 }, 
        3: { cellWidth: 20 }, 4: { cellWidth: 25 }, 5: { cellWidth: 35 }, 
    },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 4;

  autoTable(doc, {
    startY: yPos,
    head: [
      [
        { content: 'HOTEL MAKKAH', rowSpan: 4, styles: { ...headStylesRed, valign: 'middle' as const } }, 
        { content: 'NAME', styles: headStylesRed },
        { content: packageInfo.makkahHotelStructured?.name || 'N/A', styles: dataStylesYellowLeft, colSpan: 2 },
        { content: 'CHECK IN', styles: headStylesRed },
        { content: formatDateForPdf(packageInfo.makkahHotelStructured?.checkIn), styles: dataStylesYellowCenter },
      ],
      [ 
        { content: 'ROOMS', styles: headStylesRed },
        { content: getRoomDetailsString(packageInfo.makkahHotelStructured), styles: dataStylesYellowLeft, colSpan: 4 },
      ],
      [
        { content: 'BOOKING BY', styles: headStylesRed },
        { content: 'EWAKO ROYAL GROUP', styles: dataStylesYellowLeft, colSpan: 2 },
        { content: 'CHECK OUT', styles: headStylesRed },
        { content: formatDateForPdf(packageInfo.makkahHotelStructured?.checkOut), styles: dataStylesYellowCenter },
      ],
      [
        { content: 'CONTACT NO', styles: headStylesRed },
        { content: ADMIN_WHATSAPP_NUMBER, styles: dataStylesYellowCenter, colSpan: 4 },
      ]
    ],
    theme: 'grid',
    styles: commonStyles,
    columnStyles: { 
        0: { cellWidth: 35 }, 1: { cellWidth: 30 }, 2: { cellWidth: 45 }, 
        3: { cellWidth: 20 }, 4: { cellWidth: 25 }, 5: { cellWidth: 35 }, 
    },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 4;

  const ziarahBody: RowInput[] = (packageInfo.ziarahRoutes && packageInfo.ziarahRoutes.length > 0) 
    ? packageInfo.ziarahRoutes.map(route => ([
        { content: route.kota || 'N/A', styles: dataStylesYellowLeft },
        { content: getDayNameFromDateForPdf(route.tanggal), styles: dataStylesYellowCenter },
        { content: formatDateForPdf(route.tanggal), styles: dataStylesYellowCenter },
        { content: formatTimeForPdf(route.waktu), styles: dataStylesYellowCenter },
        { content: route.tujuan || route.remake || 'N/A', styles: dataStylesYellowLeft },
      ]))
    : [
        [{ content: 'Data ziarah tidak tersedia', colSpan: 5, styles: { ...dataStylesYellowCenter, fontStyle:'italic' as const } }]
      ];

  autoTable(doc, {
    startY: yPos,
    head: [[
        { content: 'ZIARAH', styles: headStylesRed },
        { content: 'DAY', styles: headStylesRed },
        { content: 'DATE', styles: headStylesRed },
        { content: 'TIME', styles: headStylesRed },
        { content: 'REMAKE', styles: headStylesRed },
    ]],
    body: ziarahBody,
    theme: 'grid',
    styles: commonStyles,
    columnStyles: { 
        0: { cellWidth: 35 }, 1: { cellWidth: 30 }, 2: { cellWidth: 30 }, 
        3: { cellWidth: 30 }, 4: { cellWidth: 'auto' }, 
    },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 4;

  const busMark = packageInfo.busVehicleType === 'Bus' ? 'V' : '';
  const hiaceMark = packageInfo.busVehicleType === 'HiAce' ? 'V' : '';
  const suvMark = packageInfo.busVehicleType === 'SUV' ? 'V' : '';

  autoTable(doc, {
    startY: yPos,
    head: [ 
        [
            { content: 'TRANSPORT', rowSpan: 3, styles: { ...headStylesRed, valign:'middle' as const } },
            { content: 'BUS', styles: headStylesRed }, { content: 'COSTER', styles: headStylesRed }, 
            { content: 'VAN', styles: headStylesRed }, { content: 'GMC', styles: headStylesRed },   
        ],
        [ 
            { content: busMark, styles: dataStylesWhiteCenter }, { content: '', styles: dataStylesWhiteCenter }, 
            { content: hiaceMark, styles: dataStylesWhiteCenter }, { content: suvMark, styles: dataStylesWhiteCenter },   
        ],
        [ 
           { content: 'COMPANY NAME', styles: headStylesRed },
           { content: packageInfo.busSyarikahNumber || ppiuNameFromData || 'N/A', colSpan: 4, styles: dataStylesWhiteLeft },
        ]
    ],
    body: [ 
        [
            { content: '', styles: {fillColor: whiteColor, lineColor: whiteColor} as Partial<Styles> }, 
            { content: 'BOOKING BY', styles: headStylesRed },
            { content: packageInfo.mutowifName || packageInfo.tourLeaderName || 'Admin Ewako', colSpan: 1, styles: dataStylesWhiteLeft }, 
            { content: 'CONTACT NO', styles: headStylesRed },
            { content: ADMIN_WHATSAPP_NUMBER, colSpan: 1, styles: dataStylesWhiteCenter }, 
        ]
    ],
    theme: 'grid',
    styles: commonStyles,
    columnStyles: { 
        0: { cellWidth: 30 },    
        1: { cellWidth: 38 },    
        2: { cellWidth: 38 },    
        3: { cellWidth: 38 },    
        4: { cellWidth: 38 },    
    },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });

  doc.save(`Arrival_Information_${packageInfo.groupCode || order.id.substring(0,8)}.pdf`);
};

export const generateOrderRequestPdf = (order: Order): void => {
  const doc = new jsPDF();
  let yPos = PDF_MARGIN;
  
  const customerData = order.data;

  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text("Surat Permintaan Pesanan", PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 6;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(APP_NAME, PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 10;

  const basicInfoBody: RowInput[] = [
    ["ID Pesanan:", order.id.substring(0,15) + (order.id.length > 15 ? '...' : '')],
    ["Tanggal Pesanan:", formatFullDateForPdf(order.createdAt)],
    ["Jenis Layanan:", order.serviceType],
    ["Status Pesanan:", order.status],
  ];
  autoTable(doc, {
    startY: yPos,
    body: basicInfoBody,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1.5 },
    columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 40 } },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 6;

  let alamatValue = 'N/A';
  if (order.serviceType === ServiceType.JASTIP) {
    alamatValue = (order.data as JastipBookingData).deliveryAddress || 'N/A';
  } else if ('address' in order.data && (order.data as any).address) {
    alamatValue = (order.data as any).address || 'N/A';
  }

  let ppiuNameValue = '-';
  if (order.serviceType === ServiceType.HOTEL || order.serviceType === ServiceType.VISA || order.serviceType === ServiceType.HANDLING) {
    ppiuNameValue = (order.data as HotelBookingData | VisaBookingData | HandlingBookingData).ppiuName || '-';
  }


  const customerInfoBody: RowInput[] = [
    ["Nama Pemesan:", String((customerData as any).customerName || 'N/A')],
    ["PPIU/PIHK:", ppiuNameValue],
    ["No. Handphone:", String((customerData as any).phone || 'N/A')],
    ["Alamat:", String(alamatValue)],
  ];
  autoTable(doc, {
    startY: yPos,
    head: [['Informasi Pemesan']],
    body: customerInfoBody,
    theme: 'striped',
    headStyles: { fillColor: [220, 220, 220], textColor: [0,0,0], fontStyle: 'bold' as const, fontSize: 10 },
    styles: { fontSize: 9, cellPadding: 1.5 },
    columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 40 } },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 8;

  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text("Rincian Pesanan:", PDF_MARGIN, yPos);
  yPos += 6;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');

  const serviceDetailsBody: RowInput[] = [];

  if (order.serviceType === ServiceType.HOTEL) {
    const hotelData = order.data as HotelBookingData;
    if (hotelData.madinahHotel && hotelData.madinahHotel.name) {
      serviceDetailsBody.push([{ content: "Hotel Madinah", colSpan: 2, styles: { fontStyle: 'bold' as const, fillColor: [230,230,230] } }]);
      serviceDetailsBody.push(["Nama Hotel:", hotelData.madinahHotel.name]);
      serviceDetailsBody.push(["Check-in:", formatFullDateForPdf(hotelData.madinahHotel.checkIn)]);
      serviceDetailsBody.push(["Check-out:", formatFullDateForPdf(hotelData.madinahHotel.checkOut)]);
      serviceDetailsBody.push(["Durasi:", `${hotelData.madinahHotel.nights} malam`]);
      serviceDetailsBody.push(["Kamar Quad:", hotelData.madinahHotel.rooms.quad.toString()]);
      serviceDetailsBody.push(["Kamar Triple:", hotelData.madinahHotel.rooms.triple.toString()]);
      serviceDetailsBody.push(["Kamar Double:", hotelData.madinahHotel.rooms.double.toString()]);
    }
    if (hotelData.makkahHotel && hotelData.makkahHotel.name) {
      serviceDetailsBody.push([{ content: "Hotel Mekah", colSpan: 2, styles: { fontStyle: 'bold' as const, fillColor: [230,230,230] } }]);
      serviceDetailsBody.push(["Nama Hotel:", hotelData.makkahHotel.name]);
      serviceDetailsBody.push(["Check-in:", formatFullDateForPdf(hotelData.makkahHotel.checkIn)]);
      serviceDetailsBody.push(["Check-out:", formatFullDateForPdf(hotelData.makkahHotel.checkOut)]);
      serviceDetailsBody.push(["Durasi:", `${hotelData.makkahHotel.nights} malam`]);
      serviceDetailsBody.push(["Kamar Quad:", hotelData.makkahHotel.rooms.quad.toString()]);
      serviceDetailsBody.push(["Kamar Triple:", hotelData.makkahHotel.rooms.triple.toString()]);
      serviceDetailsBody.push(["Kamar Double:", hotelData.makkahHotel.rooms.double.toString()]);
    }
    serviceDetailsBody.push([{ content: "Layanan Tambahan", colSpan: 2, styles: { fontStyle: 'bold' as const, fillColor: [230,230,230] } }]);
    serviceDetailsBody.push(["Handling Bandara:", hotelData.includeHandling ? `Ya (${hotelData.handlingPax || 0} pax)` : "Tidak"]);
    serviceDetailsBody.push(["Visa:", hotelData.includeVisa ? `Ya (${hotelData.visaPax || 0} pax)` : "Tidak"]);
    if (hotelData.includeVisa) {
      serviceDetailsBody.push(["  Jenis Kendaraan (Visa):", hotelData.visaVehicleType || "-"]);
      serviceDetailsBody.push(["  Nama Maskapai (Visa):", hotelData.visaAirlineName || "-"]);
      serviceDetailsBody.push(["  Tgl Kedatangan (Visa):", formatFullDateTimeForPdf(hotelData.visaArrivalDate)]);
      serviceDetailsBody.push(["  Tgl Kepulangan (Visa):", formatFullDateTimeForPdf(hotelData.visaDepartureDate)]);
      serviceDetailsBody.push(["  Nama Muasasah:", hotelData.muasasahName || "-"]);
    }
  } else if (order.serviceType === ServiceType.VISA) {
    const visaData = order.data as VisaBookingData;
    serviceDetailsBody.push(["Jumlah Jemaah:", visaData.pax.toString()]);
    serviceDetailsBody.push(["Jenis Kendaraan:", visaData.vehicleType || "-"]);
    serviceDetailsBody.push(["Nama Muasasah:", visaData.muasasahName || "-"]);
  } else if (order.serviceType === ServiceType.HANDLING) {
    const handlingData = order.data as HandlingBookingData;
    serviceDetailsBody.push(["Jumlah Jemaah:", handlingData.pax.toString()]);
    serviceDetailsBody.push(["Include Mutowif:", handlingData.includeMutowif ? `Ya (${handlingData.mutowifName || 'Belum Dipilih'})` : "Tidak"]);
  } else if (order.serviceType === ServiceType.JASTIP) {
    const jastipData = order.data as JastipBookingData;
    serviceDetailsBody.push(["Jenis Titipan:", jastipData.itemType]);
    serviceDetailsBody.push(["Jumlah & Unit:", `${jastipData.quantity} ${jastipData.unit}`]);
    serviceDetailsBody.push(["Alamat Pengiriman:", jastipData.deliveryAddress]);
    serviceDetailsBody.push(["Catatan Untuk Pengantar:", jastipData.notes || "-"]);
  }

  if (serviceDetailsBody.length > 0) {
    autoTable(doc, {
      startY: yPos,
      body: serviceDetailsBody,
      theme: 'grid',
      styles: { fontSize: 9, cellPadding: 1.5 },
      columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 50 } },
      didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
    });
    yPos = (doc as any).lastAutoTable.finalY + 8;
  } else {
    doc.text("Detail layanan tidak tersedia.", PDF_MARGIN, yPos);
    yPos += 6;
  }
  
  const totalPembayaran = (order.payments || []).reduce((sum, p) => sum + p.amount, 0);
  if(order.totalPrice) {
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text("Informasi Harga & Pembayaran:", PDF_MARGIN, yPos);
      yPos += 5;
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      const paymentInfoBody: RowInput[] = [
          ["Total Harga Paket (Estimasi):", formatCurrency(order.totalPrice, 'IDR')],
          ["Total Pembayaran Diterima:", formatCurrency(totalPembayaran, 'IDR')],
          ["Sisa Pembayaran:", formatCurrency(order.totalPrice - totalPembayaran, 'IDR')]
      ];
      autoTable(doc, {
        startY: yPos,
        body: paymentInfoBody,
        theme: 'plain',
        styles: { fontSize: 9, cellPadding: 1.5 },
        columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 50 } },
        didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
      });
      yPos = (doc as any).lastAutoTable.finalY + 8;
  }


  doc.setFontSize(9);
  doc.text("Hormat Kami,", PDF_MARGIN, yPos);
  yPos += 15;
  doc.text(APP_NAME, PDF_MARGIN, yPos);
  yPos += 5;
  doc.text(`Kontak: ${DEFAULT_SUPPORT_PHONE} | Email: ${DEFAULT_SUPPORT_EMAIL}`, PDF_MARGIN, yPos);

  doc.save(`Surat_Permintaan_Pesanan_${order.id.substring(0,8)}.pdf`);
};

const generateCostBreakdownForPdf = (doc: jsPDF, order: Order, startY: number): number => {
  let y = startY;
  if (!order.totalPrice || order.totalPrice === 0) {
    doc.setFontSize(9);
    doc.text("Rincian biaya akan tersedia setelah Admin menetapkan harga.", PDF_MARGIN, y);
    return y + 5;
  }

  const orderData = order.data as any;
  const costItems: Array<{label: string; qty: string | number; unitPrice: string; subtotal: string; subtotalIDR: string;}> = [];
  
  const addCostItemToPdf = (
      label: string, 
      quantity: number | string, 
      pricePerUnit: number, 
      currency: 'SAR' | 'USD', 
      totalAmountInCurrency: number
    ) => {
    costItems.push({
      label,
      qty: quantity.toString(),
      unitPrice: `${formatCurrency(pricePerUnit, currency)} (${formatCurrency(convertToIDR(pricePerUnit, currency), 'IDR')})`,
      subtotal: formatCurrency(totalAmountInCurrency, currency),
      subtotalIDR: formatCurrency(convertToIDR(totalAmountInCurrency, currency), 'IDR'),
    });
  };


  if (order.serviceType === ServiceType.HOTEL) {
    const hotelData = orderData as HotelBookingData;
    const processHotelCosts = (hotelInfo: HotelInfo | undefined, prefix: string) => {
        if (hotelInfo && hotelInfo.name && hotelInfo.pricesSAR) {
            const prices = hotelInfo.pricesSAR;
            const processRoomType = (roomType: keyof RoomBooking, roomLabel: string, pricePerNightSAR?: number) => {
                const roomCount = hotelInfo.rooms[roomType];
                if (roomCount > 0 && pricePerNightSAR) {
                    addCostItemToPdf(
                        `${prefix} - ${hotelInfo.name} - Kamar ${roomLabel}`,
                        `${roomCount} kamar x ${hotelInfo.nights} malam`,
                        pricePerNightSAR,
                        'SAR',
                        pricePerNightSAR * hotelInfo.nights * roomCount
                    );
                }
            };
            processRoomType('quad', 'Quad', prices.quad);
            processRoomType('triple', 'Triple', prices.triple);
            processRoomType('double', 'Double', prices.double);
        }
    };
    processHotelCosts(hotelData.madinahHotel, "Hotel Madinah");
    processHotelCosts(hotelData.makkahHotel, "Hotel Mekah");

    if (hotelData.includeVisa && hotelData.visaPricePerPaxUSD && hotelData.visaPax) {
      addCostItemToPdf(`Visa (${hotelData.muasasahName || 'Umum'})`, `${hotelData.visaPax} pax`, hotelData.visaPricePerPaxUSD, 'USD', hotelData.visaPricePerPaxUSD * hotelData.visaPax);
    }
    if (hotelData.includeHandling && hotelData.handlingPricePerPaxSAR && hotelData.handlingPax) {
      addCostItemToPdf('Layanan Handling Bandara', `${hotelData.handlingPax} pax`, hotelData.handlingPricePerPaxSAR, 'SAR', hotelData.handlingPricePerPaxSAR * hotelData.handlingPax);
    }
    if (hotelData.busPriceTotalSAR && hotelData.busPriceTotalSAR > 0) {
      addCostItemToPdf('Transportasi Bus (Paket)', `1 paket`, hotelData.busPriceTotalSAR, 'SAR', hotelData.busPriceTotalSAR);
    }
  } else if (order.serviceType === ServiceType.VISA) {
      const visaData = orderData as VisaBookingData;
      if (visaData.visaPricePerPaxUSD && visaData.pax) {
        addCostItemToPdf(`Visa (${visaData.muasasahName || 'Umum'})`, `${visaData.pax} pax`, visaData.visaPricePerPaxUSD, 'USD', visaData.visaPricePerPaxUSD * visaData.pax);
      }
      if (visaData.busPriceTotalSAR && visaData.busPriceTotalSAR > 0) {
        addCostItemToPdf('Transportasi Bus (Paket Visa)', `1 paket`, visaData.busPriceTotalSAR, 'SAR', visaData.busPriceTotalSAR);
      }
  } else if (order.serviceType === ServiceType.HANDLING) {
      const handlingData = orderData as HandlingBookingData;
      if (handlingData.handlingPricePerPaxSAR && handlingData.pax) {
        addCostItemToPdf('Layanan Handling Bandara', `${handlingData.pax} pax`, handlingData.handlingPricePerPaxSAR, 'SAR', handlingData.handlingPricePerPaxSAR * handlingData.pax);
      }
  } else if (order.serviceType === ServiceType.JASTIP && order.totalPrice) {
     costItems.push({
        label: `Jasa Titipan: ${(orderData as JastipBookingData).itemType} (${(orderData as JastipBookingData).quantity} ${(orderData as JastipBookingData).unit})`,
        qty: '1',
        unitPrice: formatCurrency(order.totalPrice, 'IDR'),
        subtotal: formatCurrency(order.totalPrice, 'IDR'),
        subtotalIDR: formatCurrency(order.totalPrice, 'IDR'),
     });
  }

  if (costItems.length === 0 && order.totalPrice && order.totalPrice > 0) {
    costItems.push({
        label: `Total Paket Layanan (${order.serviceType})`,
        qty: '1',
        unitPrice: formatCurrency(order.totalPrice, 'IDR'),
        subtotal: formatCurrency(order.totalPrice, 'IDR'),
        subtotalIDR: formatCurrency(order.totalPrice, 'IDR'),
    });
  }


  if (costItems.length > 0) {
    autoTable(doc, {
        startY: y,
        head: [['Deskripsi', 'Kuantitas', 'Harga Satuan', 'Subtotal (Mata Uang Asli)', 'Subtotal (IDR)']],
        body: costItems.map(item => [item.label, item.qty, item.unitPrice, item.subtotal, item.subtotalIDR]),
        theme: 'striped',
        headStyles: { fillColor: [220, 220, 220], textColor: [0,0,0], fontStyle: 'bold' as const, fontSize: 8 },
        styles: { fontSize: 8, cellPadding: 1.5 },
        columnStyles: {
            0: { cellWidth: PDF_CONTENT_WIDTH * 0.30 },
            1: { halign: 'center' as const, cellWidth: PDF_CONTENT_WIDTH * 0.15 },
            2: { halign: 'right' as const, cellWidth: PDF_CONTENT_WIDTH * 0.20 },
            3: { halign: 'right' as const, cellWidth: PDF_CONTENT_WIDTH * 0.20 },
            4: { halign: 'right' as const, cellWidth: PDF_CONTENT_WIDTH * 0.15 },
        },
        didDrawPage: (data) => { y = data.cursor?.y || y; }
    });
    y = (doc as any).lastAutoTable.finalY + 2;
    
    doc.setFontSize(8);
    doc.text(`Kurs Estimasi Digunakan: 1 USD = ${formatCurrency(MOCK_EXCHANGE_RATES.USD_TO_IDR, 'IDR', true, 0)}, 1 SAR = ${formatCurrency(MOCK_EXCHANGE_RATES.SAR_TO_IDR, 'IDR', true, 0)}`, PDF_MARGIN, y);
    y += 5;
  }
  return y;
};


export const generateInvoicePdf = (order: Order): void => {
  const doc = new jsPDF();
  let yPos = PDF_MARGIN;

  const customerData = order.data;

  doc.setFontSize(18);
  doc.setFont('helvetica', 'bold');
  doc.text("INVOICE", PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 8;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(APP_NAME, PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 5;
  doc.text(`Kontak: ${DEFAULT_SUPPORT_PHONE} | Email: ${DEFAULT_SUPPORT_EMAIL}`, PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 10;

  doc.setFontSize(10);
  autoTable(doc, {
    startY: yPos,
    body: [
      ["No. Invoice:", `INV/${order.id.substring(0,10).toUpperCase()}`],
      ["Tanggal Invoice:", formatFullDateForPdf(new Date().toISOString())],
      ["ID Pesanan:", order.id],
      ["Tanggal Pesanan:", formatFullDateForPdf(order.createdAt)],
    ],
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1 },
    columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 40 } },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 7;

  let alamatCustomer = 'N/A';
   if (order.serviceType === ServiceType.JASTIP) {
    alamatCustomer = (order.data as JastipBookingData).deliveryAddress || 'N/A';
  } else if ('address' in order.data && (order.data as any).address) {
    alamatCustomer = (order.data as any).address || 'N/A';
  }
  
  let ppiuNameForBilledTo = '-';
  if ('ppiuName' in customerData && (customerData as any).ppiuName) {
    ppiuNameForBilledTo = (customerData as any).ppiuName;
  }

  doc.setFont('helvetica', 'bold');
  doc.text("Ditagihkan Kepada:", PDF_MARGIN, yPos);
  yPos += 5;
  doc.setFont('helvetica', 'normal');
  const billedToBody: RowInput[] = [
    [(customerData as any).customerName || 'N/A'],
    [ppiuNameForBilledTo],
    [alamatCustomer],
    [(customerData as any).phone || 'N/A'],
  ];
  autoTable(doc, {
    startY: yPos,
    body: billedToBody,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1 },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 7;

  // Generate and add cost breakdown table
  yPos = generateCostBreakdownForPdf(doc, order, yPos);
  yPos += 5; // Add some space after the breakdown

  // Total
  const totalApprovedPayments = (order.payments || [])
    .filter(p => p.paymentApprovalStatus === 'Approved')
    .reduce((sum, p) => sum + p.amount, 0);
  const grandTotalIDR = order.totalPrice || 0;
  const sisaTagihan = grandTotalIDR - totalApprovedPayments;

  const totalsBody: RowInput[] = [
    [{ content: 'Subtotal Keseluruhan (IDR):', styles: { halign: 'right' as const, fontStyle: 'bold' as const } }, { content: formatCurrency(grandTotalIDR, 'IDR'), styles: { halign: 'right' as const } }],
    [{ content: 'Pajak (0%):', styles: { halign: 'right' as const, fontStyle: 'bold' as const } }, { content: formatCurrency(0, 'IDR'), styles: { halign: 'right' as const } }],
    [{ content: 'Grand Total Tagihan (IDR):', styles: { halign: 'right' as const, fontStyle: 'bold' as const, fontSize: 10 } }, { content: formatCurrency(grandTotalIDR, 'IDR'), styles: { halign: 'right' as const, fontStyle: 'bold' as const, fontSize: 10 } }],
    [{ content: 'Total Pembayaran Diterima & Disetujui (IDR):', styles: { halign: 'right' as const, fontStyle: 'bold' as const } }, { content: formatCurrency(totalApprovedPayments, 'IDR'), styles: { halign: 'right' as const } }],
    [{ content: 'Sisa Tagihan (IDR):', styles: { halign: 'right' as const, fontStyle: 'bold' as const, fontSize: 11, textColor: [255,0,0] } }, { content: formatCurrency(sisaTagihan, 'IDR'), styles: { halign: 'right' as const, fontStyle: 'bold' as const, fontSize: 11, textColor: [255,0,0] } }],
  ];

  autoTable(doc, {
    startY: yPos,
    body: totalsBody,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1 },
    columnStyles: { 0: { cellWidth: PDF_CONTENT_WIDTH - 50 }, 1: { cellWidth: 50 }},
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 10;

  doc.setFont('helvetica', 'bold');
  doc.text("Instruksi Pembayaran:", PDF_MARGIN, yPos);
  yPos += 5;
  doc.setFont('helvetica', 'normal');
  doc.text("Mohon lakukan pembayaran ke salah satu rekening berikut:", PDF_MARGIN, yPos);
  yPos += 5;
  doc.text("Bank BCA: 1234567890 a/n PT EWAKO ROYAL NUSANTARA (Contoh)", PDF_MARGIN, yPos);
  yPos += 5;
  doc.text("Bank Mandiri: 0987654321 a/n PT EWAKO ROYAL NUSANTARA (Contoh)", PDF_MARGIN, yPos);
  yPos += 8;
  doc.text("Harap konfirmasi pembayaran Anda melalui WhatsApp ke nomor Admin.", PDF_MARGIN, yPos);
  yPos += 8;

  doc.setFontSize(8);
  doc.text("Terima kasih atas kepercayaan Anda kepada " + APP_NAME + ".", PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });

  doc.save(`Invoice_${order.id.substring(0,8)}.pdf`);
};


export const generateManifestPdf = (order: Order): void => {
  const doc = new jsPDF();
  const manifest = order.manifest || [];
  let yPos = PDF_MARGIN;
  
  let ppiuNameFromData: string | undefined = undefined;
  if (order.serviceType === ServiceType.HOTEL || order.serviceType === ServiceType.VISA || order.serviceType === ServiceType.HANDLING) {
    ppiuNameFromData = (order.data as HotelBookingData | VisaBookingData | HandlingBookingData).ppiuName;
  }


  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text(`MANIFEST JEMAAH - ${order.packageInfo?.groupCode || `Order ID: ${order.id.substring(0,8)}`}`, PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 8;
  doc.setFontSize(10);
  doc.text(`PPIU/PIHK: ${order.packageInfo?.ppiuName || ppiuNameFromData || 'N/A'}`, PDF_MARGIN, yPos);
  yPos += 5;
  doc.text(`Total Jemaah: ${manifest.length} pax`, PDF_MARGIN, yPos);
  yPos += 8;

  type ManifestRow = {
    no: number;
    namaJemaah: string;
    jenisKelamin: string;
    tanggalLahir: string;
    usia: string;
    nomorVisa: string;
    namaDiPaspor: string;
    nomorPaspor: string;
    tanggalTerbitPaspor: string;
    tanggalExpiredPaspor: string;
    kotaAsalKeberangkatan: string;
  };
  
  const tableHeadConfig: Array<{ header: string; dataKey: keyof ManifestRow }> = [
    { header: 'No', dataKey: 'no' },
    { header: 'Nama Jemaah', dataKey: 'namaJemaah' },
    { header: 'JK', dataKey: 'jenisKelamin' },
    { header: 'Tgl Lahir', dataKey: 'tanggalLahir' },
    { header: 'Usia', dataKey: 'usia' },
    { header: 'No. Visa', dataKey: 'nomorVisa' },
    { header: 'Nama Paspor', dataKey: 'namaDiPaspor' },
    { header: 'No. Paspor', dataKey: 'nomorPaspor' },
    { header: 'Tgl Terbit', dataKey: 'tanggalTerbitPaspor' },
    { header: 'Tgl Expired', dataKey: 'tanggalExpiredPaspor' },
    { header: 'Kota Asal', dataKey: 'kotaAsalKeberangkatan'},
  ];

  const tableBody: ManifestRow[] = manifest.map((item, index) => ({
    no: index + 1,
    namaJemaah: item.namaJemaah,
    jenisKelamin: item.jenisKelamin?.charAt(0) || '-',
    tanggalLahir: formatDateForPdf(item.tanggalLahir),
    usia: item.usia !== undefined ? `${item.usia} th` : '-',
    nomorVisa: item.nomorVisa || '-',
    namaDiPaspor: item.namaDiPaspor,
    nomorPaspor: item.nomorPaspor,
    tanggalTerbitPaspor: formatDateForPdf(item.tanggalTerbitPaspor),
    tanggalExpiredPaspor: formatDateForPdf(item.tanggalExpiredPaspor),
    kotaAsalKeberangkatan: item.kotaAsalKeberangkatan || item.kotaTempatIssuedPaspor || '-',
  }));

  autoTable(doc, {
    startY: yPos,
    head: [tableHeadConfig.map(col => col.header)],
    body: tableBody.map(row => tableHeadConfig.map(col => row[col.dataKey])),
    theme: 'grid',
    styles: { fontSize: 7, cellPadding: 1 },
    headStyles: { fillColor: [200, 200, 200], textColor: [0,0,0], fontStyle: 'bold' as const },
    columnStyles: {
        no: { cellWidth: 8 },
        jenisKelamin: { cellWidth: 7, halign: 'center' as const },
        usia: { cellWidth: 10, halign: 'center' as const },
    },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });

  doc.save(`Manifest_${order.packageInfo?.groupCode || order.id.substring(0,8)}.pdf`);
};


// --- Handling Report PDF Generation ---

const addHandlingReportHeader = (doc: jsPDF, reportType: string, order: Order, report: HandlingReport, yPos: number): number => {
  let ppiuNameFromData: string | undefined = undefined;
  if (order.serviceType === ServiceType.HOTEL || order.serviceType === ServiceType.VISA || order.serviceType === ServiceType.HANDLING) {
    ppiuNameFromData = (order.data as HotelBookingData | VisaBookingData | HandlingBookingData).ppiuName;
  }

  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(`LAPORAN HANDLING - ${reportType.toUpperCase()}`, PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 7;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Order ID: ${order.id.substring(0,10)}... | Kode Grup: ${order.packageInfo?.groupCode || 'N/A'}`, PDF_PAGE_WIDTH / 2, yPos, { align: 'center' });
  yPos += 5;
  doc.text(`Nama PPIU: ${order.packageInfo?.ppiuName || ppiuNameFromData || 'N/A'}`, PDF_MARGIN, yPos);
  doc.text(`Tanggal Laporan: ${formatFullDateForPdf(report.createdAt)}`, PDF_PAGE_WIDTH - PDF_MARGIN, yPos, { align: 'right' });
  yPos += 5;
  doc.text(`Petugas PJ: ${(report.data as any).petugasPJName || 'N/A'}`, PDF_MARGIN, yPos);
  yPos += 7;
  return yPos;
};

const addJemaahHealthTable = (doc: jsPDF, jemaahSakitDetails: HandlingReportJemaahHealth[], yPos: number): number => {
  if (jemaahSakitDetails.length === 0) return yPos;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text("Detail Jemaah Sakit:", PDF_MARGIN, yPos);
  yPos += 5;
  autoTable(doc, {
    startY: yPos,
    head: [['Nama Jemaah', 'No. Paspor', 'No. Visa', 'Kota Asal', 'Keluhan']],
    body: jemaahSakitDetails.map(j => [j.namaJemaah, j.nomorPaspor, j.nomorVisa || '-', j.kotaAsal || '-', j.keluhan]),
    theme: 'striped',
    styles: { fontSize: 8, cellPadding: 1.5 },
    headStyles: { fillColor: [230, 230, 230], textColor: [0,0,0], fontStyle: 'bold' as const },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  return (doc as any).lastAutoTable.finalY + 5;
};

const addAbsensiTable = (doc: jsPDF, absensiData: { [jemaahId: string]: boolean }, manifest: ManifestItem[], title: string, yPos: number): number => {
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(title, PDF_MARGIN, yPos);
  yPos += 5;
  const body = manifest.map(j => [j.namaJemaah, j.nomorPaspor, absensiData[j.id] ? 'Hadir' : 'Tidak Hadir']);
  autoTable(doc, {
    startY: yPos,
    head: [['Nama Jemaah', 'No. Paspor', 'Status Kehadiran']],
    body: body,
    theme: 'striped',
    styles: { fontSize: 8, cellPadding: 1.5 },
    headStyles: { fillColor: [230, 230, 230], textColor: [0,0,0], fontStyle: 'bold' as const },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  return (doc as any).lastAutoTable.finalY + 5;
};


export const generateHandlingArrivalReportPdf = (order: Order, report: HandlingReport): void => {
  const doc = new jsPDF();
  const data = report.data as HandlingArrivalReportData;
  let yPos = PDF_MARGIN;
  yPos = addHandlingReportHeader(doc, "Kedatangan Jemaah", order, report, yPos);

  const reportDetails: RowInput[] = [
    ["Waktu Kedatangan Aktual:", formatFullDateTimeForPdf(data.waktuKedatanganJemaah)],
    ["Nama Maskapai:", data.namaMaskapai],
    ["Terminal Kedatangan:", data.terminalKedatangan],
    ["Nama Mutowif (Lapangan):", data.namaMutowif || '-'],
    ["Nama Tour Guide/Leader (Lapangan):", data.namaTourGuideLeader || '-'],
    ["Nama Bus (Dari Airport):", data.transportasiNamaBus],
    ["Nomor Seri Bus:", data.transportasiNomorSeriBus],
    ["No. Driver:", data.transportasiNoDriver],
    ["Kondisi Bus:", data.transportasiKondisiBus],
    ["Jumlah Koper:", `${data.bagasiKoper} unit`],
    ["Jumlah Tas Kabin:", `${data.bagasiTasKabin} unit`],
    ["Bagasi Lain:", data.bagasiLain || '-'],
    ["Kondisi Jemaah (Umum):", data.kondisiJemaahUmum],
    ["Waktu Keberangkatan dari Airport:", formatFullDateTimeForPdf(data.waktuKeberangkatanDariAirport)],
  ];
  autoTable(doc, {
    startY: yPos,
    body: reportDetails,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1 },
    columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 60 } },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 3;
  yPos = addAbsensiTable(doc, data.absensiJemaah, order.manifest || [], "Absensi Jemaah Saat Kedatangan:", yPos);
  yPos = addJemaahHealthTable(doc, data.jemaahSakitDetails, yPos);
  
  doc.save(`Handling_Arrival_Report_${order.packageInfo?.groupCode || order.id.substring(0,8)}.pdf`);
};


export const generateHandlingHotelCheckInReportPdf = (order: Order, report: HandlingReport): void => {
  const doc = new jsPDF();
  const data = report.data as HandlingHotelCheckInReportData;
  let yPos = PDF_MARGIN;
  yPos = addHandlingReportHeader(doc, "Check-in Hotel", order, report, yPos);

  const reportDetails: RowInput[] = [
    ["Lokasi Hotel:", data.lokasiHotel],
    ["Nama Hotel (Sistem):", data.namaHotel || '-'],
    ["Periode Check-in/out (Sistem):", data.tanggalCheckInOut || '-'],
    ["Durasi (Sistem):", data.durasi || '-'],
    ["Jumlah Kamar by Tipe (Sistem):", data.jumlahKamarByTipe || '-'],
    ["Ketersediaan Kunci Saat Tiba:", data.ketersediaanKunci],
    ["  Alasan Kunci Belum Tersedia:", data.alasanKunciBelumTersedia || (data.ketersediaanKunci === 'Belum Tersedia' ? '-' : 'N/A')],
    ["Ketersediaan Jumlah Kamar (Sesuai Pesanan):", data.ketersediaanJumlahKamar],
    ["  Alasan Kamar Belum Sesuai:", data.alasanKamarBelumSesuai || (data.ketersediaanJumlahKamar === 'Belum Sesuai' ? '-' : 'N/A')],
    ["  Solusi/Tindakan:", data.solusiKamarBelumSesuai || (data.ketersediaanJumlahKamar === 'Belum Sesuai' ? '-' : 'N/A')],
    ["Jumlah Koper (Ulang):", `${data.bagasiKoperUlang || 0} unit`],
    ["Jumlah Tas Kabin (Ulang):", `${data.bagasiTasKabinUlang || 0} unit`],
    ["Bagasi Lain (Ulang):", data.bagasiLainUlang || '-'],
    ["Status Distribusi Bagasi ke Kamar:", data.distribusiBagasi],
    ["  Nomor Kamar Bagasi Belum Terdistribusi:", data.nomorKamarBagasiBelumTerdistribusi || (data.distribusiBagasi === 'Belum' ? '-' : 'N/A')],
  ];
  autoTable(doc, {
    startY: yPos,
    body: reportDetails,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1 },
    columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 70 } },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  doc.save(`Handling_Hotel_CheckIn_Report_${order.packageInfo?.groupCode || order.id.substring(0,8)}.pdf`);
};

export const generateHandlingActivityReportPdf = (order: Order, report: HandlingReport): void => {
  const doc = new jsPDF();
  const data = report.data as HandlingActivityReportData;
  let yPos = PDF_MARGIN;
  yPos = addHandlingReportHeader(doc, "Kegiatan Jemaah", order, report, yPos);

  const reportDetails: RowInput[] = [
    ["Nama Kegiatan:", data.namaKegiatan],
    ["Nama Bus Kegiatan:", data.transportasiNamaBus],
    ["Nomor Seri Bus:", data.transportasiNomorSeriBus],
    ["No. Driver:", data.transportasiNoDriver],
    ["Kondisi Bus:", data.transportasiKondisiBus],
    ["Tujuan Kegiatan:", data.tujuanKegiatan.join(', ') || '-'],
    ["Kondisi Jemaah (Umum):", data.kondisiJemaahUmum],
    ["Waktu Kembali dari Kegiatan:", formatFullDateTimeForPdf(data.waktuKembaliDariKegiatan)],
    ["Rangkuman Perjalanan/Catatan:", data.rangkumanPerjalanan || '-'],
  ];
   autoTable(doc, {
    startY: yPos,
    body: reportDetails,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1 },
    columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 60 } },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 3;
  yPos = addAbsensiTable(doc, data.absensiJemaahKeberangkatan, order.manifest || [], "Absensi Jemaah Saat Keberangkatan Kegiatan:", yPos);
  yPos = addJemaahHealthTable(doc, data.jemaahSakitDetails, yPos);

  doc.save(`Handling_Activity_Report_${order.packageInfo?.groupCode || order.id.substring(0,8)}.pdf`);
};

export const generateHandlingDepartureReportPdf = (order: Order, report: HandlingReport): void => {
  const doc = new jsPDF();
  const data = report.data as HandlingDepartureReportData;
  let yPos = PDF_MARGIN;
  yPos = addHandlingReportHeader(doc, "Kepulangan Jemaah", order, report, yPos);

  const reportDetails: RowInput[] = [
    ["Jumlah Koper (Akhir):", `${data.bagasiKoperAkhir || 0} unit`],
    ["Jumlah Tas Kabin (Akhir):", `${data.bagasiTasKabinAkhir || 0} unit`],
    ["Bagasi Lain (Akhir):", data.bagasiLainAkhir || '-'],
    ["Kondisi Jemaah (Umum Saat Checkout):", data.kondisiJemaahUmumCheckout],
    ["Waktu Checkout Hotel:", formatFullDateTimeForPdf(data.waktuCheckoutHotel)],
    ["Nama Bus ke Airport:", data.transportasiNamaBusKeAirport],
    ["Nomor Seri Bus ke Airport:", data.transportasiNomorSeriBusKeAirport],
    ["No. Driver Bus ke Airport:", data.transportasiNoDriverKeAirport],
    ["Ada City Tour Tambahan?:", data.adaCityTourTambahan],
    ["  Tujuan City Tour Tambahan:", data.tujuanCityTourTambahan || (data.adaCityTourTambahan === 'Ya' ? '-' : 'N/A')],
    ["Waktu Kedatangan di Airport Pulang:", formatFullDateTimeForPdf(data.waktuKedatanganDiAirportPulang)],
    ["Nama Airport & Terminal Kepulangan:", data.namaAirportTerminalPulang],
    ["Catatan Proses Check-in Counter:", data.catatanProsesCheckInCounter || '-'],
    ["Catatan Proses Pembagian Tiket:", data.catatanProsesPembagianTiket || '-'],
    ["Catatan Proses Boarding:", data.catatanProsesBoarding || '-'],
  ];
   autoTable(doc, {
    startY: yPos,
    body: reportDetails,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 1 },
    columnStyles: { 0: { fontStyle: 'bold' as const, cellWidth: 70 } },
    didDrawPage: (data) => { yPos = data.cursor?.y || yPos; }
  });
  yPos = (doc as any).lastAutoTable.finalY + 3;
  yPos = addAbsensiTable(doc, data.absensiJemaahCheckout, order.manifest || [], "Absensi Jemaah Saat Checkout Hotel:", yPos);
  yPos = addJemaahHealthTable(doc, data.jemaahSakitDetailsCheckout, yPos);
  
  doc.save(`Handling_Departure_Report_${order.packageInfo?.groupCode || order.id.substring(0,8)}.pdf`);
};
