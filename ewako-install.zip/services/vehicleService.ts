
import { Vehicle } from '../types';

const API_BASE_URL = 'http://localhost:3002/api'; // Pastikan port sesuai

// Helper untuk mendapatkan token JWT dari localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('ewakoRoyalAuthToken');
};

// Helper untuk fetch request dengan Authorization header
async function fetchApi<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json', // Default Content-Type
    ...(options.headers ? (options.headers as Record<string, string>) : {}),
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }


  try {
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: `HTTP error! status: ${response.statusText || response.status}` }));
      throw new Error(errorData.message || `API Error: ${response.status} - Unknown error`);
    }
    if (response.status === 204) {
      return undefined as T;
    }
    return await response.json() as T;
  } catch (error) {
    console.error('Fetch API error (VehicleService):', url, options, error);
    throw error;
  }
}

export const getVehicles = async (): Promise<Vehicle[]> => {
  return fetchApi<Vehicle[]>(`${API_BASE_URL}/vehicles`);
};

export const getVehicleById = async (id: string): Promise<Vehicle | undefined> => {
  try {
    return await fetchApi<Vehicle>(`${API_BASE_URL}/vehicles/${id}`);
  } catch (error) {
     if ((error as Error).message.includes('404') || (error as Error).message.includes('Not Found') || (error as Error).message.includes('tidak ditemukan')) {
      return undefined;
    }
    throw error;
  }
};

export const createVehicle = async (vehicleData: Omit<Vehicle, 'id'>): Promise<Vehicle> => {
  return fetchApi<Vehicle>(`${API_BASE_URL}/vehicles`, {
    method: 'POST',
    body: JSON.stringify(vehicleData),
  });
};

export const updateVehicle = async (id: string, updates: Partial<Omit<Vehicle, 'id'>>): Promise<Vehicle | undefined> => {
  return fetchApi<Vehicle>(`${API_BASE_URL}/vehicles/${id}`, {
    method: 'PUT',
    body: JSON.stringify(updates),
  });
};

export const deleteVehicle = async (id: string): Promise<boolean> => {
  try {
    await fetchApi<void>(`${API_BASE_URL}/vehicles/${id}`, {
      method: 'DELETE',
    });
    return true;
  } catch (error) {
    console.error(`Failed to delete vehicle ${id}:`, error);
    return false;
  }
};
