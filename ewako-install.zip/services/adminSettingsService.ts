
import { AdminManagedBankAccount } from '../types';

const API_BASE_URL = 'http://localhost:3002/api/admin'; // Pastikan port sesuai

// Helper untuk mendapatkan token JWT dari localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('ewakoRoyalAuthToken');
};

// Helper untuk fetch request dengan Authorization header
async function fetchApi<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json', // Default Content-Type
    ...(options.headers ? (options.headers as Record<string, string>) : {}),
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: `HTTP error! status: ${response.statusText || response.status}` }));
      throw new Error(errorData.message || `API Error: ${response.status} - Unknown error`);
    }
    if (response.status === 204) {
      return undefined as T;
    }
    return await response.json() as T;
  } catch (error) {
    console.error('Fetch API error (AdminSettingsService):', url, options, error);
    throw error;
  }
}

export const getAdminBankAccounts = async (): Promise<AdminManagedBankAccount[]> => {
  return fetchApi<AdminManagedBankAccount[]>(`${API_BASE_URL}/bank-accounts`);
};

export const addAdminBankAccount = async (accountData: Omit<AdminManagedBankAccount, 'id'>): Promise<AdminManagedBankAccount> => {
  return fetchApi<AdminManagedBankAccount>(`${API_BASE_URL}/bank-accounts`, {
    method: 'POST',
    body: JSON.stringify(accountData),
  });
};

export const updateAdminBankAccount = async (id: string, updates: Partial<Omit<AdminManagedBankAccount, 'id'>>): Promise<AdminManagedBankAccount | undefined> => {
  // Backend mungkin tidak mengharapkan 'id' di body untuk update
  const { ...updatePayload } = updates; 
  return fetchApi<AdminManagedBankAccount>(`${API_BASE_URL}/bank-accounts/${id}`, {
    method: 'PUT',
    body: JSON.stringify(updatePayload),
  });
};

export const deleteAdminBankAccount = async (id: string): Promise<boolean> => {
  try {
    await fetchApi<void>(`${API_BASE_URL}/bank-accounts/${id}`, {
      method: 'DELETE',
    });
    return true;
  } catch (error) {
    console.error(`Failed to delete admin bank account ${id}:`, error);
    return false;
  }
};
