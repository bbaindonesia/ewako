
import { Order, OrderStatus, ServiceType, HotelBookingData, VisaBookingData, HandlingBookingData, JastipBookingData, PackageInfoData, ManifestItem, Payment, ChatMessage, HandlingReport, PaymentApprovalStatus } from '../types';
import { sendNotificationToCustomer } from './whatsappService';
import { getUserById as getAuthUserInfoForNotif } from './userService';

const API_BASE_URL = 'http://localhost:3002/api';

// Helper untuk mendapatkan token JWT dari localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('ewakoRoyalAuthToken');
};

// Helper untuk fetch request dengan Authorization header
async function fetchApi<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    ...(options.headers ? (options.headers as Record<string, string>) : {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Untuk FormData, Content-Type di-set otomatis oleh browser, jadi jangan di-override manual
  if (!(options.body instanceof FormData)) {
    if (!headers['Content-Type']) { // Hanya set jika belum ada
        headers['Content-Type'] = 'application/json';
    }
  }


  try {
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: `HTTP error! status: ${response.statusText || response.status}` }));
      console.error('API Error Response Data:', errorData);
      throw new Error(errorData.message || `API Error: ${response.status} - Unknown server error`);
    }
    if (response.status === 204) { // No Content
      return undefined as T;
    }
    return await response.json() as T;
  } catch (error) {
    console.error('Fetch API error:', url, options, error);
    throw error; // Rethrow error agar bisa ditangkap oleh pemanggil
  }
}


export const createOrder = async (
  userId: string,
  serviceType: ServiceType,
  data: HotelBookingData | VisaBookingData | HandlingBookingData | JastipBookingData
): Promise<Order> => {
  const newOrderData = { userId, serviceType, data };
  const createdOrder = await fetchApi<Order>(`${API_BASE_URL}/orders`, {
    method: 'POST',
    body: JSON.stringify(newOrderData),
  });

  // Client-side notification, idealnya backend yang menangani ini
  try {
    const adminUser = await getAuthUserInfoForNotif('adminUser'); 
    if (adminUser && adminUser.phone) {
      const customerName = (createdOrder.data as any).customerName || 'Pelanggan';
      const adminNotificationMessage = `Notifikasi Pesanan Baru: Jenis: ${createdOrder.serviceType}, ID: ${createdOrder.id.substring(0,8)}, Pemesan: ${customerName}. Silakan periksa dashboard admin.`;
      sendNotificationToCustomer(adminUser.phone, adminNotificationMessage);
    }
  } catch (error) {
    console.error("Error sending WhatsApp notification to admin (from createOrder):", error);
  }
  return createdOrder;
};

export const getOrdersByUserId = async (userId: string): Promise<Order[]> => {
  return fetchApi<Order[]>(`${API_BASE_URL}/orders?userId=${userId}`);
};

export const getAllOrders = async (): Promise<Order[]> => {
  return fetchApi<Order[]>(`${API_BASE_URL}/orders`);
};

export const getOrderById = async (orderId: string): Promise<Order | undefined> => {
  try {
    return await fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}`);
  } catch (error) {
    if ((error as Error).message.includes('404') || (error as Error).message.includes('Not Found') || (error as Error).message.includes('tidak ditemukan')) {
      console.warn(`Order with ID ${orderId} not found.`);
      return undefined;
    }
    throw error;
  }
};

export const updateOrderStatus = async (orderId: string, status: OrderStatus, customerConfirmation?: boolean): Promise<Order | undefined> => {
  return fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/status`, {
    method: 'PUT',
    body: JSON.stringify({ status, customerConfirmation }),
  });
};

export const updateOrderData = async (orderId: string, data: Partial<HotelBookingData> | Partial<VisaBookingData> | Partial<HandlingBookingData> | Partial<JastipBookingData>): Promise<Order | undefined> => {
  return fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/data`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
};

export const updatePackageInfo = async (orderId: string, packageInfo: PackageInfoData): Promise<Order | undefined> => {
  return fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/package-info`, {
    method: 'PUT',
    body: JSON.stringify(packageInfo),
  });
};

export const updateOrderManifest = async (orderId: string, manifest: ManifestItem[]): Promise<Order | undefined> => {
  return fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/manifest`, {
    method: 'PUT',
    body: JSON.stringify(manifest),
  });
};

// Helper untuk membaca file sebagai Data URL (tetap di client-side untuk preview jika diperlukan)
const readFileAsDataURL = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
};


export const addPaymentToOrder = async (
  orderId: string,
  paymentData: Omit<Payment, 'id' | 'createdAt' | 'orderId' | 'paymentProofFileName' | 'paymentProofFileDataUrl' | 'paymentProofFileType'> & { userId: string },
  paymentProofFile?: File
): Promise<Order | undefined> => {
  const formDataPayload = new FormData();
  // Kirim semua field paymentData sebagai string JSON dalam satu field
  // karena backend akan mem-parse ini dan menghandle file secara terpisah.
  formDataPayload.append('paymentDetails', JSON.stringify(paymentData));
  
  if (paymentProofFile) {
    formDataPayload.append('paymentProofFile', paymentProofFile, paymentProofFile.name);
  }

  const updatedOrder = await fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/payments`, {
    method: 'POST',
    body: formDataPayload, // Headers Content-Type akan di-set otomatis oleh browser untuk FormData
  });

  // Jika perlu preview di client setelah upload, tambahkan logika Data URL di sini seperti sebelumnya
    if (paymentProofFile && updatedOrder && updatedOrder.payments) {
    const newPaymentEntry = updatedOrder.payments?.find(p => 
        p.amount === paymentData.amount && 
        p.paymentDate === paymentData.paymentDate &&
        p.userId === paymentData.userId &&
        p.paymentApprovalStatus === 'Pending' && // Cari yang baru ditambahkan
        p.paymentProofFileName === paymentProofFile.name // Cocokkan dengan nama file yang diupload
    );

    if (newPaymentEntry && !newPaymentEntry.paymentProofFileDataUrl && paymentProofFile.type.startsWith('image/') && paymentProofFile.size < 2 * 1024 * 1024) {
        try {
            const dataUrl = await readFileAsDataURL(paymentProofFile);
            newPaymentEntry.paymentProofFileDataUrl = dataUrl;
            // Nama file dan tipe sudah ada dari backend, jadi tidak perlu di-set ulang di sini
        } catch (e) { console.error("Error creating Data URL for payment proof for UI:", e); }
    }
  }
  return updatedOrder;
};


export const deletePaymentFromOrder = async (orderId: string, paymentId: string): Promise<Order | undefined> => {
  return fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/payments/${paymentId}`, {
    method: 'DELETE',
  });
};

interface AdminPriceDetailsInput {
  madinahHotelRoomPricesSAR?: { quad?: number; triple?: number; double?: number };
  makkahHotelRoomPricesSAR?: { quad?: number; triple?: number; double?: number };
  visaPricePerPaxUSD?: number;
  handlingPricePerPaxSAR?: number;
  busPriceTotalSAR?: number;
  muasasahName?: string;
  jastipPriceIDR?: number; // Untuk jastip
}

export const adminSetPriceAndDetails = async (
  orderId: string,
  details: AdminPriceDetailsInput
): Promise<Order | undefined> => {
  return fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/pricing-details`, {
    method: 'PUT',
    body: JSON.stringify(details),
  });
};

export const addHandlingReport = async (
  orderId: string,
  reportData: Omit<HandlingReport, 'id' | 'createdAt' | 'orderId'> & { createdByUserId: string }
): Promise<Order | undefined> => {
  return fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/handling-reports`, {
    method: 'POST',
    body: JSON.stringify(reportData),
  });
};

export const updatePaymentApprovalStatus = async (
    orderId: string,
    paymentId: string,
    newStatus: PaymentApprovalStatus,
    approvedByUserId: string,
    adminActionNotes?: string
): Promise<Order | undefined> => {
    return fetchApi<Order>(`${API_BASE_URL}/orders/${orderId}/payments/${paymentId}/approval`, {
        method: 'PUT',
        body: JSON.stringify({ newStatus, approvedByUserId, adminActionNotes }),
    });
};
