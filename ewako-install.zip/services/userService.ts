
import { User } from '../types';
import { sendNotificationToCustomer } from './whatsappService'; // Untuk notifikasi

// Base URL untuk API backend Anda. Pastikan ini sesuai dengan port backend Anda.
// Port 3002 adalah yang kita set di .env backend.
const API_BASE_URL = 'http://localhost:3002/api';

// Helper untuk menangani response API dan error
async function handleApiResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: `HTTP error! status: ${response.statusText || response.status}` }));
    throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
  }
  if (response.status === 204) { // No Content
      return undefined as T;
  }
  return response.json();
}

// Fungsi untuk mendapatkan token dari localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('ewakoRoyalAuthToken');
};

export const loginUser = async (emailOrPhone: string, passwordInput: string): Promise<User> => {
  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ emailOrPhone, password: passwordInput }),
  });
  const data = await handleApiResponse<{ token: string; user: User }>(response);
  
  // Simpan token dan info pengguna dasar di localStorage
  localStorage.setItem('ewakoRoyalAuthToken', data.token);
  localStorage.setItem('ewakoRoyalUserId', data.user.id);
  localStorage.setItem('ewakoRoyalUserRole', data.user.role);

  // Trigger event agar komponen lain (seperti App.tsx) bisa tahu ada perubahan auth
   window.dispatchEvent(new StorageEvent('storage', {
      key: 'ewakoRoyalAuthToken', // Atau key generic seperti 'authChange'
      newValue: data.token, // Atau cukup userId
      storageArea: localStorage,
    }));

  return data.user;
};

export const registerUser = async (userData: Omit<User, 'id' | 'role' | 'accountStatus'> & { password?: string }): Promise<User> => {
  const response = await fetch(`${API_BASE_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData),
  });
  // Backend mungkin mengembalikan { message: string, user: User }
  const data = await handleApiResponse<{ message: string, user?: User }>(response);
  if (data.user) {
    // Tidak auto-login setelah registrasi, biarkan admin approve
    return data.user;
  } else {
    console.warn("Registrasi berhasil tapi tidak ada data user dikembalikan dari API:", data.message);
    throw new Error(data.message || "Registrasi berhasil, menunggu persetujuan Admin.");
  }
};

export const getUsers = async (roleFilter?: User['role'] | User['role'][]): Promise<User[]> => {
  let url = `${API_BASE_URL}/users`;
  if (roleFilter) {
    const rolesToFilterQuery = Array.isArray(roleFilter) ? roleFilter.join(',') : roleFilter;
    url += `?role=${rolesToFilterQuery}`;
  }
  const token = getAuthToken();
  const response = await fetch(url, {
    headers: token ? { 'Authorization': `Bearer ${token}` } : {}
  });
  return handleApiResponse<User[]>(response);
};

export const getUserById = async (userId: string): Promise<User | undefined> => {
  const token = getAuthToken();
  try {
    const response = await fetch(`${API_BASE_URL}/users/${userId}`, {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (response.status === 404) return undefined;
    return await handleApiResponse<User>(response);
  } catch (error) {
    if ((error as Error).message.toLowerCase().includes('not found') || (error as Error).message.includes('404')) {
      return undefined;
    }
    console.error(`Error fetching user by ID ${userId}:`, error);
    throw error;
  }
};

export const updateUser = async (userId: string, updates: Partial<Omit<User, 'id' | 'role' | 'accountStatus' | 'password'>>): Promise<User | undefined> => {
  const token = getAuthToken();
  const response = await fetch(`${API_BASE_URL}/users/${userId}`, {
    method: 'PUT',
    headers: { 
        'Content-Type': 'application/json',
        ...(token && {'Authorization': `Bearer ${token}`})
    },
    body: JSON.stringify(updates),
  });
  return handleApiResponse<User>(response);
};

export const updateUserAccountStatus = async (userId: string, newStatus: User['accountStatus']): Promise<User | undefined> => {
  const token = getAuthToken();
  const updatedUser = await fetch(`${API_BASE_URL}/users/${userId}/account-status`, {
    method: 'PUT',
    headers: { 
        'Content-Type': 'application/json',
        ...(token && {'Authorization': `Bearer ${token}`})
    },
    body: JSON.stringify({ accountStatus: newStatus }),
  }).then(res => handleApiResponse<User>(res));

  if (updatedUser && updatedUser.phone) {
    let message = '';
    if (newStatus === 'active') {
      message = `Akun Ewako Royal Anda (${updatedUser.name}) telah DIAKTIFKAN oleh Admin. Anda sekarang dapat login.`;
    } else if (newStatus === 'suspended') {
      message = `Akun Ewako Royal Anda (${updatedUser.name}) telah DITANGGUHKAN oleh Admin. Silakan hubungi Admin untuk informasi lebih lanjut.`;
    } else if (newStatus === 'pending_approval') {
      message = `Status akun Ewako Royal Anda (${updatedUser.name}) diubah menjadi 'Menunggu Persetujuan'.`;
    }
    if (message) {
      sendNotificationToCustomer(updatedUser.phone, message); // Notifikasi ke user yang diupdate
    }
  }
  return updatedUser;
};
