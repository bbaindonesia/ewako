import React, { useState } from 'react';
import { Layout } from '../components/Layout';
import { Input } from '../components/ui/Input';
import { Textarea } from '../components/ui/Textarea';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Select } from '../components/ui/Select';
import { HandlingBookingData, ServiceType, Mutowif } from '../types';
import { MOCK_MUTOWIFS } from '../constants';
import { sendOrderToWhatsApp } from '../services/whatsappService';
import { createOrder } from '../services/orderService'; // Updated import
import * as ReactRouterDOM from 'react-router-dom';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';

const mutowifOptions = MOCK_MUTOWIFS.map(m => ({ value: m.name, label: `${m.name} (${m.phone})` }));

const HandlingBookingPage: React.FC = () => {
  const navigate = ReactRouterDOM.useNavigate();
  const [formData, setFormData] = useState<HandlingBookingData>({
    customerName: '',
    ppiuName: '',
    phone: '',
    address: '',
    pax: 1,
    includeMutowif: false,
    mutowifName: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked, mutowifName: checked ? prev.mutowifName : '' }));
    } else {
        setFormData(prev => ({ 
            ...prev, 
            [name]: name === 'pax' ? Math.max(1, parseInt(value)) : value 
        }));
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setSubmissionStatus(null);

    if (!formData.customerName || !formData.phone || formData.pax <= 0) {
      alert("Nama Pemesan, No. Handphone, dan Jumlah Jemaah wajib diisi dengan benar.");
      setIsLoading(false);
      return;
    }

    try {
      const userId = localStorage.getItem('ewakoRoyalUserId') || 'guestUser';
      await createOrder(userId, ServiceType.HANDLING, formData);
      sendOrderToWhatsApp(ServiceType.HANDLING, formData);
      setSubmissionStatus('success');
      setTimeout(() => navigate('/orders'), 2000);
    } catch (error) {
      console.error("Error submitting handling order:", error);
      setSubmissionStatus('error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Layout>
       <div className="flex items-center mb-6">
         <button onClick={() => navigate(-1)} className="mr-4 p-2 rounded-full hover:bg-white/15 transition-colors"> {/* Adjusted hover */}
            <ArrowLeftIcon className="h-6 w-6 text-white" />
        </button>
        <h1 className="text-2xl font-bold metallic-gold-text">Pesan Handling Bandara</h1>
      </div>

      {submissionStatus === 'success' && (
        <div className="bg-green-600/80 backdrop-blur-sm border border-green-500 text-white px-4 py-3 rounded-lg relative mb-4" role="alert">
          <strong className="font-bold">Berhasil! </strong>
          <span className="block sm:inline">Pesanan handling Anda telah dikirim. Anda akan dialihkan.</span>
        </div>
      )}
      {submissionStatus === 'error' && (
        <div className="bg-red-600/80 backdrop-blur-sm border border-red-500 text-white px-4 py-3 rounded-lg relative mb-4" role="alert">
          <strong className="font-bold">Gagal! </strong>
          <span className="block sm:inline">Terjadi kesalahan saat mengirim pesanan. Silakan coba lagi.</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card title="Detail Pemesanan Handling" className="generic-card-glass"> {/* Used generic-card-glass */}
          <div className="space-y-4">
            <Input label="Nama Pemesan*" name="customerName" value={formData.customerName} onChange={handleInputChange} required />
            <Input label="Nama PPIU/PIHK (Opsional)" name="ppiuName" value={formData.ppiuName || ''} onChange={handleInputChange} />
            <Input label="No. Handphone*" name="phone" type="tel" value={formData.phone} onChange={handleInputChange} placeholder="+628123456789" required />
            <Textarea label="Alamat" name="address" value={formData.address || ''} onChange={handleInputChange} />
            <Input label="Jumlah Jemaah*" name="pax" type="number" min="1" value={formData.pax} onChange={handleInputChange} required />
            
            <div className="flex items-center mt-2">
              <input id="includeMutowif" name="includeMutowif" type="checkbox" checked={formData.includeMutowif} onChange={handleInputChange} className="form-checkbox-glass" /> {/* Custom class for glass checkbox */}
              <label htmlFor="includeMutowif" className="ml-2 block text-sm text-indigo-100">Include Mutowif</label>
            </div>
            {formData.includeMutowif && (
              <Select label="Pilih Mutowif (Opsional)" name="mutowifName" value={formData.mutowifName || ''} onChange={handleInputChange} options={mutowifOptions} placeholder="Pilih Mutowif" />
            )}
          </div>
        </Card>
        
        <div className="pt-4">
          <Button type="submit" variant="primary" size="lg" isLoading={isLoading} fullWidth>
            Kirim Pesanan Handling
          </Button>
        </div>
      </form>
    </Layout>
  );
};

export default HandlingBookingPage;