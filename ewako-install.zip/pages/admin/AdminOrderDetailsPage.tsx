import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { Layout } from '../../components/Layout';
import { Order, OrderStatus, HotelBookingData, VisaBookingData, HandlingBookingData, JastipBookingData, ServiceType, PackageInfoData, HotelInfo, ManifestItem, Payment, RoomBooking, Vehicle, BusRouteItem, AdminManagedBankAccount, ZiarahRouteItem, PaymentApprovalStatus, AddPaymentPayload } from '../../types';
import { getOrderById, updateOrderStatus, updatePackageInfo, addPaymentToOrder, deletePaymentFromOrder, adminSetPriceAndDetails, updatePaymentApprovalStatus } from '../../services/orderService'; 
import { getVehicles } from '../../services/vehicleService'; 
import { getAdminBankAccounts } from '../../services/adminSettingsService'; 
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { Select } from '../../components/ui/Select';
import { Textarea } from '../../components/ui/Textarea';
import { ArrowLeftIcon, TrashIcon, EyeIcon, ChatBubbleLeftEllipsisIcon, ArchiveBoxIcon, PlusCircleIcon, CheckCircleIcon, XCircleIcon } from '@heroicons/react/24/outline';
import { PackageInfoDisplay } from '../../components/PackageInfoDisplay';
import { sendNotificationToCustomer } from '../../services/whatsappService';
import { generateOrderRequestPdf, generateInvoicePdf, generatePackageInfoPdf, generateManifestPdf } from '../../services/pdfService';
import { MOCK_MUTOWIFS, ADMIN_WHATSAPP_NUMBER, SENDER_TRANSFER_METHODS } from '../../constants';
import { Input } from '../../components/ui/Input'; 
import { MOCK_EXCHANGE_RATES, convertToIDR, formatCurrency } from '../../services/currencyService';
import { ChatMessage, ChatParty, User as AuthUserType } from '../../types';
import { ChatMessageBubble } from '../../components/ChatMessageBubble';
import { ChatInput } from '../../components/ChatInput';
import { getChatMessagesForOrder, sendChatMessage } from '../../services/chatService'; 
import { useAuth } from '../../App'; 
import { getUserById as getAuthUserInfo } from '../../services/userService'; 


const statusOptions: Array<{ value: string; label: string }> = Object.values(OrderStatus).map(status => ({ value: status as string, label: status as string }));

const paymentTypeOptions: Array<{ value: string; label: string }> = [
    { value: 'DP', label: 'DP (Down Payment)' },
    { value: 'LUNAS', label: 'Pelunasan' },
    { value: 'LAINNYA', label: 'Lainnya' },
];
const paymentMethodOptions: Array<{ value: string; label: string }> = [
    { value: 'Transfer', label: 'Transfer Bank' },
    { value: 'Midtrans VA', label: 'Midtrans Virtual Account' },
    { value: 'Cash', label: 'Tunai (Cash)' },
    { value: 'Lainnya', label: 'Lainnya' },
];


const formatDateForDisplay = (dateString?: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString.split('T')[0]); 
  if (isNaN(date.getTime())) return '';
  return date.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

const formatDateTimeForDisplay = (dateTimeString?: string): string => {
    if (!dateTimeString) return '-';
    const date = new Date(dateTimeString);
    if (isNaN(date.getTime())) return '-';
    return date.toLocaleString('id-ID', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'});
};

const formatHotelToStringForPackageInfo = (hotel?: HotelInfo): string => {
    if (!hotel || !hotel.name) return '';
    const roomsDescArray: string[] = [];
    if (hotel.rooms.quad > 0) roomsDescArray.push(`Quad(${hotel.rooms.quad})`);
    if (hotel.rooms.triple > 0) roomsDescArray.push(`Triple(${hotel.rooms.triple})`);
    if (hotel.rooms.double > 0) roomsDescArray.push(`Double(${hotel.rooms.double})`);
    const roomsDesc = roomsDescArray.length > 0 ? roomsDescArray.join(', ') : 'Rincian kamar tidak specific';
    
    return `${hotel.name} (Kamar: ${roomsDesc}), ${hotel.nights} malam. CheckIn: ${formatDateForDisplay(hotel.checkIn)}, CheckOut: ${formatDateForDisplay(hotel.checkOut)}`;
};

const initialHotelInfoForEdit: HotelInfo = { name: '', nights: 1, rooms: { quad: 0, triple: 0, double: 0 }, checkIn: '', checkOut: '' };

const initialPackageInfo: PackageInfoData = {
    groupCode: '', 
    ppiuName: '', ppiuPhone: '', paxCount: 0, 
    madinahHotelInfo: '', makkahHotelInfo: '',
    madinahHotelStructured: { ...initialHotelInfoForEdit }, 
    makkahHotelStructured: { ...initialHotelInfoForEdit },
    busVehicleId: '', busName: '', busVehicleType: '', busDriverName: '', busDriverPhone: '', busSyarikahNumber: '',
    busRoutes: [], 
    ziarahRoutes: [], 
    mutowifName: '', mutowifPhone: '',
    representativeName: '', representativePhone: '', ewakoRoyalPhone: ADMIN_WHATSAPP_NUMBER.replace('+', ''),
    airlineName: '', airlineCode: '', arrivalDateTime: '', departureDateTime: '',
    pnrCode: '', arrivalTerminal: '', departureTerminal: '',
    tourLeaderName: '', tourLeaderPhone: '', tourGuideName: '', tourGuidePhone: ''
};

const ziarahKotaOptions: Array<{ value: ZiarahRouteItem['kota'] | string; label: string }> = [
    { value: '', label: 'Pilih Kota' },
    { value: 'Madinah', label: 'Madinah' },
    { value: 'Mekah', label: 'Mekah' },
    { value: 'Thaif', label: 'Thaif' },
    { value: 'Jeddah', label: 'Jeddah' },
    { value: 'Lainnya', label: 'Lainnya' },
];

const ziarahRemakeOptions: Array<{ value: ZiarahRouteItem['remake'] | string; label: string }> = [
    { value: '', label: 'Pilih Jenis' },
    { value: 'Ziarah', label: 'Ziarah' },
    { value: 'City Tour', label: 'City Tour' },
];

const initialPaymentForm = (adminId: string | null): AddPaymentPayload => ({
    userId: adminId || 'adminUser', 
    amount: 0,
    paymentDate: new Date().toISOString().split('T')[0],
    paymentType: 'DP',
    paymentMethod: 'Transfer',
    notes: '',
    senderAccountName: '', 
    senderAccountNumber: '', 
    senderBankName: '', 
    senderTransferMethod: '', 
    destinationBankName: '', 
    destinationAccountNumber: '', 
    paymentGatewayType: '', 
    paymentApprovalStatus: 'Pending',
});

interface AdminPriceDetailsPayload { 
  madinahHotelRoomPricesSAR?: { quad?: number; triple?: number; double?: number };
  makkahHotelRoomPricesSAR?: { quad?: number; triple?: number; double?: number };
  visaPricePerPaxUSD?: number;
  handlingPricePerPaxSAR?: number;
  busPriceTotalSAR?: number;
  muasasahName?: string;
  jastipPriceIDR?: number;
}

interface AdminPriceInputState {
  madinahHotelRoomPricesSAR: { quad: string; triple: string; double: string };
  makkahHotelRoomPricesSAR: { quad: string; triple: string; double: string };
  visaPricePerPaxUSD: string;
  handlingPricePerPaxSAR: string;
  busPriceTotalSAR: string;
  muasasahName: string;
}

const initialAdminPriceInputState: AdminPriceInputState = {
  madinahHotelRoomPricesSAR: { quad: '', triple: '', double: '' },
  makkahHotelRoomPricesSAR: { quad: '', triple: '', double: '' },
  visaPricePerPaxUSD: '',
  handlingPricePerPaxSAR: '',
  busPriceTotalSAR: '',
  muasasahName: '',
};

interface CalculatedSubTotalsState {
    madinahHotel: { subtotalSAR: { quad: number; triple: number; double: number; total: number }; subtotalIDR: { quad: number; triple: number; double: number; total: number } };
    makkahHotel: { subtotalSAR: { quad: number; triple: number; double: number; total: number }; subtotalIDR: { quad: number; triple: number; double: number; total: number } };
    visa: { amountUSD: number; amountIDR: number };
    handling: { amountSAR: number; amountIDR: number };
    bus: { amountSAR: number; amountIDR: number };
    summary: { totalSAR: number; totalUSD: number; grandTotalIDR: number };
}

const initialCalculatedSubTotals: CalculatedSubTotalsState = {
    madinahHotel: { subtotalSAR: { quad: 0, triple: 0, double: 0, total: 0 }, subtotalIDR: { quad: 0, triple: 0, double: 0, total: 0 } },
    makkahHotel: { subtotalSAR: { quad: 0, triple: 0, double: 0, total: 0 }, subtotalIDR: { quad: 0, triple: 0, double: 0, total: 0 } },
    visa: { amountUSD: 0, amountIDR: 0 },
    handling: { amountSAR: 0, amountIDR: 0 },
    bus: { amountSAR: 0, amountIDR: 0 },
    summary: { totalSAR: 0, totalUSD: 0, grandTotalIDR: 0 },
};

const getPaymentApprovalStatusPillStyle = (status: PaymentApprovalStatus): string => {
  switch (status) {
    case 'Pending': return 'border-yellow-400 text-yellow-300';
    case 'Approved': return 'border-green-400 text-green-300';
    case 'Rejected': return 'border-red-400 text-red-300';
    default: return 'border-gray-400 text-gray-300';
  }
};

const mapPaymentApprovalStatusToText = (status: PaymentApprovalStatus): string => {
    switch (status) {
        case 'Pending': return 'Menunggu Konfirmasi';
        case 'Approved': return 'Lunas / Disetujui';
        case 'Rejected': return 'Ditolak';
        default: return status;
    }
};


const AdminOrderDetailsPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { userId: adminAuthUserId } = useAuth(); 
  const [currentUser, setCurrentUser] = useState<AuthUserType | null>(null); 

  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<OrderStatus | ''>('');
  
  const [isEditingPackageInfo, setIsEditingPackageInfo] = useState(false);
  const [packageInfoForm, setPackageInfoForm] = useState<PackageInfoData>(initialPackageInfo);
  const [availableVehicles, setAvailableVehicles] = useState<Vehicle[]>([]);
  const [showManualMutowifInput, setShowManualMutowifInput] = useState(false);


  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentForm, setPaymentForm] = useState<AddPaymentPayload>(initialPaymentForm(adminAuthUserId));
  const [selectedPaymentProofFile, setSelectedPaymentProofFile] = useState<File | null>(null);
  const [adminBankAccounts, setAdminBankAccounts] = useState<AdminManagedBankAccount[]>([]);
  const [adminActionNotes, setAdminActionNotes] = useState('');


  const [adminPriceInputs, setAdminPriceInputs] = useState<AdminPriceInputState>(initialAdminPriceInputState);
  const [calculatedSubTotals, setCalculatedSubTotals] = useState<CalculatedSubTotalsState>(initialCalculatedSubTotals);

  const [showChatModal, setShowChatModal] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isLoadingChatMessages, setIsLoadingChatMessages] = useState(false);
  const [isSendingChatMessage, setIsSendingChatMessage] = useState(false);
  const chatMessagesEndRef = useRef<HTMLDivElement>(null);


  const fetchOrderDetails = useCallback(async (showLoadingSpinner = true): Promise<void> => {
    if (!orderId) { 
        setError("Order ID tidak valid.");
        setIsLoading(false);
        return; 
    }
    if (showLoadingSpinner) setIsLoading(true); setError(null);
    try {
      const [fetchedOrder, vehicles, fetchedAdminBankAccounts, adminInfo] = await Promise.all([
          getOrderById(orderId),
          getVehicles(),
          getAdminBankAccounts(),
          adminAuthUserId ? getAuthUserInfo(adminAuthUserId) : Promise.resolve(null) 
      ]);
      setAvailableVehicles(vehicles);
      setAdminBankAccounts(fetchedAdminBankAccounts);
      setCurrentUser(adminInfo || null);


      if (fetchedOrder) {
        setOrder(fetchedOrder);
        setSelectedStatus(fetchedOrder.status);
        
        let initialFormStatePopulated: PackageInfoData = { 
            ...initialPackageInfo, 
            ...(fetchedOrder.packageInfo || {}),
            madinahHotelStructured: fetchedOrder.packageInfo?.madinahHotelStructured || (fetchedOrder.data as HotelBookingData)?.madinahHotel || { ...initialHotelInfoForEdit },
            makkahHotelStructured: fetchedOrder.packageInfo?.makkahHotelStructured || (fetchedOrder.data as HotelBookingData)?.makkahHotel || { ...initialHotelInfoForEdit },
            ewakoRoyalPhone: fetchedOrder.packageInfo?.ewakoRoyalPhone || ADMIN_WHATSAPP_NUMBER.replace('+', ''),
            busRoutes: fetchedOrder.packageInfo?.busRoutes ? [...fetchedOrder.packageInfo.busRoutes.map(r => ({...r, id: r.id || uuidv4()}))] : [],
            ziarahRoutes: fetchedOrder.packageInfo?.ziarahRoutes ? [...fetchedOrder.packageInfo.ziarahRoutes.map(r => ({...r, id: r.id || uuidv4()}))] : [],
        };

        if (fetchedOrder.packageInfo?.busVehicleId) {
            const selectedVehicle = vehicles.find(v => v.id === fetchedOrder.packageInfo?.busVehicleId);
            if (selectedVehicle) {
                initialFormStatePopulated = {
                    ...initialFormStatePopulated,
                    busVehicleId: selectedVehicle.id,
                    busName: selectedVehicle.name,
                    busVehicleType: selectedVehicle.type,
                    busDriverName: selectedVehicle.driverName || '',
                    busDriverPhone: selectedVehicle.driverPhone || '',
                    busSyarikahNumber: selectedVehicle.companyName || '',
                };
            }
        }
        if (initialFormStatePopulated.busRoutes && initialFormStatePopulated.busRoutes.length > 0) {
            initialFormStatePopulated.busRoutes = initialFormStatePopulated.busRoutes.map(route => {
                let vehicleDetails = route.vehicleDetails || '';
                if (route.routeVehicleId) {
                    const foundVehicle = vehicles.find(v => v.id === route.routeVehicleId);
                    if (foundVehicle) {
                        vehicleDetails = `${foundVehicle.name} (${foundVehicle.plateNumber}) - Driver: ${foundVehicle.driverName || '-'}`;
                    }
                }
                return {...route, vehicleDetails};
            });
        } else {
             initialFormStatePopulated.busRoutes = [];
        }
        
        const isManualMutowif = !!(fetchedOrder.packageInfo?.mutowifName && !MOCK_MUTOWIFS.find(m => m.name === fetchedOrder.packageInfo?.mutowifName));
        setShowManualMutowifInput(isManualMutowif);


        setPackageInfoForm(initialFormStatePopulated);


        const data = fetchedOrder.data as any; 
        const newAdminPriceInputs = { ...initialAdminPriceInputState };
        if (fetchedOrder.serviceType === ServiceType.HOTEL) {
            const hotelData = data as HotelBookingData;
            if (hotelData.madinahHotel?.pricesSAR) {
                newAdminPriceInputs.madinahHotelRoomPricesSAR.quad = hotelData.madinahHotel.pricesSAR.quad?.toString() || '';
                newAdminPriceInputs.madinahHotelRoomPricesSAR.triple = hotelData.madinahHotel.pricesSAR.triple?.toString() || '';
                newAdminPriceInputs.madinahHotelRoomPricesSAR.double = hotelData.madinahHotel.pricesSAR.double?.toString() || '';
            }
            if (hotelData.makkahHotel?.pricesSAR) {
                newAdminPriceInputs.makkahHotelRoomPricesSAR.quad = hotelData.makkahHotel.pricesSAR.quad?.toString() || '';
                newAdminPriceInputs.makkahHotelRoomPricesSAR.triple = hotelData.makkahHotel.pricesSAR.triple?.toString() || '';
                newAdminPriceInputs.makkahHotelRoomPricesSAR.double = hotelData.makkahHotel.pricesSAR.double?.toString() || '';
            }
             newAdminPriceInputs.visaPricePerPaxUSD = hotelData.visaPricePerPaxUSD?.toString() || '';
             newAdminPriceInputs.handlingPricePerPaxSAR = hotelData.handlingPricePerPaxSAR?.toString() || '';
             newAdminPriceInputs.busPriceTotalSAR = hotelData.busPriceTotalSAR?.toString() || '';
             newAdminPriceInputs.muasasahName = hotelData.muasasahName || '';
        } else if (fetchedOrder.serviceType === ServiceType.VISA) {
            const visaData = data as VisaBookingData;
            newAdminPriceInputs.visaPricePerPaxUSD = visaData.visaPricePerPaxUSD?.toString() || '';
            newAdminPriceInputs.busPriceTotalSAR = visaData.busPriceTotalSAR?.toString() || '';
            newAdminPriceInputs.muasasahName = visaData.muasasahName || '';
        } else if (fetchedOrder.serviceType === ServiceType.HANDLING) {
            const handlingData = data as HandlingBookingData;
            newAdminPriceInputs.handlingPricePerPaxSAR = handlingData.handlingPricePerPaxSAR?.toString() || '';
        }
        setAdminPriceInputs(newAdminPriceInputs);

      } else { setError("Pesanan tidak ditemukan."); }
    } catch (err) { 
        setError("Gagal memuat detail pesanan.");
        console.error(err);
    } finally { if (showLoadingSpinner) setIsLoading(false); }
  }, [orderId, adminAuthUserId]);

  useEffect(() => { 
    fetchOrderDetails(); 
    if (adminAuthUserId) {
      setPaymentForm(initialPaymentForm(adminAuthUserId));
    }
  }, [fetchOrderDetails, adminAuthUserId]);
  
   useEffect(() => {
    if (!order) return;

    const data = order.data as any;
    const newSubTotals: CalculatedSubTotalsState = JSON.parse(JSON.stringify(initialCalculatedSubTotals));
    let currentTotalSAR = 0;
    let currentTotalUSD = 0;
    let currentGrandTotalIDR = 0;

    if (order.serviceType === ServiceType.HOTEL) {
        const hotelData = data as HotelBookingData;
        
        const calculateHotelSubtotals = (
            hotelInfo?: HotelInfo, 
            roomPricesSAR?: { quad: string; triple: string; double: string }
        ): { subtotalSAR: { quad: number; triple: number; double: number; total: number }; subtotalIDR: { quad: number; triple: number; double: number; total: number } } => {
            const result = { 
                subtotalSAR: { quad: 0, triple: 0, double: 0, total: 0 }, 
                subtotalIDR: { quad: 0, triple: 0, double: 0, total: 0 } 
            };
            if (!hotelInfo || !roomPricesSAR) return result;

            const priceQuadSAR = parseFloat(roomPricesSAR.quad) || 0;
            const priceTripleSAR = parseFloat(roomPricesSAR.triple) || 0;
            const priceDoubleSAR = parseFloat(roomPricesSAR.double) || 0;

            if (hotelInfo.rooms.quad > 0 && priceQuadSAR > 0) {
                result.subtotalSAR.quad = priceQuadSAR * hotelInfo.nights * hotelInfo.rooms.quad;
                result.subtotalIDR.quad = convertToIDR(result.subtotalSAR.quad, 'SAR');
            }
            if (hotelInfo.rooms.triple > 0 && priceTripleSAR > 0) {
                result.subtotalSAR.triple = priceTripleSAR * hotelInfo.nights * hotelInfo.rooms.triple;
                result.subtotalIDR.triple = convertToIDR(result.subtotalSAR.triple, 'SAR');
            }
            if (hotelInfo.rooms.double > 0 && priceDoubleSAR > 0) {
                result.subtotalSAR.double = priceDoubleSAR * hotelInfo.nights * hotelInfo.rooms.double;
                result.subtotalIDR.double = convertToIDR(result.subtotalSAR.double, 'SAR');
            }
            result.subtotalSAR.total = result.subtotalSAR.quad + result.subtotalSAR.triple + result.subtotalSAR.double;
            result.subtotalIDR.total = result.subtotalIDR.quad + result.subtotalIDR.triple + result.subtotalIDR.double;
            return result;
        };

        newSubTotals.madinahHotel = calculateHotelSubtotals(hotelData.madinahHotel, adminPriceInputs.madinahHotelRoomPricesSAR);
        currentTotalSAR += newSubTotals.madinahHotel.subtotalSAR.total;
        currentGrandTotalIDR += newSubTotals.madinahHotel.subtotalIDR.total;
        
        newSubTotals.makkahHotel = calculateHotelSubtotals(hotelData.makkahHotel, adminPriceInputs.makkahHotelRoomPricesSAR);
        currentTotalSAR += newSubTotals.makkahHotel.subtotalSAR.total;
        currentGrandTotalIDR += newSubTotals.makkahHotel.subtotalIDR.total;

        if (hotelData.includeVisa && hotelData.visaPax && parseFloat(adminPriceInputs.visaPricePerPaxUSD) > 0) {
            newSubTotals.visa.amountUSD = parseFloat(adminPriceInputs.visaPricePerPaxUSD) * hotelData.visaPax;
            newSubTotals.visa.amountIDR = convertToIDR(newSubTotals.visa.amountUSD, 'USD');
            currentTotalUSD += newSubTotals.visa.amountUSD;
            currentGrandTotalIDR += newSubTotals.visa.amountIDR;
        }
        if (hotelData.includeHandling && hotelData.handlingPax && parseFloat(adminPriceInputs.handlingPricePerPaxSAR) > 0) {
            newSubTotals.handling.amountSAR = parseFloat(adminPriceInputs.handlingPricePerPaxSAR) * hotelData.handlingPax;
            newSubTotals.handling.amountIDR = convertToIDR(newSubTotals.handling.amountSAR, 'SAR');
            currentTotalSAR += newSubTotals.handling.amountSAR;
            currentGrandTotalIDR += newSubTotals.handling.amountIDR;
        }
         if (parseFloat(adminPriceInputs.busPriceTotalSAR) > 0 ) {
            newSubTotals.bus.amountSAR = parseFloat(adminPriceInputs.busPriceTotalSAR);
            newSubTotals.bus.amountIDR = convertToIDR(newSubTotals.bus.amountSAR, 'SAR');
            currentTotalSAR += newSubTotals.bus.amountSAR;
            currentGrandTotalIDR += newSubTotals.bus.amountIDR;
        }
    } else if (order.serviceType === ServiceType.VISA) {
        const visaData = data as VisaBookingData;
        if (visaData.pax && parseFloat(adminPriceInputs.visaPricePerPaxUSD) > 0) {
            newSubTotals.visa.amountUSD = parseFloat(adminPriceInputs.visaPricePerPaxUSD) * visaData.pax;
            newSubTotals.visa.amountIDR = convertToIDR(newSubTotals.visa.amountUSD, 'USD');
            currentTotalUSD += newSubTotals.visa.amountUSD;
            currentGrandTotalIDR += newSubTotals.visa.amountIDR;
        }
        if (parseFloat(adminPriceInputs.busPriceTotalSAR) > 0 ) {
            newSubTotals.bus.amountSAR = parseFloat(adminPriceInputs.busPriceTotalSAR);
            newSubTotals.bus.amountIDR = convertToIDR(newSubTotals.bus.amountSAR, 'SAR');
            currentTotalSAR += newSubTotals.bus.amountSAR;
            currentGrandTotalIDR += newSubTotals.bus.amountIDR;
        }
    } else if (order.serviceType === ServiceType.HANDLING) {
        const handlingData = data as HandlingBookingData;
        if (handlingData.pax && parseFloat(adminPriceInputs.handlingPricePerPaxSAR) > 0) {
            newSubTotals.handling.amountSAR = parseFloat(adminPriceInputs.handlingPricePerPaxSAR) * handlingData.pax;
            newSubTotals.handling.amountIDR = convertToIDR(newSubTotals.handling.amountSAR, 'SAR');
            currentTotalSAR += newSubTotals.handling.amountSAR;
            currentGrandTotalIDR += newSubTotals.handling.amountIDR;
        }
    }
    

    newSubTotals.summary.totalSAR = currentTotalSAR;
    newSubTotals.summary.totalUSD = currentTotalUSD;
    newSubTotals.summary.grandTotalIDR = Math.round(currentGrandTotalIDR);
    setCalculatedSubTotals(newSubTotals);
  }, [adminPriceInputs, order]);

  const scrollToChatBottom = () => {
    chatMessagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  useEffect(scrollToChatBottom, [chatMessages]);


  const handleAdminPriceInputChange = (
    name: keyof AdminPriceInputState | string, 
    value: string
  ) => {
    setAdminPriceInputs(prev => {
      const keys = name.split('.');
      if (keys.length === 2) { 
        const [objectKey, fieldKey] = keys as [keyof AdminPriceInputState, string];
         if (objectKey === 'madinahHotelRoomPricesSAR' || objectKey === 'makkahHotelRoomPricesSAR') {
            return {
                ...prev,
                [objectKey]: {
                    ...(prev[objectKey] as object), 
                    [fieldKey]: value,
                },
            };
        }
      }
      return { ...prev, [name as keyof AdminPriceInputState]: value };
    });
  };

  const handleAdminSavePriceAndDetails = async () => {
    if (!order || !orderId) return;
    setIsSubmitting(true);
    try {
      const detailsToSave: AdminPriceDetailsPayload = { 
        madinahHotelRoomPricesSAR: {
            quad: adminPriceInputs.madinahHotelRoomPricesSAR.quad ? parseFloat(adminPriceInputs.madinahHotelRoomPricesSAR.quad) : undefined,
            triple: adminPriceInputs.madinahHotelRoomPricesSAR.triple ? parseFloat(adminPriceInputs.madinahHotelRoomPricesSAR.triple) : undefined,
            double: adminPriceInputs.madinahHotelRoomPricesSAR.double ? parseFloat(adminPriceInputs.madinahHotelRoomPricesSAR.double) : undefined,
        },
        makkahHotelRoomPricesSAR: {
            quad: adminPriceInputs.makkahHotelRoomPricesSAR.quad ? parseFloat(adminPriceInputs.makkahHotelRoomPricesSAR.quad) : undefined,
            triple: adminPriceInputs.makkahHotelRoomPricesSAR.triple ? parseFloat(adminPriceInputs.makkahHotelRoomPricesSAR.triple) : undefined,
            double: adminPriceInputs.makkahHotelRoomPricesSAR.double ? parseFloat(adminPriceInputs.makkahHotelRoomPricesSAR.double) : undefined,
        },
        visaPricePerPaxUSD: adminPriceInputs.visaPricePerPaxUSD ? parseFloat(adminPriceInputs.visaPricePerPaxUSD) : undefined,
        handlingPricePerPaxSAR: adminPriceInputs.handlingPricePerPaxSAR ? parseFloat(adminPriceInputs.handlingPricePerPaxSAR) : undefined,
        busPriceTotalSAR: adminPriceInputs.busPriceTotalSAR ? parseFloat(adminPriceInputs.busPriceTotalSAR) : undefined,
        muasasahName: adminPriceInputs.muasasahName,
      };

      const updatedOrder = await adminSetPriceAndDetails(orderId, detailsToSave);
      if (updatedOrder) {
        setOrder(updatedOrder); 
        setSelectedStatus(updatedOrder.status); 
        const customerPhone = (updatedOrder.data as any).phone;
        if (customerPhone && updatedOrder.totalPrice) {
          sendNotificationToCustomer(customerPhone, 
            `Harga untuk pesanan Anda (ID: ${orderId.substring(0,8)}) telah ditetapkan menjadi ${formatCurrency(updatedOrder.totalPrice, 'IDR')}. Mohon periksa detail pesanan Anda di aplikasi EWAKO ROYAL dan lakukan konfirmasi.`
          );
        }
        alert("Harga dan detail Muasasah berhasil disimpan. Status pesanan mungkin diubah menjadi 'Tentative Confirmation'.");
        fetchOrderDetails(false); 
      } else { throw new Error("Gagal update order."); }
    } catch (err) { setError("Gagal menyimpan harga dan detail."); console.error(err); } 
    finally { setIsSubmitting(false); }
  };
  
  const handleStatusUpdate = async () => { 
    if (!orderId || !selectedStatus || selectedStatus === order?.status) return;
    setIsSubmitting(true);
    try {
        const updatedOrder = await updateOrderStatus(orderId, selectedStatus);
        if (updatedOrder) {
            setOrder(updatedOrder);
            alert(`Status pesanan berhasil diubah menjadi: ${selectedStatus}`);
            const customerPhone = (updatedOrder.data as any).phone;
            let messageToCustomer = `Status pesanan Anda (${updatedOrder.serviceType} - ID: ${orderId.substring(0,8)}) telah diperbarui oleh admin menjadi: ${selectedStatus}.`;
            if (selectedStatus === OrderStatus.DEFINITE_CONFIRMATION) { 
                messageToCustomer += " Silakan lakukan pembayaran Down Payment (DP). Info rekening akan kami kirimkan.";
            } else if (selectedStatus === OrderStatus.CONFIRMED_BY_ADMIN){ 
                 messageToCustomer += " Pesanan Anda telah dikonfirmasi oleh Admin. Silakan lanjutkan ke tahap pembayaran atau konfirmasi selanjutnya.";
            }else if (selectedStatus === OrderStatus.DOWNPAYMENT_RECEIVED) {
                messageToCustomer = `Pembayaran DP Anda untuk pesanan (${updatedOrder.serviceType} - ID: ${orderId.substring(0,8)}) telah kami konfirmasi. Terima kasih.`;
            } else if (selectedStatus === OrderStatus.FULLY_PAID) {
                messageToCustomer = `Pembayaran Anda untuk pesanan (${updatedOrder.serviceType} - ID: ${orderId.substring(0,8)}) telah lunas. Itinerary dan dokumen akan segera kami kirimkan. Terima kasih telah menggunakan layanan EWAKO ROYAL.`;
            } else if (selectedStatus === OrderStatus.CANCELLED) {
                messageToCustomer = `Dengan berat hati kami memberitahukan bahwa pesanan Anda (${updatedOrder.serviceType} - ID: ${orderId.substring(0,8)}) telah dibatalkan oleh Admin. Silakan hubungi kami untuk info lebih lanjut.`;
            }
            if (customerPhone) sendNotificationToCustomer(customerPhone, messageToCustomer);
        }
    } catch(err) {
        setError("Gagal memperbarui status.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };

const handlePackageInfoFormHotelChange = useCallback((
    hotelFieldKey: 'madinahHotelStructured' | 'makkahHotelStructured',
    field: string, 
    value: string | number
  ) => {
    setPackageInfoForm(prev => {
        const hotelToUpdate: HotelInfo = JSON.parse(JSON.stringify(prev[hotelFieldKey] || initialHotelInfoForEdit)); 
    
        if (field.startsWith('rooms.')) {
          const roomSubField = field.split('.')[1] as keyof RoomBooking;
          hotelToUpdate.rooms[roomSubField] = Math.max(0, Number(value));
        } else {
          const typedField = field as keyof HotelInfo;
          if (typedField === 'name') {
              hotelToUpdate.name = String(value);
          } else if (typedField === 'checkIn') {
              hotelToUpdate.checkIn = String(value);
          } else if (typedField === 'checkOut') { 
              hotelToUpdate.checkOut = String(value);
          } else if (typedField === 'nights') {
              hotelToUpdate.nights = Math.max(1, Number(value));
          }
        }
    
        if ((field === 'checkIn' || field === 'nights') && hotelToUpdate.checkIn && hotelToUpdate.nights > 0) {
          const checkInDate = new Date(hotelToUpdate.checkIn);
          if (!isNaN(checkInDate.getTime())) {
            checkInDate.setDate(checkInDate.getDate() + hotelToUpdate.nights);
            hotelToUpdate.checkOut = checkInDate.toISOString().split('T')[0];
          }
        }
        
        return { ...prev, [hotelFieldKey]: hotelToUpdate };
      });
  }, []);

  const handlePackageInfoFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => { 
    const { name, value } = e.target;
    
    if (name === 'mutowifNameSelection') { 
        if (value === 'MANUAL_INPUT') {
            setShowManualMutowifInput(true);
            setPackageInfoForm(prev => ({ ...prev, mutowifName: '', mutowifPhone: '' }));
        } else {
            setShowManualMutowifInput(false);
            const selectedMutowif = MOCK_MUTOWIFS.find(m => m.name === value);
            setPackageInfoForm(prev => ({ 
                ...prev, 
                mutowifName: selectedMutowif?.name || '',
                mutowifPhone: selectedMutowif?.phone || ''
            }));
        }
    } else if (name === 'busVehicleId') {
        const selectedVehicle = availableVehicles.find(v => v.id === value);
        setPackageInfoForm(prev => ({
            ...prev,
            busVehicleId: value,
            busName: selectedVehicle?.name || '',
            busVehicleType: selectedVehicle?.type || '',
            busDriverName: selectedVehicle?.driverName || '',
            busDriverPhone: selectedVehicle?.driverPhone || '',
            busSyarikahNumber: selectedVehicle?.companyName || '',
        }));
    } else {
        setPackageInfoForm(prev => ({ ...prev, [name]: value }));
    }
  };


  const handleAddBusRoute = () => { 
      setPackageInfoForm(prev => ({ 
          ...prev, 
          busRoutes: [...(prev.busRoutes || []), {id: uuidv4(), date: '', from: '', to: '', routeVehicleId: '', vehicleDetails: ''}] 
      }));
  };

  const handleBusRouteChange = (index: number, field: keyof Omit<BusRouteItem, 'id'>, value: string) => {
    setPackageInfoForm(prev => {
        const newRoutes = prev.busRoutes ? [...prev.busRoutes] : [];
        const routeToUpdate = { ...newRoutes[index] };

        if (field === 'date' || field === 'from' || field === 'to' || field === 'vehicleDetails') {
            (routeToUpdate as any)[field] = value;
        } else if (field === 'routeVehicleId') {
            routeToUpdate.routeVehicleId = value;
            const selectedVehicle = availableVehicles.find(v => v.id === value);
            routeToUpdate.vehicleDetails = selectedVehicle 
                ? `${selectedVehicle.name} (${selectedVehicle.plateNumber}) - Driver: ${selectedVehicle.driverName || '-'}` 
                : '';
        }

        newRoutes[index] = routeToUpdate;
        return { ...prev, busRoutes: newRoutes };
    });
};
  const handleRemoveBusRoute = (index: number) => { 
      setPackageInfoForm(prev => ({...prev, busRoutes: (prev.busRoutes || []).filter((_, i) => i !== index)}));
  };

  const handleAddZiarahRoutePackageInfo = () => {
    setPackageInfoForm(prev => ({
      ...prev,
      ziarahRoutes: [...(prev.ziarahRoutes || []), { id: uuidv4(), tujuan: '', kota: '', tanggal: '', waktu: '', remake: '' }]
    }));
  };

  const handleZiarahRouteChangePackageInfo = (index: number, field: keyof Omit<ZiarahRouteItem, 'id'>, value: string) => {
    setPackageInfoForm(prev => {
      const newZiarahRoutes = prev.ziarahRoutes ? [...prev.ziarahRoutes] : [];
      const routeToUpdate = { ...newZiarahRoutes[index] };
      
       if (field === 'kota') {
        routeToUpdate.kota = value as ZiarahRouteItem['kota'];
      } else if (field === 'remake') {
        routeToUpdate.remake = value as ZiarahRouteItem['remake'];
      } else if (field === 'tujuan' || field === 'tanggal' || field === 'waktu') {
         (routeToUpdate as Record<string, string>)[field] = value;
      }
      newZiarahRoutes[index] = routeToUpdate;
      return { ...prev, ziarahRoutes: newZiarahRoutes };
    });
  };

  const handleRemoveZiarahRoutePackageInfo = (index: number) => {
    setPackageInfoForm(prev => ({
      ...prev,
      ziarahRoutes: (prev.ziarahRoutes || []).filter((_, i) => i !== index)
    }));
  };

const handleEditPackageInfoClick = async () => {
    if (availableVehicles.length === 0) {
        try {
            const vehicles = await getVehicles();
            setAvailableVehicles(vehicles);
        } catch (err) {
            setError("Gagal memuat daftar kendaraan untuk form paket info.");
            console.error(err);
        }
    }

    if (order) {
        let currentFormState: PackageInfoData = { 
            ...initialPackageInfo, 
            ...(order.packageInfo || {}),
             madinahHotelStructured: order.packageInfo?.madinahHotelStructured || (order.data as HotelBookingData)?.madinahHotel || { ...initialHotelInfoForEdit },
             makkahHotelStructured: order.packageInfo?.makkahHotelStructured || (order.data as HotelBookingData)?.makkahHotel || { ...initialHotelInfoForEdit },
            ewakoRoyalPhone: order.packageInfo?.ewakoRoyalPhone || ADMIN_WHATSAPP_NUMBER.replace('+', ''),
            busRoutes: order.packageInfo?.busRoutes ? [...order.packageInfo.busRoutes.map(r => ({...r, id: r.id || uuidv4()}))] : [],
            ziarahRoutes: order.packageInfo?.ziarahRoutes ? [...order.packageInfo.ziarahRoutes.map(r => ({...r, id: r.id || uuidv4()}))] : [],
         };

        if (order.packageInfo?.busVehicleId) {
            const selectedVehicle = availableVehicles.find(v => v.id === order.packageInfo?.busVehicleId) || (await getVehicles()).find(v => v.id === order.packageInfo?.busVehicleId);
            if (selectedVehicle) {
                currentFormState = {
                    ...currentFormState,
                    busVehicleId: selectedVehicle.id,
                    busName: selectedVehicle.name,
                    busVehicleType: selectedVehicle.type,
                    busDriverName: selectedVehicle.driverName || '',
                    busDriverPhone: selectedVehicle.driverPhone || '',
                    busSyarikahNumber: selectedVehicle.companyName || '',
                };
            }
        } else if (order.data) { 
            const data = order.data as HotelBookingData; 
            currentFormState.ppiuName = data.ppiuName || currentFormState.ppiuName;
            currentFormState.madinahHotelInfo = currentFormState.madinahHotelStructured ? formatHotelToStringForPackageInfo(currentFormState.madinahHotelStructured) : (data.madinahHotel ? formatHotelToStringForPackageInfo(data.madinahHotel) : '');
            currentFormState.makkahHotelInfo = currentFormState.makkahHotelStructured ? formatHotelToStringForPackageInfo(currentFormState.makkahHotelStructured) : (data.makkahHotel ? formatHotelToStringForPackageInfo(data.makkahHotel) : '');


            currentFormState.airlineName = data.visaAirlineName || currentFormState.airlineName;
            currentFormState.arrivalDateTime = data.visaArrivalDate || currentFormState.arrivalDateTime;
            currentFormState.departureDateTime = data.visaDepartureDate || currentFormState.departureDateTime;
        }
        
        let pax = 0;
        if (order.serviceType === ServiceType.HOTEL) {
            const hotelD = order.data as HotelBookingData;
            if (hotelD.visaPax && hotelD.visaPax > 0) pax = hotelD.visaPax;
            else if (hotelD.handlingPax && hotelD.handlingPax > 0) pax = hotelD.handlingPax;
        } else if (order.serviceType === ServiceType.VISA) {
            pax = (order.data as VisaBookingData).pax || 0;
        } else if (order.serviceType === ServiceType.HANDLING) {
            pax = (order.data as HandlingBookingData).pax || 0;
        }
        currentFormState.paxCount = pax > 0 ? pax : currentFormState.paxCount;
        
        if (currentFormState.busRoutes && currentFormState.busRoutes.length > 0) {
            currentFormState.busRoutes = currentFormState.busRoutes.map(route => {
                let vehicleDetails = route.vehicleDetails || '';
                if (route.routeVehicleId) {
                    const foundVehicle = availableVehicles.find(v => v.id === route.routeVehicleId);
                    if (foundVehicle) {
                        vehicleDetails = `${foundVehicle.name} (${foundVehicle.plateNumber}) - Driver: ${foundVehicle.driverName || '-'}`;
                    }
                }
                return { ...route, vehicleDetails }; 
            });
        } else {
            currentFormState.busRoutes = []; 
        }
        
        const isManualMutowif = !!(currentFormState.mutowifName && !MOCK_MUTOWIFS.find(m => m.name === currentFormState.mutowifName));
        setShowManualMutowifInput(isManualMutowif);

        setPackageInfoForm(currentFormState);
    }
    setIsEditingPackageInfo(true);
};


  const handleSavePackageInfo = async () => { 
    if (!orderId || !packageInfoForm) return;
    setIsSubmitting(true);
    try {
        const packageDataToSave = { ...packageInfoForm };
        if (packageDataToSave.madinahHotelStructured && packageDataToSave.madinahHotelStructured.name) {
            packageDataToSave.madinahHotelInfo = formatHotelToStringForPackageInfo(packageDataToSave.madinahHotelStructured);
        } else {
            packageDataToSave.madinahHotelInfo = ''; 
        }
        if (packageDataToSave.makkahHotelStructured && packageDataToSave.makkahHotelStructured.name) {
            packageDataToSave.makkahHotelInfo = formatHotelToStringForPackageInfo(packageDataToSave.makkahHotelStructured);
        } else {
             packageDataToSave.makkahHotelInfo = ''; 
        }

        const updatedOrder = await updatePackageInfo(orderId, packageDataToSave);
        if (updatedOrder) {
            setOrder(updatedOrder);
            setIsEditingPackageInfo(false);
            alert("Informasi paket berhasil disimpan/diperbarui.");
            await fetchOrderDetails(false); 
        }
    } catch (err) {
        setError("Gagal menyimpan informasi paket.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };
  
  const handlePaymentFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => { 
    const { name, value } = e.target;
     if (name === "destinationBankDetails") {
        const selectedAccount = adminBankAccounts.find(acc => acc.id === value);
        setPaymentForm(prev => ({ 
            ...prev, 
            destinationBankName: selectedAccount?.bankName || '',
            destinationAccountNumber: selectedAccount?.accountNumber || ''
        }));
    } else {
        setPaymentForm(prev => ({ ...prev, [name]: name === 'amount' ? parseFloat(value) || 0 : value }));
    }
  };

  const handlePaymentProofFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg'];
      const maxSize = 2 * 1024 * 1024; // 2MB

      if (!allowedTypes.includes(file.type)) {
        alert('Format file tidak didukung. Harap unggah PDF, PNG, atau JPG.');
        setSelectedPaymentProofFile(null);
        e.target.value = ''; 
        return;
      }
      if (file.size > maxSize) {
        alert('Ukuran file terlalu besar. Maksimal 2MB.');
        setSelectedPaymentProofFile(null);
        e.target.value = ''; 
        return;
      }
      setSelectedPaymentProofFile(file);
    } else {
      setSelectedPaymentProofFile(null);
    }
  };


  const handleAddPayment = async (e: React.FormEvent) => { 
    e.preventDefault();
    if (!orderId || !adminAuthUserId) {
        alert("Autentikasi gagal. Silakan login kembali.");
        return;
    }
    if (paymentForm.amount <= 0) {
        alert("Jumlah pembayaran (IDR) harus lebih dari 0.");
        return;
    }
    if (paymentForm.paymentMethod === 'Transfer' && (!paymentForm.destinationBankName || !paymentForm.senderAccountName || !paymentForm.senderAccountNumber)) {
        alert("Untuk metode Transfer, Nama Pentransfer, Bank Tujuan, dan No. Rekening Pengirim wajib diisi.");
        return;
    }

    setIsSubmitting(true);
    try {
        const updatedOrder = await addPaymentToOrder(orderId, paymentForm, selectedPaymentProofFile || undefined);
        if (updatedOrder) {
            setOrder(updatedOrder);
            setShowPaymentForm(false);
            setPaymentForm(initialPaymentForm(adminAuthUserId));
            setSelectedPaymentProofFile(null); 
            alert("Pembayaran berhasil ditambahkan.");
            const customer = await getAuthUserInfo(updatedOrder.userId);
            if (customer?.phone) {
                let messageToCustomer = `Admin telah mencatat pembayaran Anda untuk Pesanan ID: ${orderId.substring(0,8)} sejumlah ${formatCurrency(paymentForm.amount, 'IDR')} (${paymentForm.paymentType}).`;
                sendNotificationToCustomer(customer.phone, messageToCustomer);
            }
            fetchOrderDetails(false); // Refresh order details
        }
    } catch (err) {
        setError("Gagal menambahkan pembayaran.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };
  const handleDeletePayment = async (paymentId: string) => { 
    if (!orderId || !window.confirm("Yakin ingin menghapus pembayaran ini?")) return;
    setIsSubmitting(true);
    try {
        const updatedOrder = await deletePaymentFromOrder(orderId, paymentId);
        if (updatedOrder) {
            setOrder(updatedOrder);
            alert("Pembayaran berhasil dihapus.");
            fetchOrderDetails(false); // Refresh order details
        }
    } catch (err) {
        setError("Gagal menghapus pembayaran.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };
  
  const handlePaymentApproval = async (paymentId: string, status: 'Approved' | 'Rejected') => {
    if (!orderId || !adminAuthUserId) return;
    
    const notes = status === 'Rejected' ? prompt("Masukkan alasan penolakan (opsional):") : '';
    if (status === 'Rejected' && notes === null) return; // User cancelled prompt

    setIsSubmitting(true);
    try {
        const updatedOrder = await updatePaymentApprovalStatus(orderId, paymentId, status, adminAuthUserId, notes || undefined);
        if (updatedOrder) {
            setOrder(updatedOrder);
            alert(`Pembayaran berhasil di-${status === 'Approved' ? 'konfirmasi' : 'tolak'}.`);
            
            const customer = await getAuthUserInfo(updatedOrder.userId);
            if(customer?.phone) {
                const payment = updatedOrder.payments?.find(p => p.id === paymentId);
                let message = `Pembayaran Anda sejumlah ${formatCurrency(payment?.amount || 0, 'IDR')} untuk pesanan ${orderId.substring(0,8)} telah `;
                if(status === 'Approved') message += `DISETUJUI.`;
                else message += `DITOLAK. ${notes ? `Alasan: ${notes}` : 'Silakan hubungi admin untuk info lebih lanjut.'}`;
                sendNotificationToCustomer(customer.phone, message);
            }
            fetchOrderDetails(false); // Refresh order details
        }
    } catch (err) {
        setError("Gagal memperbarui status pembayaran.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };
  
  const handleOpenChatModal = async () => {
    if (!order) return;
    setShowChatModal(true);
    setIsLoadingChatMessages(true);
    try {
        const messages = await getChatMessagesForOrder(order.id);
        setChatMessages(messages);
    } catch (error) {
        console.error("Failed to load chat messages:", error);
        setChatMessages([]); 
    } finally {
        setIsLoadingChatMessages(false);
    }
  };

  const handleAdminSendChatMessage = async (text?: string, file?: File) => {
    if (!order || (!text && !file) || !currentUser) return; // Added !currentUser check
    setIsSendingChatMessage(true);
    try {
        const newMessage = await sendChatMessage(order.id, currentUser.name, currentUser.id, text, file);
        if (newMessage) {
            setChatMessages(prev => [...prev, newMessage]);
             const customer = await getAuthUserInfo(order.userId);
             if(customer?.phone) {
                 sendNotificationToCustomer(customer.phone, `Admin mengirim pesan baru untuk Order ID ${order.id.substring(0,8)}: "${text || 'File terlampir'}"`);
             }
        }
    } catch (err: any) {
        console.error("Failed to send chat message:", err);
        setError("Gagal mengirim pesan chat: " + err.message);
    } finally {
        setIsSendingChatMessage(false);
    }
  };

  const handleViewPaymentProof = (payment: Payment) => {
    if (payment.paymentProofFileDataUrl && payment.paymentProofFileType?.startsWith('image/')) {
        const imageWindow = window.open();
        if (imageWindow) {
            imageWindow.document.write(`<body style="margin:0; background: #222;"><img src="${payment.paymentProofFileDataUrl}" style="display:block; margin: auto; max-width:100%; max-height:100vh; object-fit:contain;" alt="Bukti Pembayaran: ${payment.paymentProofFileName || 'image'}"/></body>`);
            imageWindow.document.title = payment.paymentProofFileName || 'Bukti Pembayaran';
        }
    } else if (payment.paymentProofFileName) {
        // Simulate download for non-image or large files
        const fileName = payment.paymentProofFileName;
        const fileType = payment.paymentProofFileType || 'application/octet-stream';
        const mockContent = `Ini adalah simulasi unduhan untuk file: ${fileName}\nTipe file: ${fileType}\nURL Data (jika ada dan ini bukan gambar atau terlalu besar): ${payment.paymentProofFileDataUrl ? 'Ada Data URL (tidak ditampilkan di sini)' : 'Tidak ada Data URL yang dapat ditampilkan langsung'}\n\nDalam aplikasi nyata, ini akan menjadi file ${fileName} yang sebenarnya.`;
        const blob = new Blob([mockContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `mock_download_EWAKO_${fileName.replace(/[^a-zA-Z0-9.]/g, '_')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        alert(`Simulasi unduh untuk: ${fileName}. Sebuah file teks akan diunduh.`);
    } else {
        alert("Tidak ada file bukti pembayaran yang dapat ditampilkan atau diunduh.");
    }
  };

  const renderPaymentHistory = () => {
    const totalApprovedPayments = (order?.payments || [])
        .filter(p => p.paymentApprovalStatus === 'Approved')
        .reduce((sum, p) => sum + p.amount, 0);
    
    let sisaPembayaranText = "Harga total paket belum ditetapkan.";
    if (order?.totalPrice && order.totalPrice > 0) {
        const sisa = order.totalPrice - totalApprovedPayments;
        if (sisa <= 0) {
            sisaPembayaranText = "LUNAS SEPENUHNYA";
        } else {
            sisaPembayaranText = `${formatCurrency(sisa, 'IDR')}`;
        }
    }

    return (
      <>
        {(order?.payments || []).length === 0 && <p className="text-sm text-indigo-200">Belum ada pembayaran tercatat.</p>}
        <ul className="space-y-3">
            {(order?.payments || []).map(payment => (
                <li key={payment.id} className="p-3 bg-black/10 rounded-md text-xs relative">
                    <div className="flex justify-between items-start mb-1">
                        <p className="font-semibold text-indigo-100">{payment.paymentType} - {formatCurrency(payment.amount, 'IDR')}</p>
                        <span className={`px-1.5 py-0.5 rounded-full border backdrop-blur-sm text-[10px] ${getPaymentApprovalStatusPillStyle(payment.paymentApprovalStatus)}`}>
                            {mapPaymentApprovalStatusToText(payment.paymentApprovalStatus)}
                        </span>
                    </div>
                    <p><strong className="text-indigo-300">Tanggal:</strong> {formatDateForDisplay(payment.paymentDate)}</p>
                    <p><strong className="text-indigo-300">Metode:</strong> {payment.paymentMethod} {payment.paymentGatewayType ? `(${payment.paymentGatewayType})` : ''}</p>
                    {payment.notes && <p><strong className="text-indigo-300">Catatan Pelanggan:</strong> {payment.notes}</p>}
                    {(payment.senderAccountName || payment.destinationBankName) && (
                         <div className="mt-1 pt-1 border-t border-white/10 text-[10px]">
                            {payment.senderAccountName && <p><strong className="text-indigo-300">Pengirim:</strong> {payment.senderAccountName} ({payment.senderBankName} - {payment.senderAccountNumber}) via {payment.senderTransferMethod || 'N/A'}</p>}
                            {payment.destinationBankName && <p><strong className="text-indigo-300">Ke Rekening:</strong> {payment.destinationBankName} - {payment.destinationAccountNumber}</p>}
                        </div>
                    )}
                     {payment.adminActionNotes && <p className="italic text-indigo-300 mt-0.5">Catatan Admin: {payment.adminActionNotes}</p>}
                     {payment.approvedByUserId && <p className="text-[10px] text-indigo-400">Diproses oleh: {payment.approvedByUserId.substring(0,8)}... pada {formatDateTimeForDisplay(payment.approvedAt || payment.rejectedAt)}</p>}

                    <div className="absolute top-2 right-2 flex space-x-1">
                        {payment.paymentProofFileName && <Button variant="outline" size="sm" onClick={() => handleViewPaymentProof(payment)} className="!p-1 !text-[10px]"><EyeIcon className="h-3 w-3"/></Button>}
                        <Button variant="danger" size="sm" onClick={() => handleDeletePayment(payment.id)} className="!p-1 !text-[10px]" isLoading={isSubmitting}><TrashIcon className="h-3 w-3"/></Button>
                    </div>
                    {payment.paymentApprovalStatus === 'Pending' && (
                        <div className="mt-2 pt-2 border-t border-white/15 flex space-x-2">
                            <Button onClick={() => handlePaymentApproval(payment.id, 'Approved')} variant="primary" size="sm" className="!text-xs !py-0.5" isLoading={isSubmitting}><CheckCircleIcon className="h-3.5 w-3.5 mr-1"/> Setujui</Button>
                            <Button onClick={() => handlePaymentApproval(payment.id, 'Rejected')} variant="danger" size="sm" className="!text-xs !py-0.5" isLoading={isSubmitting}><XCircleIcon className="h-3.5 w-3.5 mr-1"/> Tolak</Button>
                        </div>
                    )}
                </li>
            ))}
        </ul>
         {order?.totalPrice && (order.payments || []).length > 0 && (
            <div className="mt-4 pt-3 border-t border-white/15">
                <p className="text-sm font-semibold text-indigo-100">
                    Total Harga Paket: <span className="metallic-gold-text">{formatCurrency(order.totalPrice, 'IDR')}</span>
                </p>
                 <p className="text-sm font-semibold text-indigo-100">
                    Total Pembayaran Disetujui: <span className="text-green-300">{formatCurrency(totalApprovedPayments, 'IDR')}</span>
                </p>
                <p className="text-md font-bold text-white mt-1">
                    Sisa Pembayaran: <span className="metallic-gold-text">{sisaPembayaranText}</span>
                </p>
            </div>
        )}
      </>
    );
  };


  if (isLoading && !order) return <Layout><div className="flex justify-center items-center h-64"><LoadingSpinner /></div></Layout>;
  if (error && !order) return <Layout><p className="text-red-300 bg-red-700/50 backdrop-blur-sm p-4 rounded-lg text-center">{error}</p></Layout>;
  if (!order) return <Layout><p className="text-indigo-200 text-center">Detail pesanan tidak ditemukan.</p></Layout>;

  const data = order.data as any; 

  const renderHotelInfoBlock = (hotelInfo: HotelInfo | undefined, city: string) => {
    if (!hotelInfo || !hotelInfo.name) {
      return (
        <div className="py-1">
          <p className="text-indigo-200"><strong className="text-indigo-100">{city}:</strong> Tidak ada data hotel.</p>
        </div>
      );
    }
    const roomDetailsArray: string[] = [];
    if (hotelInfo.rooms.quad > 0) roomDetailsArray.push(`Quad(${hotelInfo.rooms.quad})`);
    if (hotelInfo.rooms.triple > 0) roomDetailsArray.push(`Triple(${hotelInfo.rooms.triple})`);
    if (hotelInfo.rooms.double > 0) roomDetailsArray.push(`Double(${hotelInfo.rooms.double})`);
    const roomText = roomDetailsArray.length > 0 ? roomDetailsArray.join(', ') : 'Tidak ada rincian kamar';

    return (
      <div className="py-1 mb-2 last:mb-0 last:border-b-0 border-b border-white/10 pb-2">
        <p className="font-semibold text-white">{city}: {hotelInfo.name}</p>
        <div className="pl-4 mt-1 space-y-0.5 text-sm">
            <p className="text-indigo-200"><strong className="text-indigo-100">Kamar:</strong> {roomText}</p>
            <p className="text-indigo-200"><strong className="text-indigo-100">Durasi:</strong> {hotelInfo.nights} malam</p>
            <p className="text-indigo-200"><strong className="text-indigo-100">Check In:</strong> {formatDateForDisplay(hotelInfo.checkIn)}</p>
            <p className="text-indigo-200"><strong className="text-indigo-100">Check Out:</strong> {formatDateForDisplay(hotelInfo.checkOut)}</p>
        </div>
      </div>
    );
  };

  // Main return statement for AdminOrderDetailsPage
  return (
    <Layout>
      {/* Chat Modal */}
      {showChatModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[70]">
            <Card title={`Chat untuk Order ID: ${order.id.substring(0,8)}`} className="generic-card-glass w-full max-w-lg h-[70vh] flex flex-col">
                <div className="absolute top-3 right-3">
                    <Button onClick={() => setShowChatModal(false)} variant="danger" size="sm" className="!p-1.5">X</Button>
                </div>
                <div className="flex-grow overflow-y-auto p-4 space-y-2 bg-black/10 backdrop-blur-sm rounded-t-md">
                    {isLoadingChatMessages ? <LoadingSpinner/> :
                        chatMessages.length === 0 ? <p className="text-indigo-300 text-center">Belum ada pesan.</p> :
                        chatMessages.map(msg => <ChatMessageBubble key={msg.id} message={msg} currentUserId={adminAuthUserId!} />) 
                    }
                    <div ref={chatMessagesEndRef} />
                </div>
                <ChatInput onSendMessage={handleAdminSendChatMessage} isLoading={isSendingChatMessage} />
            </Card>
        </div>
      )}

      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
            <button onClick={() => navigate('/admin/orders')} className="mr-4 p-2 rounded-full hover:bg-white/15 transition-colors" aria-label="Kembali ke Kelola Pesanan">
            <ArrowLeftIcon className="h-6 w-6 text-white" />
            </button>
            <h1 className="text-2xl font-bold metallic-gold-text">Admin Detail Pesanan</h1>
        </div>
        <div className="space-x-2">
          <Button onClick={handleOpenChatModal} variant="outline" size="sm" icon={<ChatBubbleLeftEllipsisIcon className="h-5 w-5 mr-1" />}>
            Chat
          </Button>
          <Button onClick={() => navigate(`/admin/orders/${orderId}/handling-reports`)} variant="outline" size="sm" icon={<ArchiveBoxIcon className="h-5 w-5 mr-1" />}>
            Laporan Handling
          </Button>
        </div>
      </div>

      <Card title={`Order ID: ${order.id.substring(0,12)}...`} className="mb-6 generic-card-glass">
        {/* Basic Order Info Display */}
        <dl className="divide-y divide-white/15">
            <div className="py-2 sm:grid sm:grid-cols-3 sm:gap-4"><dt className="text-sm font-medium text-indigo-300">Jenis Layanan</dt><dd className="mt-1 text-sm text-indigo-100 sm:mt-0 sm:col-span-2">{order.serviceType}</dd></div>
            <div className="py-2 sm:grid sm:grid-cols-3 sm:gap-4"><dt className="text-sm font-medium text-indigo-300">Pemesan</dt><dd className="mt-1 text-sm text-indigo-100 sm:mt-0 sm:col-span-2">{data.customerName}</dd></div>
            <div className="py-2 sm:grid sm:grid-cols-3 sm:gap-4"><dt className="text-sm font-medium text-indigo-300">No. HP Pemesan</dt><dd className="mt-1 text-sm text-indigo-100 sm:mt-0 sm:col-span-2">{data.phone}</dd></div>
            <div className="py-2 sm:grid sm:grid-cols-3 sm:gap-4"><dt className="text-sm font-medium text-indigo-300">Total Harga Paket</dt><dd className="mt-1 text-sm text-indigo-100 sm:mt-0 sm:col-span-2">{order.totalPrice ? formatCurrency(order.totalPrice, 'IDR') : 'Belum ditetapkan'}</dd></div>
            
            {order.serviceType === ServiceType.HOTEL && (
                <>
                {renderHotelInfoBlock((data as HotelBookingData).madinahHotel, "Madinah")}
                {renderHotelInfoBlock((data as HotelBookingData).makkahHotel, "Mekah")}
                </>
            )}
             {/* TODO: Display details for other service types if needed */}
        </dl>
      </Card>

      {/* Status Update Section */}
      <Card title="Update Status Pesanan" className="mb-6 generic-card-glass">
        <div className="flex items-center space-x-3">
          <Select label="Status Baru:" options={statusOptions} value={selectedStatus} onChange={(e) => setSelectedStatus(e.target.value as OrderStatus)} className="flex-grow"/>
          <Button onClick={handleStatusUpdate} isLoading={isSubmitting} variant="primary" className="self-end">Update Status</Button>
        </div>
      </Card>

      {/* Price Setting Section */}
      {order.serviceType !== ServiceType.JASTIP && ( 
      <Card title="Atur Harga & Detail (SAR/USD)" className="mb-6 generic-card-glass">
        <form onSubmit={(e) => {e.preventDefault(); handleAdminSavePriceAndDetails();}} className="space-y-3">
            
            {order.serviceType === ServiceType.HOTEL && (<>
                <h4 className="text-md font-semibold text-indigo-100 mt-2">Harga Hotel Madinah (SAR/malam/kamar)</h4>
                <div className="grid grid-cols-3 gap-2">
                    <Input label="Quad" name="madinahHotelRoomPricesSAR.quad" type="number" value={adminPriceInputs.madinahHotelRoomPricesSAR.quad} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
                    <Input label="Triple" name="madinahHotelRoomPricesSAR.triple" type="number" value={adminPriceInputs.madinahHotelRoomPricesSAR.triple} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
                    <Input label="Double" name="madinahHotelRoomPricesSAR.double" type="number" value={adminPriceInputs.madinahHotelRoomPricesSAR.double} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
                </div>
                <h4 className="text-md font-semibold text-indigo-100 mt-2">Harga Hotel Mekah (SAR/malam/kamar)</h4>
                 <div className="grid grid-cols-3 gap-2">
                    <Input label="Quad" name="makkahHotelRoomPricesSAR.quad" type="number" value={adminPriceInputs.makkahHotelRoomPricesSAR.quad} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
                    <Input label="Triple" name="makkahHotelRoomPricesSAR.triple" type="number" value={adminPriceInputs.makkahHotelRoomPricesSAR.triple} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
                    <Input label="Double" name="makkahHotelRoomPricesSAR.double" type="number" value={adminPriceInputs.makkahHotelRoomPricesSAR.double} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
                </div>
            </>)}
            {(order.serviceType === ServiceType.HOTEL || order.serviceType === ServiceType.VISA) && ((order.data as HotelBookingData).includeVisa || order.serviceType === ServiceType.VISA) && (<>
                <Input label="Harga Visa per Pax (USD)" name="visaPricePerPaxUSD" type="number" value={adminPriceInputs.visaPricePerPaxUSD} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
                <Input label="Nama Muasasah (Visa)" name="muasasahName" value={adminPriceInputs.muasasahName} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
            </>)}
            {(order.serviceType === ServiceType.HOTEL || order.serviceType === ServiceType.HANDLING) && ((order.data as HotelBookingData).includeHandling || order.serviceType === ServiceType.HANDLING) && (
                <Input label="Harga Handling per Pax (SAR)" name="handlingPricePerPaxSAR" type="number" value={adminPriceInputs.handlingPricePerPaxSAR} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
            )}
             {(order.serviceType === ServiceType.HOTEL || order.serviceType === ServiceType.VISA) && (
                <Input label="Total Harga Bus (SAR)" name="busPriceTotalSAR" type="number" value={adminPriceInputs.busPriceTotalSAR} onChange={(e) => handleAdminPriceInputChange(e.target.name, e.target.value)} />
            )}
            
            <div className="mt-3 pt-3 border-t border-white/15 text-sm space-y-1">
                <p className="font-bold text-indigo-100">Estimasi Kalkulasi Harga:</p>
                <p>Madinah: {formatCurrency(calculatedSubTotals.madinahHotel.subtotalSAR.total, 'SAR')} ({formatCurrency(calculatedSubTotals.madinahHotel.subtotalIDR.total, 'IDR')})</p>
                <p>Mekah: {formatCurrency(calculatedSubTotals.makkahHotel.subtotalSAR.total, 'SAR')} ({formatCurrency(calculatedSubTotals.makkahHotel.subtotalIDR.total, 'IDR')})</p>
                <p>Visa: {formatCurrency(calculatedSubTotals.visa.amountUSD, 'USD')} ({formatCurrency(calculatedSubTotals.visa.amountIDR, 'IDR')})</p>
                <p>Handling: {formatCurrency(calculatedSubTotals.handling.amountSAR, 'SAR')} ({formatCurrency(calculatedSubTotals.handling.amountIDR, 'IDR')})</p>
                <p>Bus: {formatCurrency(calculatedSubTotals.bus.amountSAR, 'SAR')} ({formatCurrency(calculatedSubTotals.bus.amountIDR, 'IDR')})</p>
                <p className="font-bold metallic-gold-text">Grand Total (IDR): {formatCurrency(calculatedSubTotals.summary.grandTotalIDR, 'IDR')}</p>
                <p className="text-xs text-indigo-300">Kurs: 1 USD = {formatCurrency(MOCK_EXCHANGE_RATES.USD_TO_IDR, 'IDR')}, 1 SAR = {formatCurrency(MOCK_EXCHANGE_RATES.SAR_TO_IDR, 'IDR')}</p>
            </div>
            <Button type="submit" variant="primary" isLoading={isSubmitting}>Simpan Harga & Detail</Button>
        </form>
      </Card>
      )}
      
      {/* Package Info Section */}
      {isEditingPackageInfo ? (
          // Simplified renderPackageInfoEditForm for brevity
          <Card title="Edit Informasi Paket" className="my-6 generic-card-glass">
            <form className="space-y-4 p-4" onSubmit={(e) => { e.preventDefault(); handleSavePackageInfo(); }}>
                 <Input label="Nama PPIU/PIHK" name="ppiuName" value={packageInfoForm.ppiuName} onChange={handlePackageInfoFormChange} />
                 {/* ... More fields would go here in a full implementation ... */}
                 <div className="flex justify-end space-x-2 pt-2">
                    <Button type="button" variant="outline" onClick={() => setIsEditingPackageInfo(false)} disabled={isSubmitting}>Batal</Button>
                    <Button type="submit" variant="primary" isLoading={isSubmitting}>Simpan Info Paket</Button>
                </div>
            </form>
          </Card>
      ) : (
        <div className="mb-6 mt-6">
            <PackageInfoDisplay packageInfo={order.packageInfo} />
            <Button onClick={handleEditPackageInfoClick} variant="outline" className="mt-4">
                {order.packageInfo ? 'Ubah' : 'Lengkapi'} Info Paket
            </Button>
        </div>
      )}

      {/* Payment Management Section */}
      <Card title="Kelola Pembayaran" className="mb-6 generic-card-glass">
        {renderPaymentHistory()}
        <Button onClick={() => setShowPaymentForm(true)} variant="primary" size="sm" className="mt-4">
          <PlusCircleIcon className="h-5 w-5 mr-1"/> Tambah Pembayaran Manual
        </Button>
        {showPaymentForm && (
            <form onSubmit={handleAddPayment} className="mt-4 space-y-3 p-3 border-t border-white/15">
                <h4 className="text-md font-semibold text-indigo-100">Form Tambah Pembayaran</h4>
                <Input label="Jumlah (IDR)" name="amount" type="number" value={String(paymentForm.amount)} onChange={handlePaymentFormChange} required/>
                <Input label="Tanggal Pembayaran" name="paymentDate" type="date" value={paymentForm.paymentDate} onChange={handlePaymentFormChange} required/>
                <Select label="Jenis Pembayaran" name="paymentType" value={paymentForm.paymentType} onChange={handlePaymentFormChange} options={paymentTypeOptions} />
                <Select label="Metode Pembayaran" name="paymentMethod" value={paymentForm.paymentMethod} onChange={handlePaymentFormChange} options={paymentMethodOptions} />
                
                {paymentForm.paymentMethod === 'Transfer' && (
                    <>
                        <Input label="Nama Pentransfer (Jika beda dengan pemesan)" name="senderAccountName" value={paymentForm.senderAccountName || ''} onChange={handlePaymentFormChange} />
                        <Input label="No. Rekening Pengirim (Opsional)" name="senderAccountNumber" value={paymentForm.senderAccountNumber || ''} onChange={handlePaymentFormChange} />
                         <Input label="Nama Bank Pengirim (Opsional)" name="senderBankName" value={paymentForm.senderBankName || ''} onChange={handlePaymentFormChange} />
                         <Select label="Transfer Dilakukan Via (Opsional)" name="senderTransferMethod" value={paymentForm.senderTransferMethod || ''} onChange={handlePaymentFormChange} options={SENDER_TRANSFER_METHODS} />
                        <Select label="Bank Tujuan (Admin)" name="destinationBankDetails" 
                            options={[{value: '', label: 'Pilih Rekening Tujuan Admin'}, ...adminBankAccounts.map(acc => ({value: acc.id, label: `${acc.bankName} - ${acc.accountNumber} (A/N: ${acc.accountHolderName})`}))]} 
                            onChange={handlePaymentFormChange} 
                        />
                        <div>
                            <label htmlFor="adminPaymentProofFile" className="block text-xs font-medium text-gray-200 mb-1">Unggah Bukti Transfer (Opsional)</label>
                            <input type="file" id="adminPaymentProofFile" onChange={handlePaymentProofFileChange} accept=".pdf,.png,.jpg,.jpeg" className="block w-full text-xs text-indigo-200 file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-indigo-500/30 file:text-indigo-100 hover:file:bg-indigo-600/40"/>
                            {selectedPaymentProofFile && <p className="text-[10px] text-indigo-200 mt-1">File: {selectedPaymentProofFile.name}</p>}
                        </div>
                    </>
                )}
                <Textarea label="Catatan Admin" name="notes" value={paymentForm.notes || ''} onChange={handlePaymentFormChange} />
                <div className="flex space-x-2">
                    <Button type="submit" variant="primary" isLoading={isSubmitting}>Simpan Pembayaran</Button>
                    <Button type="button" variant="outline" onClick={() => setShowPaymentForm(false)}>Batal</Button>
                </div>
            </form>
        )}
      </Card>

      {/* PDF Downloads */}
      <Card title="Dokumen Pesanan" className="generic-card-glass">
        <div className="flex flex-wrap gap-2">
            <Button onClick={() => generateOrderRequestPdf(order)} variant="secondary" size="sm">Surat Permintaan (PDF)</Button>
            {order.totalPrice && <Button onClick={() => generateInvoicePdf(order)} variant="secondary" size="sm">Invoice (PDF)</Button>}
            {order.packageInfo && <Button onClick={() => generatePackageInfoPdf(order)} variant="secondary" size="sm">Info Paket (PDF)</Button>}
            {order.manifest && order.manifest.length > 0 && <Button onClick={() => generateManifestPdf(order)} variant="secondary" size="sm">Manifest (PDF)</Button>}
        </div>
      </Card>

    </Layout>
  );
};
export default AdminOrderDetailsPage;
