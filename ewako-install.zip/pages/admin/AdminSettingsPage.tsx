import React, { useState, useEffect, useCallback } from 'react';
import { Layout } from '../../components/Layout';
import { Card } from '../../components/ui/Card';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Select';
import { ArrowLeftIcon, PlusCircleIcon, PencilIcon, TrashIcon } from '@heroicons/react/24/outline';
import { useNavigate } from 'react-router-dom';
import { AdminManagedBankAccount } from '../../types';
import { getAdminBankAccounts, addAdminBankAccount, updateAdminBankAccount, deleteAdminBankAccount } from '../../services/adminSettingsService'; 
import { INDONESIAN_BANK_LIST } from '../../constants';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';

const initialBankAccountForm: Omit<AdminManagedBankAccount, 'id' | 'logoUrl' | 'bankCode'> = {
  bankName: '',
  accountNumber: '',
  accountHolderName: '',
  branchName: '',
};

const AdminSettingsPage: React.FC = () => {
  const navigate = useNavigate();
  const [adminBankAccounts, setAdminBankAccounts] = useState<AdminManagedBankAccount[]>([]);
  const [isLoadingAccounts, setIsLoadingAccounts] = useState(true);
  
  const [showBankAccountForm, setShowBankAccountForm] = useState(false);
  const [editingBankAccount, setEditingBankAccount] = useState<AdminManagedBankAccount | null>(null);
  const [bankAccountForm, setBankAccountForm] = useState<Omit<AdminManagedBankAccount, 'id' | 'logoUrl' | 'bankCode'>>(initialBankAccountForm);
  const [isSubmittingAccount, setIsSubmittingAccount] = useState(false);
  
  const [midtransApiKey, setMidtransApiKey] = useState('MIDTRANS_SERVER_KEY_ANDA'); // Placeholder

  const fetchBankAccounts = useCallback(async () => {
    setIsLoadingAccounts(true);
    try {
      const accounts = await getAdminBankAccounts();
      setAdminBankAccounts(accounts);
    } catch (error) {
      console.error("Error fetching admin bank accounts:", error);
      // Handle error display if necessary
    } finally {
      setIsLoadingAccounts(false);
    }
  }, []);

  useEffect(() => {
    fetchBankAccounts();
  }, [fetchBankAccounts]);

  const handleOpenBankAccountForm = (account?: AdminManagedBankAccount) => {
    if (account) {
      setEditingBankAccount(account);
      const { id, logoUrl, bankCode, ...formData } = account;
      setBankAccountForm(formData);
    } else {
      setEditingBankAccount(null);
      setBankAccountForm(initialBankAccountForm);
    }
    setShowBankAccountForm(true);
  };

  const handleCloseBankAccountForm = () => {
    setShowBankAccountForm(false);
    setEditingBankAccount(null);
    setBankAccountForm(initialBankAccountForm);
  };

  const handleBankAccountFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setBankAccountForm({ ...bankAccountForm, [e.target.name]: e.target.value });
  };

  const handleSaveBankAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bankAccountForm.bankName || !bankAccountForm.accountNumber || !bankAccountForm.accountHolderName) {
      alert("Nama Bank, Nomor Rekening, dan Atas Nama wajib diisi.");
      return;
    }
    setIsSubmittingAccount(true);
    const selectedBankData = INDONESIAN_BANK_LIST.find(b => b.name === bankAccountForm.bankName);
    const accountDataToSend: Omit<AdminManagedBankAccount, 'id'> = {
        ...bankAccountForm,
        bankCode: selectedBankData?.code,
        logoUrl: selectedBankData?.logoUrl,
    };

    try {
      if (editingBankAccount) {
        await updateAdminBankAccount(editingBankAccount.id, accountDataToSend);
      } else {
        await addAdminBankAccount(accountDataToSend);
      }
      await fetchBankAccounts(); // Refresh list
      handleCloseBankAccountForm();
    } catch (err) {
      console.error("Failed to save bank account:", err);
      alert("Gagal menyimpan rekening bank.");
    } finally {
      setIsSubmittingAccount(false);
    }
  };

  const handleDeleteBankAccount = async (accountId: string) => {
    if (window.confirm("Apakah Anda yakin ingin menghapus rekening bank ini?")) {
      setIsSubmittingAccount(true); // Use same loading state or a dedicated one
      try {
        await deleteAdminBankAccount(accountId);
        await fetchBankAccounts(); // Refresh list
      } catch (err) {
        console.error("Failed to delete bank account:", err);
        alert("Gagal menghapus rekening bank.");
      } finally {
        setIsSubmittingAccount(false);
      }
    }
  };
  
  const handleSaveMidtransKey = () => {
      // In a real app, this would save to a secure backend.
      // For mock, it just alerts.
      alert(`Kunci API Midtrans (mock) akan disimpan: ${midtransApiKey}`);
      // Potentially store in localStorage for mock persistence if needed, but not secure.
  };


  return (
    <Layout>
      <div className="flex items-center mb-6">
        <button onClick={() => navigate('/admin')} className="mr-4 p-2 rounded-full hover:bg-white/15 transition-colors"> {/* Adjusted hover */}
          <ArrowLeftIcon className="h-6 w-6 text-white" />
        </button>
        <h1 className="text-2xl font-bold metallic-gold-text">Pengaturan Admin</h1>
      </div>

      <Card title="Rekening Bank Perusahaan" className="mb-6 generic-card-glass">
        <Button onClick={() => handleOpenBankAccountForm()} variant="primary" size="sm" className="mb-4">
          <PlusCircleIcon className="h-5 w-5 mr-2" /> Tambah Rekening Bank
        </Button>
        {isLoadingAccounts ? (
          <LoadingSpinner />
        ) : adminBankAccounts.length === 0 ? (
          <p className="text-indigo-200">Belum ada rekening bank ditambahkan.</p>
        ) : (
          <div className="space-y-3">
            {adminBankAccounts.map(account => (
              <div key={account.id} className="p-3 bg-black/10 rounded-md text-sm"> {/* Subtle bg for glass */}
                <div className="flex justify-between items-start">
                  <div>
                    {account.logoUrl && <img src={account.logoUrl} alt={`${account.bankName} logo`} className="h-6 mb-1"/>}
                    <p className="font-semibold text-indigo-100">{account.bankName}</p>
                    <p className="text-indigo-200">No. Rek: {account.accountNumber}</p>
                    <p className="text-indigo-200">A/N: {account.accountHolderName}</p>
                    {account.branchName && <p className="text-indigo-200">Cabang: {account.branchName}</p>}
                  </div>
                  <div className="flex space-x-2 flex-shrink-0">
                    <Button variant="outline" size="sm" onClick={() => handleOpenBankAccountForm(account)} className="!p-1.5">
                      <PencilIcon className="h-4 w-4"/>
                    </Button>
                    <Button variant="danger" size="sm" onClick={() => handleDeleteBankAccount(account.id)} className="!p-1.5">
                      <TrashIcon className="h-4 w-4"/>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {showBankAccountForm && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
          <Card title={editingBankAccount ? "Edit Rekening Bank" : "Tambah Rekening Bank"} className="generic-card-glass w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <form onSubmit={handleSaveBankAccount} className="space-y-3">
              <Select 
                label="Nama Bank*" 
                name="bankName" 
                options={[{value: '', label: 'Pilih Bank'}, ...INDONESIAN_BANK_LIST.map(b => ({value: b.name, label: b.name}))]}
                value={bankAccountForm.bankName} 
                onChange={handleBankAccountFormChange} 
                required 
              />
              <Input label="Nomor Rekening*" name="accountNumber" value={bankAccountForm.accountNumber} onChange={handleBankAccountFormChange} required />
              <Input label="Atas Nama (Pemilik Rekening)*" name="accountHolderName" value={bankAccountForm.accountHolderName} onChange={handleBankAccountFormChange} required />
              <Input label="Nama Cabang Bank (Opsional)" name="branchName" value={bankAccountForm.branchName || ''} onChange={handleBankAccountFormChange} />
              <div className="flex justify-end space-x-2 pt-2">
                <Button type="button" variant="outline" onClick={handleCloseBankAccountForm} disabled={isSubmittingAccount}>Batal</Button>
                <Button type="submit" variant="primary" isLoading={isSubmittingAccount}>
                  {editingBankAccount ? "Update Rekening" : "Simpan Rekening"}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      )}
      
      <Card title="Integrasi Midtrans (Contoh)" className="mb-6 generic-card-glass">
        <p className="text-sm text-indigo-200 mb-2">Pengaturan ini bersifat placeholder dan tidak akan menyimpan data secara permanen dalam versi mock ini.</p>
        <Input 
            label="Server Key Midtrans" 
            name="midtransApiKey" 
            value={midtransApiKey} 
            onChange={(e) => setMidtransApiKey(e.target.value)} 
            type="password"
            placeholder="Masukkan Server Key Midtrans Anda"
        />
        <Button onClick={handleSaveMidtransKey} variant="secondary" className="mt-3">
            Simpan Kunci Midtrans (Mock)
        </Button>
      </Card>

    </Layout>
  );
};

export default AdminSettingsPage;
