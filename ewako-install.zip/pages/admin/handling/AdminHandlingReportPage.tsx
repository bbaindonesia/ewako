
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { Layout } from '../../../components/Layout';
import { Card } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';
import { Input } from '../../../components/ui/Input';
import { Textarea } from '../../../components/ui/Textarea';
import { Select } from '../../../components/ui/Select';
import { LoadingSpinner } from '../../../components/ui/LoadingSpinner';
import { 
    Order, User, ManifestItem, HandlingReport, 
    HandlingArrivalReportDataSpecifics, 
    HandlingHotelCheckInReportDataSpecifics, 
    HandlingActivityReportDataSpecifics, 
    HandlingDepartureReportDataSpecifics,
    HandlingReportJemaahHealth,
    BusCondition, JemaahCondition, HotelInfo, HotelAvailabilityStatus,
    HotelRoomCountStatus, BaggageDistributionStatus, YesNoStatus, HotelBookingData,
    ReportDataSpecificsType, 
    AddHandlingReportServicePayload 
} from '../../../types';
import { getOrderById, addHandlingReport } from '../../../services/orderService';
import { getUsers } from '../../../services/userService';
import { useAuth } from '../../../App';
import { ArrowLeftIcon, PrinterIcon, PlusCircleIcon, TrashIcon } from '@heroicons/react/24/outline';
import { 
    generateHandlingArrivalReportPdf, 
    generateHandlingHotelCheckInReportPdf, 
    generateHandlingActivityReportPdf, 
    generateHandlingDepartureReportPdf 
} from '../../../services/pdfService';

type ActiveReportType = 'Arrival' | 'HotelCheckIn' | 'Activity' | 'Departure';
const REPORT_SEQUENCE: ActiveReportType[] = ['Arrival', 'HotelCheckIn', 'Activity', 'Departure'];

// Initial states for *Specifics types (do NOT include petugasPJId/Name)
const initialArrivalReportDataSpecifics: HandlingArrivalReportDataSpecifics = {
  waktuKedatanganJemaah: '', namaMaskapai: '', terminalKedatangan: '', namaMutowif: '',
  namaTourGuideLeader: '', transportasiNamaBus: '', transportasiNomorSeriBus: '',
  transportasiNoDriver: '', transportasiKondisiBus: '', bagasiKoper: 0, bagasiTasKabin: 0,
  bagasiLain: '', absensiJemaah: {}, kondisiJemaahUmum: 'Baik', jemaahSakitDetails: [],
  waktuKeberangkatanDariAirport: '',
};

const initialHotelCheckInReportDataSpecifics: HandlingHotelCheckInReportDataSpecifics = {
  lokasiHotel: '', namaHotel: '', tanggalCheckInOut: '', durasi: '', jumlahKamarByTipe: '',
  ketersediaanKunci: '', alasanKunciBelumTersedia: '', ketersediaanJumlahKamar: '',
  alasanKamarBelumSesuai: '', solusiKamarBelumSesuai: '', bagasiKoperUlang: 0,
  bagasiTasKabinUlang: 0, bagasiLainUlang: '', distribusiBagasi: '',
  nomorKamarBagasiBelumTerdistribusi: '',
};

const initialActivityReportDataSpecifics: HandlingActivityReportDataSpecifics = {
  namaKegiatan: '', transportasiNamaBus: '', transportasiNomorSeriBus: '',
  transportasiNoDriver: '', transportasiKondisiBus: '', absensiJemaahKeberangkatan: {},
  tujuanKegiatan: [], kondisiJemaahUmum: 'Baik', jemaahSakitDetails: [],
  waktuKembaliDariKegiatan: '', rangkumanPerjalanan: '',
};

const initialDepartureReportDataSpecifics: HandlingDepartureReportDataSpecifics = {
  bagasiKoperAkhir: 0, bagasiTasKabinAkhir: 0, bagasiLainAkhir: '', absensiJemaahCheckout: {},
  kondisiJemaahUmumCheckout: 'Baik', jemaahSakitDetailsCheckout: [], waktuCheckoutHotel: '',
  transportasiNamaBusKeAirport: '', transportasiNomorSeriBusKeAirport: '',
  transportasiNoDriverKeAirport: '', adaCityTourTambahan: '', tujuanCityTourTambahan: '',
  waktuKedatanganDiAirportPulang: '', namaAirportTerminalPulang: '',
  catatanProsesCheckInCounter: '', catatanProsesPembagianTiket: '', catatanProsesBoarding: '',
};


const busConditionOptions: { value: BusCondition | '', label: string }[] = [
    { value: '', label: 'Pilih Kondisi' }, { value: 'Bagus', label: 'Bagus' },
    { value: 'Standar', label: 'Standar' }, { value: 'Jelek', label: 'Jelek' },
];
const jemaahConditionOptions: { value: JemaahCondition | '', label: string }[] = [
    { value: '', label: 'Pilih Kondisi'}, { value: 'Baik', label: 'Baik' }, { value: 'Sakit', label: 'Sakit' },
];
const hotelAvailabilityStatusOptions: { value: HotelAvailabilityStatus | '', label: string }[] = [
    { value: '', label: 'Pilih Status' }, { value: 'Tersedia', label: 'Tersedia' },
    { value: 'Belum Tersedia', label: 'Belum Tersedia' },
];
const hotelRoomCountStatusOptions: { value: HotelRoomCountStatus | '', label: string }[] = [
    { value: '', label: 'Pilih Status' }, { value: 'Sesuai', label: 'Sesuai' },
    { value: 'Belum Sesuai', label: 'Belum Sesuai' },
];
const baggageDistributionStatusOptions: { value: BaggageDistributionStatus | '', label: string }[] = [
    { value: '', label: 'Pilih Status' }, { value: 'Sudah', label: 'Sudah Terdistribusi' },
    { value: 'Belum', label: 'Belum Terdistribusi' },
];
const yesNoOptions: { value: YesNoStatus | '', label: string }[] = [
    { value: '', label: 'Pilih Opsi' }, { value: 'Ya', label: 'Ya' }, { value: 'Tidak', label: 'Tidak' },
];
const hotelLocationOptions: { value: 'Mekah' | 'Madinah' | '', label: string}[] = [
    {value: '', label: 'Pilih Lokasi Hotel'},
    {value: 'Madinah', label: 'Madinah'},
    {value: 'Mekah', label: 'Mekah'},
]

const formatDateForDisplay = (dateString?: string): string => {
    if (!dateString) return '';
    const date = new Date(dateString.split('T')[0]); // Pastikan hanya bagian tanggal yang di-parse
    if (isNaN(date.getTime())) return ''; // Cek apakah tanggal valid
    return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
};

type ReportDataType = ReportDataSpecificsType; // Alias for clarity in this component

const AdminHandlingReportPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { userId: adminUserId } = useAuth(); // Renamed for clarity

  const [order, setOrder] = useState<Order | null>(null);
  const [handlingStaff, setHandlingStaff] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [activeReportType, setActiveReportType] = useState<ActiveReportType>(REPORT_SEQUENCE[0]);
  
  // State for report-specific data (without PJ info)
  const [currentReportSpecifics, setCurrentReportSpecifics] = useState<ReportDataSpecificsType>(initialArrivalReportDataSpecifics);
  
  // States for PJ info (common to all reports)
  const [petugasPJId, setPetugasPJId] = useState<string>('');
  const [petugasPJName, setPetugasPJName] = useState<string>('');

  const [existingReports, setExistingReports] = useState<HandlingReport[]>([]);


  const getInitialSpecificsForReportType = useCallback((type: ActiveReportType, currentOrder?: Order, currentLokasiHotel?: 'Mekah' | 'Madinah' | ''): ReportDataSpecificsType => {
    const packageInfo = currentOrder?.packageInfo;
    let hotelDataForCheckIn: HotelBookingData | null = null;
    if (currentOrder?.serviceType === 'Hotel') { // Check serviceType before casting
        hotelDataForCheckIn = currentOrder.data as HotelBookingData;
    }

    switch(type) {
        case 'Arrival': 
            return {
                ...initialArrivalReportDataSpecifics,
                namaMaskapai: packageInfo?.airlineName || '',
                terminalKedatangan: packageInfo?.arrivalTerminal || '',
                namaMutowif: packageInfo?.mutowifName || '',
                namaTourGuideLeader: packageInfo?.tourLeaderName || '',
                transportasiNamaBus: packageInfo?.busName || '',
                transportasiNomorSeriBus: packageInfo?.busSyarikahNumber || '',
                transportasiNoDriver: packageInfo?.busDriverPhone || '',
                waktuKedatanganJemaah: packageInfo?.arrivalDateTime || new Date().toISOString().slice(0,16),
            };
        case 'HotelCheckIn':
            let hotelNameForCheckIn = '';
            let checkInOutForCheckIn = '';
            let durationForCheckIn = '';
            let roomTypesForCheckIn = '';
            const lokasiHotel = currentLokasiHotel || ''; // Use passed in, or default

            const targetHotelPackage = lokasiHotel === 'Madinah' ? packageInfo?.madinahHotelStructured : packageInfo?.makkahHotelStructured;
            const targetHotelBooking = lokasiHotel === 'Madinah' ? hotelDataForCheckIn?.madinahHotel : hotelDataForCheckIn?.makkahHotel;
            const hotelToUse = targetHotelPackage?.name ? targetHotelPackage : (targetHotelBooking?.name ? targetHotelBooking : undefined);
            
            if (hotelToUse?.name) {
                hotelNameForCheckIn = hotelToUse.name;
                checkInOutForCheckIn = `${formatDateForDisplay(hotelToUse.checkIn)} - ${formatDateForDisplay(hotelToUse.checkOut)}`;
                durationForCheckIn = `${hotelToUse.nights} malam`;
                const rooms: string[] = [];
                if (hotelToUse.rooms.quad > 0) rooms.push(`${hotelToUse.rooms.quad} Quad`);
                if (hotelToUse.rooms.triple > 0) rooms.push(`${hotelToUse.rooms.triple} Triple`);
                if (hotelToUse.rooms.double > 0) rooms.push(`${hotelToUse.rooms.double} Double`);
                roomTypesForCheckIn = rooms.join(', ') || 'N/A';
            }
            return {
                ...initialHotelCheckInReportDataSpecifics,
                lokasiHotel: lokasiHotel,
                namaHotel: hotelNameForCheckIn,
                tanggalCheckInOut: checkInOutForCheckIn,
                durasi: durationForCheckIn,
                jumlahKamarByTipe: roomTypesForCheckIn,
            };
        case 'Activity':
            return {
                ...initialActivityReportDataSpecifics,
                transportasiNamaBus: packageInfo?.busName || '',
                transportasiNomorSeriBus: packageInfo?.busSyarikahNumber || '',
                transportasiNoDriver: packageInfo?.busDriverPhone || '',
            };
        case 'Departure':
            return {
                ...initialDepartureReportDataSpecifics,
                transportasiNamaBusKeAirport: packageInfo?.busName || '',
                transportasiNomorSeriBusKeAirport: packageInfo?.busSyarikahNumber || '',
                transportasiNoDriverKeAirport: packageInfo?.busDriverPhone || '',
                namaAirportTerminalPulang: packageInfo?.departureTerminal || '',
            };
        default: return {} as ReportDataSpecificsType; // Should not happen
    }
  }, []);

  const fetchOrderAndStaff = useCallback(async () => {
    if (!orderId) {
      setError("Order ID tidak valid.");
      setIsLoading(false);
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const fetchedOrder = await getOrderById(orderId);
      if (!fetchedOrder) {
        setError("Pesanan tidak ditemukan.");
        setIsLoading(false);
        return;
      }
      setOrder(fetchedOrder);
      const reportsFromServer = fetchedOrder.handlingReports || [];
      setExistingReports(reportsFromServer);

      const staffUsers = await getUsers(['admin', 'tim_staff']);
      setHandlingStaff(staffUsers);
      
      const currentLoggedInStaff = staffUsers.find(s => s.id === adminUserId);
      const initialPetugasId = adminUserId || (staffUsers.length > 0 ? staffUsers[0].id : '');
      const initialPetugasName = currentLoggedInStaff?.name || (staffUsers.length > 0 ? staffUsers[0].name : '');
      
      const currentActiveReportExists = reportsFromServer.find(r => r.reportType === activeReportType);
      if (currentActiveReportExists) {
        setCurrentReportSpecifics(currentActiveReportExists.data as ReportDataSpecificsType); 
        setPetugasPJId(currentActiveReportExists.petugasPJId); 
        setPetugasPJName(currentActiveReportExists.petugasPJName || ''); 
      } else {
        setPetugasPJId(initialPetugasId);
        setPetugasPJName(initialPetugasName);

        let lokasiHotelToPreserve : 'Mekah' | 'Madinah' | '' = '';
        if (activeReportType === 'HotelCheckIn' && currentReportSpecifics && 'lokasiHotel' in currentReportSpecifics) {
            lokasiHotelToPreserve = (currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).lokasiHotel;
        }
        const defaultReportSpecifics = getInitialSpecificsForReportType(activeReportType, fetchedOrder, lokasiHotelToPreserve);
        setCurrentReportSpecifics(defaultReportSpecifics);
      }

    } catch (err) {
      setError("Gagal memuat data pesanan atau staff.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [orderId, adminUserId, activeReportType, getInitialSpecificsForReportType]); 

  useEffect(() => {
    fetchOrderAndStaff();
  }, [fetchOrderAndStaff]);
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setCurrentReportSpecifics((prev: ReportDataSpecificsType) => {
        let newValue: string | number | boolean = type === 'checkbox' ? checked : value;
        if (type === 'number') {
          newValue = parseFloat(value);
          if (isNaN(newValue as number)) newValue = 0;
        }
        
        if (name === 'lokasiHotel' && activeReportType === 'HotelCheckIn') {
            const newInitialSpecifics = getInitialSpecificsForReportType('HotelCheckIn', order || undefined, newValue as 'Mekah' | 'Madinah' | '');
            return { 
              ...newInitialSpecifics, 
            };
        }
        return { ...prev, [name]: newValue } as ReportDataSpecificsType;
    });
  };

  const handleAbsensiChange = (jemaahId: string, isPresent: boolean, reportType: 'Arrival' | 'Activity' | 'Departure') => {
    setCurrentReportSpecifics((prev: ReportDataSpecificsType) => {
      const absensiField = reportType === 'Arrival' ? 'absensiJemaah' : 
                           reportType === 'Activity' ? 'absensiJemaahKeberangkatan' : 
                           'absensiJemaahCheckout';
      return {
        ...prev,
        [absensiField]: {
          ...((prev as any)[absensiField] || {}),
          [jemaahId]: isPresent,
        },
      } as ReportDataSpecificsType;
    });
  };

  const handleJemaahSakitChange = (id: string, field: keyof Omit<HandlingReportJemaahHealth, 'id'>, value: string, reportType: 'Arrival' | 'Activity' | 'Departure') => {
    setCurrentReportSpecifics((prev: ReportDataSpecificsType) => {
      const jemaahSakitField = reportType === 'Departure' ? 'jemaahSakitDetailsCheckout' : 'jemaahSakitDetails';
      const updatedDetails = [...((prev as any)[jemaahSakitField] || [])];
      const detailIndex = updatedDetails.findIndex((d: HandlingReportJemaahHealth) => d.id === id);

      if (detailIndex > -1) {
        updatedDetails[detailIndex] = { ...updatedDetails[detailIndex], [field]: value };
      }
      return { ...prev, [jemaahSakitField]: updatedDetails } as ReportDataSpecificsType;
    });
  };

  const handleAddJemaahSakit = (reportType: 'Arrival' | 'Activity' | 'Departure') => {
    setCurrentReportSpecifics((prev: ReportDataSpecificsType) => {
      const jemaahSakitField = reportType === 'Departure' ? 'jemaahSakitDetailsCheckout' : 'jemaahSakitDetails';
      const existingDetails = (prev as any)[jemaahSakitField] || [];
      return {
        ...prev,
        [jemaahSakitField]: [
          ...existingDetails,
          { 
            id: uuidv4(),
            jemaahId: '', 
            namaJemaah: '',
            nomorPaspor: '',
            keluhan: '' 
          }
        ]
      } as ReportDataSpecificsType;
    });
  };

  const handleRemoveJemaahSakit = (id: string, reportType: 'Arrival' | 'Activity' | 'Departure') => {
    setCurrentReportSpecifics((prev: ReportDataSpecificsType) => {
      const jemaahSakitField = reportType === 'Departure' ? 'jemaahSakitDetailsCheckout' : 'jemaahSakitDetails';
      return {
        ...prev,
        [jemaahSakitField]: ((prev as any)[jemaahSakitField] || []).filter((d: HandlingReportJemaahHealth) => d.id !== id)
      } as ReportDataSpecificsType;
    });
  };

  const handlePetugasChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedStaff = handlingStaff.find(s => s.id === e.target.value);
    setPetugasPJId(e.target.value);
    setPetugasPJName(selectedStaff?.name || '');
  };

  const handleSubmitReport = async () => {
    if (!orderId || !adminUserId || !currentReportSpecifics) return;
    if (!petugasPJId) {
        alert("Petugas Penanggung Jawab wajib dipilih.");
        return;
    }
    setIsSubmitting(true);
    try {
      const payloadForService: AddHandlingReportServicePayload = {
        reportType: activeReportType,
        createdByUserId: adminUserId,
        petugasPJId: petugasPJId,
        petugasPJName: petugasPJName,
        data: currentReportSpecifics,
      };
      await addHandlingReport(orderId, payloadForService);
      alert(`Laporan ${activeReportType} berhasil disimpan.`);
      await fetchOrderAndStaff(); 
    } catch (err) {
      setError(`Gagal menyimpan laporan ${activeReportType}.`);
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSelectReportType = (type: ActiveReportType) => {
    setActiveReportType(type); // This will trigger fetchOrderAndStaff via useEffect
  };
  
  const handlePrintReport = () => {
    if (!order || !currentReportSpecifics || !petugasPJId) {
        alert("Data laporan atau petugas PJ tidak lengkap untuk dicetak.");
        return;
    }
    
    const reportToPrint: HandlingReport = {
      id: `temp_${Date.now()}`, 
      orderId: order.id,
      reportType: activeReportType,
      createdByUserId: adminUserId || 'unknown_admin', 
      petugasPJId: petugasPJId, 
      petugasPJName: petugasPJName, 
      createdAt: new Date().toISOString(), 
      data: currentReportSpecifics, 
    };

    switch (activeReportType) {
      case 'Arrival':
        generateHandlingArrivalReportPdf(order, reportToPrint);
        break;
      case 'HotelCheckIn':
        generateHandlingHotelCheckInReportPdf(order, reportToPrint);
        break;
      case 'Activity':
        generateHandlingActivityReportPdf(order, reportToPrint);
        break;
      case 'Departure':
        generateHandlingDepartureReportPdf(order, reportToPrint);
        break;
    }
  };


  const renderJemaahSakitForm = (reportType: 'Arrival' | 'Activity' | 'Departure') => {
    const jemaahSakitField = reportType === 'Departure' 
        ? 'jemaahSakitDetailsCheckout' 
        : 'jemaahSakitDetails';
    const jemaahSakitDetails = (currentReportSpecifics as any)[jemaahSakitField] as HandlingReportJemaahHealth[] | undefined;
    
    return (
      <fieldset className="border border-white/20 p-3 rounded-md mt-4">
        <legend className="text-md font-medium text-indigo-100 px-1">Detail Jemaah Sakit</legend>
        {(jemaahSakitDetails || []).map((detail, index) => (
          <div key={detail.id || index} className="mb-3 p-2 border border-dashed border-white/15 rounded relative">
            <Select
              label={`Nama Jemaah ${index + 1}`}
              value={detail.jemaahId}
              options={[{value: '', label: 'Pilih Jemaah'}, ...(order?.manifest || []).map(j => ({ value: j.id, label: `${j.namaJemaah} (Paspor: ${j.nomorPaspor})` }))]}
              onChange={(e) => {
                  const selectedJemaah = order?.manifest?.find(j => j.id === e.target.value);
                  handleJemaahSakitChange(detail.id, 'jemaahId', e.target.value, reportType);
                  handleJemaahSakitChange(detail.id, 'namaJemaah', selectedJemaah?.namaJemaah || '', reportType);
                  handleJemaahSakitChange(detail.id, 'nomorPaspor', selectedJemaah?.nomorPaspor || '', reportType);
                  handleJemaahSakitChange(detail.id, 'nomorVisa', selectedJemaah?.nomorVisa || '', reportType);
                  handleJemaahSakitChange(detail.id, 'kotaAsal', selectedJemaah?.kotaAsalKeberangkatan || selectedJemaah?.kotaTempatIssuedPaspor || '', reportType);
              }}
              aria-label={`Pilih Jemaah Sakit ${index + 1}`}
            />
            <Input label="Keluhan" value={detail.keluhan} onChange={(e) => handleJemaahSakitChange(detail.id, 'keluhan', e.target.value, reportType)} aria-label={`Keluhan Jemaah ${index + 1}`}/>
             <Button type="button" variant="danger" size="sm" onClick={() => handleRemoveJemaahSakit(detail.id, reportType)} className="!p-1 absolute top-1 right-1" aria-label={`Hapus Jemaah Sakit ${index + 1}`}>
                <TrashIcon className="h-3 w-3"/>
            </Button>
          </div>
        ))}
        <Button type="button" onClick={() => handleAddJemaahSakit(reportType)} variant="outline" size="sm">Tambah Jemaah Sakit</Button>
      </fieldset>
    );
  };
  
  const renderAbsensiForm = (reportType: 'Arrival' | 'Activity' | 'Departure') => {
    const absensiField = reportType === 'Arrival' ? 'absensiJemaah' : 
                         reportType === 'Activity' ? 'absensiJemaahKeberangkatan' : 
                         'absensiJemaahCheckout';
    const absensiData = (currentReportSpecifics as any)[absensiField] || {};

    return (
        <fieldset className="border border-white/20 p-3 rounded-md mt-4">
            <legend className="text-md font-medium text-indigo-100 px-1">Absensi Jemaah</legend>
            <div className="max-h-60 overflow-y-auto space-y-1 pr-2">
                {(order?.manifest || []).map(jemaah => (
                    <div key={jemaah.id} className="flex items-center justify-between text-sm p-1.5 bg-black/10 rounded">
                        <span className="text-indigo-100">{jemaah.namaJemaah}</span>
                        <div className="flex items-center space-x-2">
                            <label className="flex items-center space-x-1 cursor-pointer">
                                <input type="radio" name={`absensi_${jemaah.id}_${reportType}`} checked={absensiData[jemaah.id] === true} onChange={() => handleAbsensiChange(jemaah.id, true, reportType)} className="form-radio text-green-400 bg-transparent border-gray-500 focus:ring-green-400"/>
                                <span className="text-green-300">Hadir</span>
                            </label>
                            <label className="flex items-center space-x-1 cursor-pointer">
                                <input type="radio" name={`absensi_${jemaah.id}_${reportType}`} checked={absensiData[jemaah.id] === false} onChange={() => handleAbsensiChange(jemaah.id, false, reportType)} className="form-radio text-red-400 bg-transparent border-gray-500 focus:ring-red-400"/>
                                <span className="text-red-300">Tidak</span>
                            </label>
                        </div>
                    </div>
                ))}
            </div>
        </fieldset>
    );
  };


  const renderArrivalForm = () => (
    <form onSubmit={(e) => { e.preventDefault(); handleSubmitReport();}} className="space-y-3">
      <Input label="Waktu Kedatangan Aktual Jemaah" type="datetime-local" name="waktuKedatanganJemaah" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).waktuKedatanganJemaah || ''} onChange={handleInputChange} />
      <Input label="Nama Maskapai" name="namaMaskapai" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).namaMaskapai || ''} onChange={handleInputChange} />
      <Input label="Terminal Kedatangan" name="terminalKedatangan" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).terminalKedatangan || ''} onChange={handleInputChange} />
      <Input label="Nama Mutowif (Sesuai Info Paket)" name="namaMutowif" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).namaMutowif || ''} readOnly className="bg-white/5 cursor-not-allowed"/>
      <Input label="Nama Tour Guide/Leader (Sesuai Info Paket)" name="namaTourGuideLeader" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).namaTourGuideLeader || ''} readOnly className="bg-white/5 cursor-not-allowed"/>
      
      <fieldset className="border border-white/20 p-3 rounded-md mt-3">
        <legend className="text-md font-medium text-indigo-100 px-1">Transportasi dari Airport</legend>
        <Input label="Nama Bus" name="transportasiNamaBus" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).transportasiNamaBus || ''} onChange={handleInputChange} />
        <Input label="Nomor Seri Bus (Syarikah)" name="transportasiNomorSeriBus" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).transportasiNomorSeriBus || ''} onChange={handleInputChange} />
        <Input label="No. HP Driver" name="transportasiNoDriver" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).transportasiNoDriver || ''} onChange={handleInputChange} />
        <Select label="Kondisi Bus" name="transportasiKondisiBus" options={busConditionOptions} value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).transportasiKondisiBus || ''} onChange={handleInputChange} />
      </fieldset>

      <fieldset className="border border-white/20 p-3 rounded-md mt-3">
        <legend className="text-md font-medium text-indigo-100 px-1">Bagasi Jemaah</legend>
        <Input label="Jumlah Koper" type="number" name="bagasiKoper" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).bagasiKoper?.toString() || '0'} onChange={handleInputChange} />
        <Input label="Jumlah Tas Kabin" type="number" name="bagasiTasKabin" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).bagasiTasKabin?.toString() || '0'} onChange={handleInputChange} />
        <Input label="Bagasi Lain (jika ada)" name="bagasiLain" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).bagasiLain || ''} onChange={handleInputChange} />
      </fieldset>

      {renderAbsensiForm('Arrival')}
      <Select label="Kondisi Jemaah (Umum)" name="kondisiJemaahUmum" options={jemaahConditionOptions} value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).kondisiJemaahUmum || 'Baik'} onChange={handleInputChange} />
      {renderJemaahSakitForm('Arrival')}
      <Input label="Waktu Keberangkatan dari Airport" type="datetime-local" name="waktuKeberangkatanDariAirport" value={(currentReportSpecifics as HandlingArrivalReportDataSpecifics).waktuKeberangkatanDariAirport || ''} onChange={handleInputChange} />
      <Button type="submit" variant="primary" isLoading={isSubmitting}>Simpan Laporan Kedatangan</Button>
    </form>
  );

  const renderHotelCheckInForm = () => (
    <form onSubmit={(e) => { e.preventDefault(); handleSubmitReport();}} className="space-y-3">
        <Select label="Lokasi Hotel*" name="lokasiHotel" options={hotelLocationOptions} value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).lokasiHotel || ''} onChange={handleInputChange} required />
        <Input label="Nama Hotel (Info Paket)" name="namaHotel" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).namaHotel || ''} readOnly className="bg-white/5 cursor-not-allowed"/>
        <Input label="Periode Menginap (Info Paket)" name="tanggalCheckInOut" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).tanggalCheckInOut || ''} readOnly className="bg-white/5 cursor-not-allowed"/>
        <Input label="Durasi (Info Paket)" name="durasi" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).durasi || ''} readOnly className="bg-white/5 cursor-not-allowed"/>
        <Input label="Jumlah Kamar by Tipe (Info Paket)" name="jumlahKamarByTipe" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).jumlahKamarByTipe || ''} readOnly className="bg-white/5 cursor-not-allowed"/>
        
        <Select label="Ketersediaan Kunci Saat Tiba*" name="ketersediaanKunci" options={hotelAvailabilityStatusOptions} value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).ketersediaanKunci || ''} onChange={handleInputChange} required />
        {(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).ketersediaanKunci === 'Belum Tersedia' && (
            <Textarea label="Alasan Kunci Belum Tersedia" name="alasanKunciBelumTersedia" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).alasanKunciBelumTersedia || ''} onChange={handleInputChange} />
        )}
        <Select label="Ketersediaan Jumlah Kamar Sesuai Pesanan*" name="ketersediaanJumlahKamar" options={hotelRoomCountStatusOptions} value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).ketersediaanJumlahKamar || ''} onChange={handleInputChange} required />
        {(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).ketersediaanJumlahKamar === 'Belum Sesuai' && (
            <>
            <Textarea label="Alasan Jumlah Kamar Belum Sesuai" name="alasanKamarBelumSesuai" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).alasanKamarBelumSesuai || ''} onChange={handleInputChange} />
            <Textarea label="Solusi / Tindakan yang Diambil" name="solusiKamarBelumSesuai" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).solusiKamarBelumSesuai || ''} onChange={handleInputChange} />
            </>
        )}
        
        <fieldset className="border border-white/20 p-3 rounded-md mt-3">
            <legend className="text-md font-medium text-indigo-100 px-1">Bagasi Jemaah (Hitung Ulang di Hotel)</legend>
            <Input label="Jumlah Koper" type="number" name="bagasiKoperUlang" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).bagasiKoperUlang?.toString() || '0'} onChange={handleInputChange} />
            <Input label="Jumlah Tas Kabin" type="number" name="bagasiTasKabinUlang" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).bagasiTasKabinUlang?.toString() || '0'} onChange={handleInputChange} />
            <Input label="Bagasi Lain (jika ada)" name="bagasiLainUlang" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).bagasiLainUlang || ''} onChange={handleInputChange} />
        </fieldset>
        
        <Select label="Status Distribusi Bagasi ke Kamar*" name="distribusiBagasi" options={baggageDistributionStatusOptions} value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).distribusiBagasi || ''} onChange={handleInputChange} required />
        {(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).distribusiBagasi === 'Belum' && (
            <Input label="Nomor Kamar Bagasi Belum Terdistribusi (jika ada)" name="nomorKamarBagasiBelumTerdistribusi" value={(currentReportSpecifics as HandlingHotelCheckInReportDataSpecifics).nomorKamarBagasiBelumTerdistribusi || ''} onChange={handleInputChange} />
        )}
      <Button type="submit" variant="primary" isLoading={isSubmitting}>Simpan Laporan Check-in Hotel</Button>
    </form>
  );
  
  const renderActivityForm = () => (
    <form onSubmit={(e) => { e.preventDefault(); handleSubmitReport();}} className="space-y-3">
        <Input label="Nama Kegiatan (e.g., City Tour Madinah Pagi)*" name="namaKegiatan" value={(currentReportSpecifics as HandlingActivityReportDataSpecifics).namaKegiatan || ''} onChange={handleInputChange} required/>
        
        <fieldset className="border border-white/20 p-3 rounded-md mt-3">
            <legend className="text-md font-medium text-indigo-100 px-1">Transportasi Kegiatan</legend>
            <Input label="Nama Bus" name="transportasiNamaBus" value={(currentReportSpecifics as HandlingActivityReportDataSpecifics).transportasiNamaBus || ''} onChange={handleInputChange} />
            <Input label="Nomor Seri Bus (Syarikah)" name="transportasiNomorSeriBus" value={(currentReportSpecifics as HandlingActivityReportDataSpecifics).transportasiNomorSeriBus || ''} onChange={handleInputChange} />
            <Input label="No. HP Driver" name="transportasiNoDriver" value={(currentReportSpecifics as HandlingActivityReportDataSpecifics).transportasiNoDriver || ''} onChange={handleInputChange} />
            <Select label="Kondisi Bus" name="transportasiKondisiBus" options={busConditionOptions} value={(currentReportSpecifics as HandlingActivityReportDataSpecifics).transportasiKondisiBus || ''} onChange={handleInputChange} />
        </fieldset>

        {renderAbsensiForm('Activity')}
        
        <div>
            <label className="block text-sm font-medium text-indigo-100 mb-1">Tujuan Kegiatan (Pisahkan dengan koma jika lebih dari satu)</label>
            <Input 
                name="tujuanKegiatanInput" 
                value={((currentReportSpecifics as HandlingActivityReportDataSpecifics).tujuanKegiatan || []).join(', ')} 
                onChange={(e) => setCurrentReportSpecifics((prev:any) => ({...prev, tujuanKegiatan: e.target.value.split(',').map(s=>s.trim()).filter(Boolean)}))}
                placeholder="Masjid Quba, Kebun Kurma, Jabal Uhud"
            />
        </div>

        <Select label="Kondisi Jemaah (Umum Selama Kegiatan)" name="kondisiJemaahUmum" options={jemaahConditionOptions} value={(currentReportSpecifics as HandlingActivityReportDataSpecifics).kondisiJemaahUmum || 'Baik'} onChange={handleInputChange} />
        {renderJemaahSakitForm('Activity')}
        
        <Input label="Waktu Kembali dari Kegiatan" type="datetime-local" name="waktuKembaliDariKegiatan" value={(currentReportSpecifics as HandlingActivityReportDataSpecifics).waktuKembaliDariKegiatan || ''} onChange={handleInputChange} />
        <Textarea label="Rangkuman Perjalanan / Catatan Penting" name="rangkumanPerjalanan" value={(currentReportSpecifics as HandlingActivityReportDataSpecifics).rangkumanPerjalanan || ''} onChange={handleInputChange} rows={3} />

      <Button type="submit" variant="primary" isLoading={isSubmitting}>Simpan Laporan Kegiatan</Button>
    </form>
  );
  
  const renderDepartureForm = () => (
     <form onSubmit={(e) => { e.preventDefault(); handleSubmitReport();}} className="space-y-3">
        <fieldset className="border border-white/20 p-3 rounded-md mt-3">
            <legend className="text-md font-medium text-indigo-100 px-1">Bagasi Jemaah (Final Saat Kepulangan)</legend>
            <Input label="Jumlah Koper (Akhir)" type="number" name="bagasiKoperAkhir" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).bagasiKoperAkhir?.toString() || '0'} onChange={handleInputChange} />
            <Input label="Jumlah Tas Kabin (Akhir)" type="number" name="bagasiTasKabinAkhir" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).bagasiTasKabinAkhir?.toString() || '0'} onChange={handleInputChange} />
            <Input label="Bagasi Lain (Akhir, jika ada)" name="bagasiLainAkhir" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).bagasiLainAkhir || ''} onChange={handleInputChange} />
        </fieldset>

        {renderAbsensiForm('Departure')}
        <Select label="Kondisi Jemaah (Umum Saat Checkout)" name="kondisiJemaahUmumCheckout" options={jemaahConditionOptions} value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).kondisiJemaahUmumCheckout || 'Baik'} onChange={handleInputChange} />
        {renderJemaahSakitForm('Departure')}
        
        <Input label="Waktu Checkout Hotel" type="datetime-local" name="waktuCheckoutHotel" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).waktuCheckoutHotel || ''} onChange={handleInputChange} />

        <fieldset className="border border-white/20 p-3 rounded-md mt-3">
            <legend className="text-md font-medium text-indigo-100 px-1">Transportasi ke Airport</legend>
            <Input label="Nama Bus ke Airport" name="transportasiNamaBusKeAirport" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).transportasiNamaBusKeAirport || ''} onChange={handleInputChange} />
            <Input label="Nomor Seri Bus ke Airport (Syarikah)" name="transportasiNomorSeriBusKeAirport" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).transportasiNomorSeriBusKeAirport || ''} onChange={handleInputChange} />
            <Input label="No. HP Driver Bus ke Airport" name="transportasiNoDriverKeAirport" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).transportasiNoDriverKeAirport || ''} onChange={handleInputChange} />
        </fieldset>

        <Select label="Ada City Tour Tambahan Sebelum ke Airport?" name="adaCityTourTambahan" options={yesNoOptions} value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).adaCityTourTambahan || ''} onChange={handleInputChange} />
        {(currentReportSpecifics as HandlingDepartureReportDataSpecifics).adaCityTourTambahan === 'Ya' && (
            <Input label="Tujuan City Tour Tambahan" name="tujuanCityTourTambahan" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).tujuanCityTourTambahan || ''} onChange={handleInputChange} />
        )}
        
        <Input label="Waktu Kedatangan di Airport Pulang" type="datetime-local" name="waktuKedatanganDiAirportPulang" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).waktuKedatanganDiAirportPulang || ''} onChange={handleInputChange} />
        <Input label="Nama Airport & Terminal Kepulangan" name="namaAirportTerminalPulang" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).namaAirportTerminalPulang || ''} onChange={handleInputChange} />
        
        <Textarea label="Catatan Proses Check-in Counter di Airport" name="catatanProsesCheckInCounter" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).catatanProsesCheckInCounter || ''} onChange={handleInputChange} rows={2} />
        <Textarea label="Catatan Proses Pembagian Tiket & Paspor" name="catatanProsesPembagianTiket" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).catatanProsesPembagianTiket || ''} onChange={handleInputChange} rows={2} />
        <Textarea label="Catatan Proses Boarding" name="catatanProsesBoarding" value={(currentReportSpecifics as HandlingDepartureReportDataSpecifics).catatanProsesBoarding || ''} onChange={handleInputChange} rows={2} />

      <Button type="submit" variant="primary" isLoading={isSubmitting}>Simpan Laporan Kepulangan</Button>
    </form>
  );

  const renderCurrentForm = () => {
    switch (activeReportType) {
      case 'Arrival': return renderArrivalForm();
      case 'HotelCheckIn': return renderHotelCheckInForm();
      case 'Activity': return renderActivityForm();
      case 'Departure': return renderDepartureForm();
      default: return <p className="text-indigo-200">Pilih jenis laporan untuk diisi.</p>;
    }
  };

  if (isLoading) return <Layout><div className="flex justify-center items-center h-64"><LoadingSpinner /></div></Layout>;
  if (error) return <Layout><p className="text-red-300 bg-red-700/50 backdrop-blur-sm p-4 rounded-lg text-center">{error}</p></Layout>;
  if (!order) return <Layout><p className="text-indigo-200 text-center">Pesanan tidak ditemukan atau tidak dapat dimuat.</p></Layout>;

  return (
    <Layout>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
            <button onClick={() => navigate(`/admin/orders/${orderId}`)} className="mr-4 p-2 rounded-full hover:bg-white/15 transition-colors" aria-label="Kembali ke Detail Pesanan">
            <ArrowLeftIcon className="h-6 w-6 text-white" />
            </button>
            <h1 className="text-2xl font-bold metallic-gold-text">Laporan Tim Handling</h1>
        </div>
        <Button onClick={handlePrintReport} variant="outline" size="sm" icon={<PrinterIcon className="h-4 w-4 mr-1"/>}>
            Cetak Laporan Ini
        </Button>
      </div>
      <p className="text-sm text-indigo-200 mb-2">Order ID: {order.id.substring(0,10)}... | Grup: {order.packageInfo?.groupCode || 'N/A'}</p>

      <div className="mb-6 flex space-x-2 border-b border-white/15 pb-3 overflow-x-auto">
        {REPORT_SEQUENCE.map(type => (
          <Button
            key={type}
            variant={activeReportType === type ? 'primary' : 'outline'}
            onClick={() => handleSelectReportType(type)}
            size="sm"
            className={`relative whitespace-nowrap ${existingReports.find(r => r.reportType === type) ? 'after:content-["✓"] after:text-green-300 after:absolute after:-top-1 after:-right-1 after:text-xs' : ''}`}
          >
            {type.replace(/([A-Z])/g, ' $1').trim()}
          </Button>
        ))}
      </div>

      <Card title={`Formulir Laporan ${activeReportType.replace(/([A-Z])/g, ' $1').trim()}`} className="generic-card-glass">
        <div className="mb-4">
            <Select 
                label="Petugas Penanggung Jawab*" 
                name="petugasPJId" 
                options={handlingStaff.map(s => ({value: s.id, label: `${s.name} (${s.role})`}))} 
                value={petugasPJId} 
                onChange={handlePetugasChange} 
                required
                placeholder="Pilih Petugas PJ"
            />
        </div>
        {renderCurrentForm()}
      </Card>
    </Layout>
  );
};

export default AdminHandlingReportPage;
