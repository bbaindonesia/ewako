import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { User } from '../types'; // Assuming User type is defined
import * as ReactRouterDOM from 'react-router-dom';
import { getUserById, updateUser } from '../services/userService'; // Updated import
import { DEFAULT_SUPPORT_PHONE, DEFAULT_SUPPORT_EMAIL } from '../constants'; // Import default contacts
import { LoadingSpinner } from '../components/ui/LoadingSpinner';


const AccountPage: React.FC = () => {
  const navigate = ReactRouterDOM.useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<User>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);


  useEffect(() => {
    const fetchUserData = async () => {
      setIsLoading(true);
      const storedUserId = localStorage.getItem('ewakoRoyalUserId');
      if (storedUserId) {
        const fetchedUser = await getUserById(storedUserId);
        if (fetchedUser) {
          setUser(fetchedUser);
          setFormData({
            name: fetchedUser.name,
            email: fetchedUser.email,
            phone: fetchedUser.phone,
            ppiuName: fetchedUser.ppiuName,
            address: fetchedUser.address,
          });
        } else {
          localStorage.removeItem('ewakoRoyalUserId');
          localStorage.removeItem('ewakoRoyalUserRole');
          navigate('/login');
        }
      } else {
        navigate('/login'); 
      }
      setIsLoading(false);
    };
    fetchUserData();
  }, [navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setIsSubmitting(true);
    try {
      const { role, accountStatus, id, password, ...updateData } = formData as User & { password?: string };
      
      const updatedUser = await updateUser(user.id, updateData);
      if (updatedUser) {
        setUser(updatedUser); 
        setFormData({ 
             name: updatedUser.name,
             email: updatedUser.email,
             phone: updatedUser.phone,
             ppiuName: updatedUser.ppiuName,
             address: updatedUser.address,
        });
        setIsEditing(false);
        alert("Profil berhasil diperbarui.");
      } else {
        alert("Gagal memperbarui profil.");
      }
    } catch (error) {
      console.error("Error saving profile:", error);
      alert("Terjadi kesalahan saat menyimpan profil.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('ewakoRoyalUserId');
    localStorage.removeItem('ewakoRoyalUserRole');
    localStorage.removeItem('ewakoRoyalAuthToken');
    window.dispatchEvent(new CustomEvent('customAuthChange'));
    navigate('/');
    // alert("Anda telah logout."); // This can be removed for a smoother UX
  };

  if (isLoading || !user) {
    return <Layout><div className="flex justify-center items-center h-64"><LoadingSpinner /></div></Layout>;
  }
  
  const supportPhoneNumber = user.role === 'admin' && user.phone ? user.phone : DEFAULT_SUPPORT_PHONE;
  const supportEmailAddress = user.role === 'admin' && user.email ? user.email : DEFAULT_SUPPORT_EMAIL;
  const supportWhatsAppLink = `https://wa.me/${supportPhoneNumber.replace(/\D/g, '')}`;


  return (
    <Layout>
      <h1 className="text-3xl font-bold metallic-gold-text mb-8">Akun Saya</h1>
      <Card title="Profil Pengguna" className="generic-card-glass"> {/* Used generic-card-glass */}
        {!isEditing ? (
          <div className="space-y-3 text-sm">
            <p><strong className="text-indigo-300">Nama:</strong> {user.name}</p>
            <p><strong className="text-indigo-300">Email:</strong> {user.email}</p>
            <p><strong className="text-indigo-300">No. HP:</strong> {user.phone || '-'}</p>
            <p><strong className="text-indigo-300">Alamat:</strong> {user.address || '-'}</p>
            {user.role === 'customer' && <p><strong className="text-indigo-300">PPIU/PIHK:</strong> {user.ppiuName || '-'}</p>}
            <p><strong className="text-indigo-300">Role:</strong> <span className="capitalize">{user.role}</span></p>
            <p><strong>Status Akun:</strong> <span className={`font-semibold ${
                    user.accountStatus === 'active' ? 'text-green-300' :
                    user.accountStatus === 'pending_approval' ? 'text-yellow-300' :
                    user.accountStatus === 'suspended' ? 'text-red-300' : 'text-indigo-300'
                }`}>
                    {user.accountStatus?.replace('_', ' ') || 'Belum Diatur'}
            </span></p>
            <Button onClick={() => setIsEditing(true)} variant="outline" size="sm" className="mt-4">
              Ubah Profil
            </Button>
          </div>
        ) : (
          <form onSubmit={(e) => { e.preventDefault(); handleSaveProfile(); }} className="space-y-4">
            <Input label="Nama" name="name" value={formData.name || ''} onChange={handleInputChange} />
            <Input label="Email" name="email" type="email" value={formData.email || ''} onChange={handleInputChange} />
            <Input label="No. HP" name="phone" type="tel" value={formData.phone || ''} onChange={handleInputChange} />
            <Input label="Alamat" name="address" value={formData.address || ''} onChange={handleInputChange} />
            {user.role === 'customer' && <Input label="PPIU/PIHK" name="ppiuName" value={formData.ppiuName || ''} onChange={handleInputChange} />}
            <div className="flex space-x-3 mt-4">
              <Button type="submit" variant="primary" size="sm" isLoading={isSubmitting}>
                Simpan Perubahan
              </Button>
              <Button onClick={() => setIsEditing(false)} variant="outline" size="sm" disabled={isSubmitting}>
                Batal
              </Button>
            </div>
          </form>
        )}
      </Card>

      {user.role === 'admin' && (
        <Card title="Pengaturan Admin" className="mt-6 generic-card-glass"> {/* Used generic-card-glass */}
           <Button onClick={() => navigate('/admin/settings')} variant="secondary" className="w-full">
            Buka Pengaturan Admin
          </Button>
        </Card>
      )}

      <Card title="Bantuan" className="mt-8 generic-card-glass"> {/* Used generic-card-glass */}
        <p className="text-indigo-200">Butuh bantuan? Hubungi kami melalui:</p>
        <ul className="list-disc list-inside text-indigo-300 mt-2 text-sm">
            <li>WhatsApp: <a href={supportWhatsAppLink} target="_blank" rel="noopener noreferrer" className="metallic-gold-text hover:opacity-80 underline">{supportPhoneNumber}</a></li>
            <li>Email: <a href={`mailto:${supportEmailAddress}`} className="metallic-gold-text hover:opacity-80 underline">{supportEmailAddress}</a></li>
        </ul>
      </Card>

       <div className="mt-8 text-center">
        <Button onClick={handleLogout} variant="danger" size="md">
          Logout
        </Button>
      </div>
    </Layout>
  );
};

export default AccountPage;
