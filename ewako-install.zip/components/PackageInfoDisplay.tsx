
import React from 'react';
import { PackageInfoData, HotelInfo, RoomBooking, ZiarahRouteItem } from '../types'; 
import { Card } from './ui/Card';

// Define the props for PackageInfoDisplay
interface PackageInfoDisplayProps {
  packageInfo: PackageInfoData | null | undefined;
}

const formatDate = (dateString?: string): string => {
    if (!dateString) return '-';
    const datePart = dateString.split('T')[0]; 
    const date = new Date(datePart);
    // Check if date is valid, considering "0000-00-00" or similar invalid inputs from date pickers
    if (isNaN(date.getTime()) || date.getFullYear() < 1000) return '-'; 
    return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
};

const formatTimeForDisplay = (timeString?: string): string => {
    if (!timeString) return '-';
    return timeString;
};

const formatDateTime = (dateTimeString?: string): string | { date: string, time: string } => {
    if (!dateTimeString) return '-';
    const date = new Date(dateTimeString);
    if (isNaN(date.getTime()) || date.getFullYear() < 1000) return '-';
    return {
        date: date.toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' }),
        time: date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    };
};


interface DetailItemProps {
  label: string;
  value?: string | number | { date: string; time: string } | React.ReactElement;
  isTableValue?: boolean;
}

const DetailItem: React.FC<DetailItemProps> = ({ label, value, isTableValue = false }) => {
  let displayValue: React.ReactNode;

  if (value === null || value === undefined) {
    displayValue = '-';
  } else if (React.isValidElement(value)) { 
    displayValue = value;
  } else if (typeof value === 'string' || typeof value === 'number') { 
    displayValue = value;
  } else if (typeof value === 'object' && 'date' in value && 'time' in value) { 
    displayValue = `${value.date}, Pukul ${value.time}`;
  } else {
    console.warn("DetailItem received an unexpected value type:", value);
    displayValue = '-';
  }
  
  if (typeof displayValue === 'string' && displayValue.trim() === '') {
    displayValue = '-';
  }
  
  if (isTableValue) {
      return <td className="px-3 py-2 text-sm text-indigo-100 align-top">{displayValue}</td>;
  }
  return (
    <div className="py-2 sm:grid sm:grid-cols-3 sm:gap-4 border-b border-white/15 last:border-b-0">
      <dt className="text-sm font-medium text-indigo-300">{label}</dt>
      <dd className="mt-1 text-sm text-indigo-100 sm:mt-0 sm:col-span-2 whitespace-pre-wrap">{displayValue}</dd>
    </div>
  );
};

const parseHotelInfoString = (infoString?: string): Partial<HotelInfo & { originalString: string }> => {
    if (!infoString) return { originalString: '-' };
    const result: Partial<HotelInfo & { originalString: string }> = { originalString: infoString };
    
    const nameMatch = infoString.match(/^([^,(]+)/);
    if (nameMatch) result.name = nameMatch[1].trim();

    const roomsMatch = infoString.match(/Kamar: ([^)]+)/);
    if (roomsMatch && roomsMatch[1]) {
        const roomDetails = roomsMatch[1].split(',').map(r => r.trim());
        const rooms: RoomBooking = { quad: 0, triple: 0, double: 0};
        roomDetails.forEach(detail => {
            const quadMatch = detail.match(/Quad\((\d+)\)/);
            if (quadMatch) rooms.quad = parseInt(quadMatch[1]);
            const tripleMatch = detail.match(/Triple\((\d+)\)/);
            if (tripleMatch) rooms.triple = parseInt(tripleMatch[1]);
            const doubleMatch = detail.match(/Double\((\d+)\)/);
            if (doubleMatch) rooms.double = parseInt(doubleMatch[1]);
        });
        result.rooms = rooms;
    }
    
    const nightsMatch = infoString.match(/(\d+)\s*malam/);
    if (nightsMatch) result.nights = parseInt(nightsMatch[1]);

    const checkInMatch = infoString.match(/CheckIn: ([^,]+)/);
    if (checkInMatch) result.checkIn = checkInMatch[1].trim(); 

    const checkOutMatch = infoString.match(/CheckOut: ([^,]+)/);
    if (checkOutMatch) result.checkOut = checkOutMatch[1].trim(); 

    return result;
};


interface RenderHotelDetailsOptions {
  hotelInfoString?: string;
  structuredHotelInfo?: HotelInfo;
  title?: string;
}

const renderHotelDetails = ({ hotelInfoString, structuredHotelInfo, title }: RenderHotelDetailsOptions): React.ReactNode => {
    let hotelName: string | undefined;
    let hotelNights: number | undefined;
    let hotelRooms: RoomBooking | undefined;
    let hotelCheckIn: string | undefined;
    let hotelCheckOut: string | undefined;
    let originalStringToDisplay: string | undefined;

    if (structuredHotelInfo && structuredHotelInfo.name) {
        hotelName = structuredHotelInfo.name;
        hotelNights = structuredHotelInfo.nights;
        hotelRooms = structuredHotelInfo.rooms;
        hotelCheckIn = structuredHotelInfo.checkIn ? formatDate(structuredHotelInfo.checkIn) : undefined;
        hotelCheckOut = structuredHotelInfo.checkOut ? formatDate(structuredHotelInfo.checkOut) : undefined;
    } else if (hotelInfoString && hotelInfoString.trim() !== '-' && hotelInfoString.trim() !== '') {
        const parsed = parseHotelInfoString(hotelInfoString);
        if (parsed.name) {
            hotelName = parsed.name;
            hotelNights = parsed.nights;
            hotelRooms = parsed.rooms;
            hotelCheckIn = parsed.checkIn; 
            hotelCheckOut = parsed.checkOut; 
        } else {
            originalStringToDisplay = hotelInfoString;
        }
    }

    if (!hotelName && !originalStringToDisplay) {
      return <DetailItem label={title || "Info Hotel"} value="Tidak ada/Belum diatur" />;
    }
    
    if (!hotelName && originalStringToDisplay) {
        return (
            <div className="py-2">
                {title && <dt className="text-sm font-medium text-indigo-300 mb-1">{title}</dt>}
                <dd className="mt-1 text-sm text-indigo-100 sm:mt-0 pl-0">
                    {originalStringToDisplay}
                </dd>
            </div>
        );
    }

    const rooms = hotelRooms || { quad: 0, triple: 0, double: 0 };

    return (
        <div className="py-2">
            {title && <dt className="text-sm font-medium text-indigo-300 mb-1">{title}</dt>}
            <dd className="mt-1 text-sm text-indigo-100 sm:mt-0 space-y-1 pl-0">
                <table className="min-w-full text-left text-sm">
                    <tbody className="divide-y divide-white/15">
                        {hotelName && <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Nama Hotel:</td><td className="py-1">{hotelName}</td></tr>}
                        { (rooms.quad > 0 || rooms.triple > 0 || rooms.double > 0) && (
                            <tr>
                                <td className="font-medium text-indigo-200 py-1 pr-2 align-top">Kamar:</td>
                                <td className="py-1">
                                    {rooms.quad > 0 && <div>Quad: {rooms.quad} unit</div>}
                                    {rooms.triple > 0 && <div>Triple: {rooms.triple} unit</div>}
                                    {rooms.double > 0 && <div>Double: {rooms.double} unit</div>}
                                </td>
                            </tr>
                        )}
                        {hotelNights && <tr><td className="font-medium text-indigo-200 py-1 pr-2">Durasi:</td><td className="py-1">{hotelNights} malam</td></tr>}
                        {hotelCheckIn && <tr><td className="font-medium text-indigo-200 py-1 pr-2">Check-In:</td><td className="py-1">{hotelCheckIn}</td></tr>}
                        {hotelCheckOut && <tr><td className="font-medium text-indigo-200 py-1 pr-2">Check-Out:</td><td className="py-1">{hotelCheckOut}</td></tr>}
                    </tbody>
                </table>
            </dd>
        </div>
    );
};


export const PackageInfoDisplay: React.FC<PackageInfoDisplayProps> = ({ packageInfo }) => {
  if (!packageInfo) {
    return (
      <Card title="Informasi Paket" className="generic-card-glass">
        <p className="text-indigo-200">Informasi paket belum tersedia untuk pesanan ini.</p>
      </Card>
    );
  }
  
  const arrivalInfoRaw: string | { date: string; time: string } | null = packageInfo.arrivalDateTime ? formatDateTime(packageInfo.arrivalDateTime) : null;
  const departureInfoRaw: string | { date: string; time: string } | null = packageInfo.departureDateTime ? formatDateTime(packageInfo.departureDateTime) : null;

  const arrivalInfoValue: string = arrivalInfoRaw && typeof arrivalInfoRaw === 'object'
    ? `${arrivalInfoRaw.date}, Pukul ${arrivalInfoRaw.time}`
    : (typeof arrivalInfoRaw === 'string' ? arrivalInfoRaw : '-');
  const departureInfoValue: string = departureInfoRaw && typeof departureInfoRaw === 'object'
    ? `${departureInfoRaw.date}, Pukul ${departureInfoRaw.time}`
    : (typeof departureInfoRaw === 'string' ? departureInfoRaw : '-');
  
  const tanggalPelaksanaan = (arrivalInfoRaw && departureInfoRaw && typeof arrivalInfoRaw === 'object' && typeof departureInfoRaw === 'object')
    ? `${arrivalInfoRaw.date} - ${departureInfoRaw.date}`
    : 'Belum Ditentukan';


  return (
    <Card title="Detail Paket Info" className="generic-card-glass">
      <dl className="divide-y divide-white/15">
        <DetailItem label="Kode Grup" value={packageInfo.groupCode || '-'} />
        <DetailItem label="Nama PPIU/PIHK" value={packageInfo.ppiuName} />
        <DetailItem label="No. Telpon PPIU" value={packageInfo.ppiuPhone} />
        <DetailItem label="Jumlah Jemaah (Pax)" value={packageInfo.paxCount} />
        <DetailItem label="Periode Pelaksanaan" value={tanggalPelaksanaan} />

        {renderHotelDetails({ hotelInfoString: packageInfo.madinahHotelInfo, structuredHotelInfo: packageInfo.madinahHotelStructured, title: "Hotel Madinah" })}
        {renderHotelDetails({ hotelInfoString: packageInfo.makkahHotelInfo, structuredHotelInfo: packageInfo.makkahHotelStructured, title: "Hotel Mekah" })}
        
        <div className="py-2 border-b border-white/15">
            <dt className="text-sm font-medium text-indigo-300 mb-1">Transportasi Bus Utama</dt>
            <dd className="mt-1 text-sm text-indigo-100 sm:mt-0">
                 <table className="min-w-full text-left text-sm">
                     <tbody className="divide-y divide-white/15">
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Nama Bus:</td><td className="py-1">{packageInfo.busName || '-'}</td></tr>
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Jenis Kendaraan:</td><td className="py-1">{packageInfo.busVehicleType || '-'}</td></tr>
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Nama Driver:</td><td className="py-1">{packageInfo.busDriverName || '-'}</td></tr>
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">No. HP Driver:</td><td className="py-1">{packageInfo.busDriverPhone || '-'}</td></tr>
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Nomor Syarikah:</td><td className="py-1">{packageInfo.busSyarikahNumber || '-'}</td></tr>
                     </tbody>
                 </table>
            </dd>
        </div>

        {packageInfo.busRoutes && packageInfo.busRoutes.length > 0 && (
          <div className="py-2 border-b border-white/15">
            <dt className="text-sm font-medium text-indigo-300 mb-2">Rute Perjalanan Bus</dt>
            <dd className="mt-1 text-sm text-indigo-100 sm:mt-0">
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-sm table-fixed">
                  <thead className="bg-white/5">
                    <tr>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-1/12">Hari Ke-</th>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-3/12">Tanggal</th>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-4/12">Rute (Dari - Tujuan)</th>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-4/12">Kendaraan Rute</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {packageInfo.busRoutes.map((route, index) => (
                      <tr key={index}>
                        <DetailItem label="" value={index + 1} isTableValue={true} />
                        <DetailItem label="" value={formatDate(route.date)} isTableValue={true} />
                        <DetailItem label="" value={`${route.from || '-'} → ${route.to || '-'}`} isTableValue={true} />
                        <DetailItem label="" value={route.vehicleDetails || 'Belum diatur'} isTableValue={true} />
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </dd>
          </div>
        )}

        {packageInfo.ziarahRoutes && packageInfo.ziarahRoutes.length > 0 && (
          <div className="py-2 border-b border-white/15">
            <dt className="text-sm font-medium text-indigo-300 mb-2">Rute Ziarah / City Tour</dt>
            <dd className="mt-1 text-sm text-indigo-100 sm:mt-0">
              <div className="overflow-x-auto">
                <table className="min-w-full text-left text-sm table-fixed">
                  <thead className="bg-white/5">
                    <tr>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-3/12">Tujuan</th>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-2/12">Kota</th>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-2/12">Tanggal</th>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-2/12">Waktu</th>
                      <th className="px-3 py-2 font-medium text-indigo-200 w-3/12">Jenis</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/10">
                    {packageInfo.ziarahRoutes.map((route) => (
                      <tr key={route.id}>
                        <DetailItem label="" value={route.tujuan || '-'} isTableValue={true} />
                        <DetailItem label="" value={route.kota || '-'} isTableValue={true} />
                        <DetailItem label="" value={formatDate(route.tanggal)} isTableValue={true} />
                        <DetailItem label="" value={formatTimeForDisplay(route.waktu)} isTableValue={true} />
                        <DetailItem label="" value={route.remake || '-'} isTableValue={true} />
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </dd>
          </div>
        )}
        
        <div className="py-2 border-b border-white/15">
             <dt className="text-sm font-medium text-indigo-300 mb-1">Tim Pendamping</dt>
             <dd className="mt-1 text-sm text-indigo-100 sm:mt-0">
                 <table className="min-w-full text-left text-sm">
                     <tbody className="divide-y divide-white/15">
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Mutowif:</td><td className="py-1">{packageInfo.mutowifName || '-'} ({packageInfo.mutowifPhone || '-'})</td></tr>
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Tour Leader:</td><td className="py-1">{packageInfo.tourLeaderName || '-'} ({packageInfo.tourLeaderPhone || '-'})</td></tr>
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Tour Guide (Lokal):</td><td className="py-1">{packageInfo.tourGuideName || '-'} ({packageInfo.tourGuidePhone || '-'})</td></tr>
                     </tbody>
                 </table>
             </dd>
        </div>

        <DetailItem label="Nama Perwakilan Saudi" value={`${packageInfo.representativeName || '-'} (${packageInfo.representativePhone || '-'})`} />
        <DetailItem label="No. Tlp Ewako Royal (PIC Saudi)" value={packageInfo.ewakoRoyalPhone} />

        <div className="py-2 border-b border-white/15 last:border-b-0">
            <dt className="text-sm font-medium text-indigo-300 mb-1">Detail Penerbangan</dt>
            <dd className="mt-1 text-sm text-indigo-100 sm:mt-0">
                <table className="min-w-full text-left text-sm">
                    <tbody className="divide-y divide-white/15">
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Nama Maskapai:</td><td className="py-1">{packageInfo.airlineName || '-'}</td></tr>
                        <tr><td className="font-medium text-indigo-200 w-1/3 py-1 pr-2">Kode Penerbangan/PNR:</td><td className="py-1">{`${packageInfo.airlineCode || '-'} / ${packageInfo.pnrCode || '-'}`}</td></tr>
                        <tr>
                            <td className="font-medium text-indigo-200 w-1/3 py-1 pr-2 align-top">Kedatangan:</td>
                            <td className="py-1">
                                {arrivalInfoValue}
                                <br/>
                                <span className="text-xs text-indigo-300">Terminal: {packageInfo.arrivalTerminal || '-'}</span>
                            </td>
                        </tr>
                        <tr>
                            <td className="font-medium text-indigo-200 w-1/3 py-1 pr-2 align-top">Kepulangan:</td>
                            <td className="py-1">
                                {departureInfoValue}
                                <br/>
                                <span className="text-xs text-indigo-300">Terminal: {packageInfo.departureTerminal || '-'}</span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </dd>
        </div>

      </dl>
    </Card>
  );
};
