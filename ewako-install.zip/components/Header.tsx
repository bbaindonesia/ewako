import React from 'react';
import { APP_NAME } from '../constants';
// import { TimeDisplay } from './TimeDisplay'; // Removed
import * as ReactRouterDOM from 'react-router-dom';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 shadow-lg p-3 md:p-4">
      <div className="container mx-auto flex justify-between items-center">
        <ReactRouterDOM.Link to="/" className="header-app-title">
          {APP_NAME}
        </ReactRouterDOM.Link>
        {/* <TimeDisplay /> Removed */}
      </div>
    </header>
  );
};