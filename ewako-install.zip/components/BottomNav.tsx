
import React from 'react';
import * as ReactRouterDOM from 'react-router-dom';
import { HomeIcon, PlusCircleIcon, TicketIcon, ShoppingBagIcon, UserCircleIcon } from '@heroicons/react/24/outline';
import { User } from '../types'; // Assuming User type has role

interface BottomNavProps {
  userRole: User['role'] | null;
}

export const BottomNav: React.FC<BottomNavProps> = ({ userRole }) => {
  const navItems = [
    { path: userRole === 'admin' ? '/admin' : '/', label: 'Beranda', icon: HomeIcon }, // Dynamic path for Beranda
    { path: '/book', label: 'Pesan', icon: PlusCircleIcon },
    { path: '/orders', label: 'Pesanan', icon: TicketIcon },
    { path: '/jastip', label: 'Jastip', icon: ShoppingBagIcon },
    { path: '/account', label: 'Akun', icon: UserCircleIcon },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 shadow-top-lg z-50"> {/* Removed bg-gray-900, border-gray-700. Global CSS will style this. */}
      <div className="container mx-auto flex justify-around items-center h-16">
        {navItems.map((item) => (
          <ReactRouterDOM.NavLink
            key={item.label}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center text-indigo-200 hover:text-indigo-100 transition-colors duration-200 p-2 
              ${isActive ? 'active-nav-link' : ''}` // active-nav-link styled globally for accent color
            }
          >
            <item.icon className="h-6 w-6 mb-0.5" />
            <span className="text-xs">{item.label}</span>
          </ReactRouterDOM.NavLink>
        ))}
      </div>
    </nav>
  );
};