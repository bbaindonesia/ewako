
import React from 'react';

interface CardProps {
  children?: React.ReactNode;
  className?: string;
  title?: string;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({ children, className, title, onClick }) => {
  return (
    <div
      // The `className` prop should include 'generic-card-glass' for the new theme.
      // Specific background styling is handled by global CSS based on 'generic-card-glass'.
      className={`shadow-xl rounded-xl overflow-hidden ${onClick ? 'cursor-pointer transition-shadow duration-300' : ''} ${className}`}
      onClick={onClick}
    >
      {title && (
        // This div will contain the title. Styling for h3 inside this path is in global CSS.
        // Use a specific class if more control needed beyond `generic-card-glass > div:first-child > h3`
        <div className="p-4 border-b border-[rgba(255,50,50,0.3)]"> {/* Red neon subtle border for title area */}
          <h3 className="text-lg font-semibold card-title-custom-style">{title}</h3> {/* Class for gold Orbitron title */}
        </div>
      )}
      <div className="p-4 md:p-6">
        {children}
      </div>
    </div>
  );
};
