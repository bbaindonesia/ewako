import React from 'react';
import { useRealTimeClocks } from '../hooks/useRealTimeClocks';
import { AnalogDigitalClock } from './AnalogDigitalClock'; 

export const NeonClockWidget: React.FC = () => {
  const { wib, ksa } = useRealTimeClocks();

  return (
    // This is the single glass panel for the whole widget.
    <div className="mb-6 sm:mb-8 p-2 sm:p-3 rounded-xl shadow-xl generic-card-glass">
      <div className="grid grid-cols-2 gap-2 sm:gap-3 items-start justify-items-center">
        {/* AnalogDigitalClock components are no longer cards themselves, but styled text blocks */}
        <AnalogDigitalClock 
          timeComponents={wib}
          label="WIB (Indonesia)"
        />
        <AnalogDigitalClock
          timeComponents={ksa}
          label="KSA (Saudi Arabia)"
        />
      </div>
    </div>
  );
};
