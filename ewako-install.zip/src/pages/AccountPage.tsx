
import React, { useState, useEffect } from 'react';
import { Layout } from '../components/Layout';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { User } from '../types';
import { useNavigate } from 'react-router-dom';
import { getUserById, updateUser } from '../services/userService';
import { DEFAULT_SUPPORT_PHONE, DEFAULT_SUPPORT_EMAIL } from '../constants';
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { useAuth } from '../hooks/useAuth';


const AccountPage: React.FC = () => {
  const navigate = useNavigate();
  const { userId } = useAuth();
  const [user, setUser] = useState<User | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<User>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);


  useEffect(() => {
    const fetchUserData = async () => {
      setIsLoading(true);
      setError(null); 

      if (userId) { 
        try {
          const fetchedUser = await getUserById(userId);
          if (fetchedUser) {
            setUser(fetchedUser as User); 
            setFormData({
              name: fetchedUser.name,
              email: fetchedUser.email,
              phone: fetchedUser.phone,
              ppiuName: fetchedUser.ppiuName,
              address: fetchedUser.address,
            });
          } else {
            console.warn(`[AccountPage] User not found for ID ${userId}. Logging out.`);
            handleLogout(true); // Call logout, with silent true
          }
        } catch (err: any) { 
          console.error("[AccountPage] Error fetching user data:", err);
            setError("Gagal memuat profil pengguna. Silakan coba lagi nanti.");
        } finally {
          setIsLoading(false); 
        }
      } else {
        console.log("[AccountPage] No userId from useAuth hook. Redirecting to login.");
        navigate('/login', { replace: true });
        setIsLoading(false); 
      }
    };

    fetchUserData();
  }, [navigate, userId]); 

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setIsSubmitting(true);
    setError(null);
    try {
      const updateData: Partial<Omit<User, 'id' | 'role' | 'accountStatus' | 'password'>> = {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        ppiuName: formData.ppiuName,
        address: formData.address,
      };
      
      const updatedUser = await updateUser(user.id, updateData);
      if (updatedUser) {
        setUser(updatedUser as User); 
        setFormData({ 
             name: updatedUser.name,
             email: updatedUser.email,
             phone: updatedUser.phone,
             ppiuName: updatedUser.ppiuName,
             address: updatedUser.address,
        });
        setIsEditing(false);
        alert("Profil berhasil diperbarui.");
      } else {
        alert("Gagal memperbarui profil.");
      }
    } catch (error) {
      console.error("Error saving profile:", error);
      setError("Terjadi kesalahan saat menyimpan profil.");
      alert("Terjadi kesalahan saat menyimpan profil.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogout = (silent = false) => {
    localStorage.removeItem('ewakoRoyalUserId');
    localStorage.removeItem('ewakoRoyalUserRole');
    localStorage.removeItem('ewakoRoyalAuthToken'); 
    window.dispatchEvent(new CustomEvent('customAuthChange')); 
    if (!silent) navigate('/');
  };

  if (isLoading) { 
    return <Layout><div className="flex justify-center items-center h-64"><LoadingSpinner /></div></Layout>;
  }
  
  if (error) {
    return (
        <Layout>
            <Card title="Error Profil" className="generic-card-glass text-center">
                <p className="text-red-400 mb-4">{error}</p>
                <Button onClick={() => navigate('/login', { replace: true })} variant="primary">Kembali ke Login</Button>
            </Card>
        </Layout>
    );
  }

  if (!user) { 
    return <Layout><div className="flex justify-center items-center h-64"><p className="text-indigo-200">Memuat ulang atau mengarahkan...</p><LoadingSpinner size="md"/></div></Layout>;
  }
  
  const supportPhoneNumber = user.role === 'admin' && user.phone ? user.phone : DEFAULT_SUPPORT_PHONE;
  const supportEmailAddress = user.role === 'admin' && user.email ? user.email : DEFAULT_SUPPORT_EMAIL;
  const supportWhatsAppLink = `https://wa.me/${supportPhoneNumber.replace(/\D/g, '')}`;


  return (
    <Layout>
      <h1 className="text-3xl font-bold metallic-gold-text mb-8">Akun Saya</h1>
      <Card title="Profil Pengguna" className="generic-card-glass">
        {!isEditing ? (
          <div className="space-y-3 text-sm">
            <p><strong className="text-indigo-300">Nama:</strong> {user.name}</p>
            <p><strong className="text-indigo-300">Email:</strong> {user.email}</p>
            <p><strong className="text-indigo-300">No. HP:</strong> {user.phone || '-'}</p>
            <p><strong className="text-indigo-300">Alamat:</strong> {user.address || '-'}</p>
            {user.role === 'customer' && <p><strong className="text-indigo-300">PPIU/PIHK:</strong> {user.ppiuName || '-'}</p>}
            <p><strong className="text-indigo-300">Role:</strong> <span className="capitalize">{user.role}</span></p>
            <p><strong>Status Akun:</strong> <span className={`font-semibold ${
                    user.accountStatus === 'active' ? 'text-green-300' :
                    user.accountStatus === 'pending_approval' ? 'text-yellow-300' :
                    user.accountStatus === 'suspended' ? 'text-red-300' : 'text-indigo-300'
                }`}>
                    {user.accountStatus.replace('_', ' ')}
            </span></p>
            <Button onClick={() => setIsEditing(true)} variant="outline" size="sm" className="mt-4">
              Ubah Profil
            </Button>
          </div>
        ) : (
          <form onSubmit={(e) => { e.preventDefault(); handleSaveProfile(); }} className="space-y-4">
            <Input label="Nama" name="name" value={formData.name || ''} onChange={handleInputChange} />
            <Input label="Email" name="email" type="email" value={formData.email || ''} onChange={handleInputChange} />
            <Input label="No. HP" name="phone" type="tel" value={formData.phone || ''} onChange={handleInputChange} />
            <Input label="Alamat" name="address" value={formData.address || ''} onChange={handleInputChange} />
            {user.role === 'customer' && <Input label="PPIU/PIHK" name="ppiuName" value={formData.ppiuName || ''} onChange={handleInputChange} />}
            <div className="flex space-x-3 mt-4">
              <Button type="submit" variant="primary" size="sm" isLoading={isSubmitting}>
                Simpan Perubahan
              </Button>
              <Button onClick={() => setIsEditing(false)} variant="outline" size="sm" disabled={isSubmitting}>
                Batal
              </Button>
            </div>
          </form>
        )}
      </Card>

      {(user.role === 'admin' || user.role === 'tim_staff') && (
        <Card title="Area Admin" className="mt-6 generic-card-glass">
           <Button onClick={() => navigate('/admin')} variant="secondary" className="w-full">
            Buka Dashboard Admin
          </Button>
        </Card>
      )}

      <Card title="Bantuan" className="mt-8 generic-card-glass">
        <p className="text-indigo-200">Butuh bantuan? Hubungi kami melalui:</p>
        <ul className="list-disc list-inside text-indigo-300 mt-2 text-sm">
            <li>WhatsApp: <a href={supportWhatsAppLink} target="_blank" rel="noopener noreferrer" className="metallic-gold-text hover:opacity-80 underline">{supportPhoneNumber}</a></li>
            <li>Email: <a href={`mailto:${supportEmailAddress}`} className="metallic-gold-text hover:opacity-80 underline">{supportEmailAddress}</a></li>
        </ul>
      </Card>

       <div className="mt-8 text-center">
        <Button onClick={() => handleLogout()} variant="danger" size="md">
          Logout
        </Button>
      </div>
    </Layout>
  );
};

export default AccountPage;
