

import React from 'react';
import { Layout } from '../../components/Layout';
import { Link } from 'react-router-dom';
import { Card } from '../../components/ui/Card';
import { Cog6ToothIcon, ClipboardDocumentListIcon, ChatBubbleLeftRightIcon, CurrencyDollarIcon, TruckIcon, UsersIcon, ArchiveBoxIcon } from '@heroicons/react/24/solid'; 

const adminSections = [
  { title: "Kelola Pesanan", link: "/admin/orders", icon: <ClipboardDocumentListIcon className="h-8 w-8 metallic-gold-text" />, description: "Lihat dan perbarui status semua pesanan." },
  { title: "Laporan Tim Handling", link: "/admin/handling-overview", icon: <ArchiveBoxIcon className="h-8 w-8 metallic-gold-text" />, description: "Buat & kelola laporan tim handling lapangan." }, 
  { title: "Kelola Pengguna", link: "/admin/users", icon: <UsersIcon className="h-8 w-8 metallic-gold-text" />, description: "Atur profil admin dan pemesan." },
  { title: "Atur Kendaraan", link: "/admin/vehicles", icon: <TruckIcon className="h-8 w-8 metallic-gold-text" />, description: "Kelola daftar kendaraan untuk layanan." },
  { title: "Chat dengan Pemesan", link: "/admin/chat", icon: <ChatBubbleLeftRightIcon className="h-8 w-8 metallic-gold-text" />, description: "Komunikasi langsung dengan pelanggan." }, 
  { title: "Pengaturan Pembayaran", link: "/admin/settings", icon: <CurrencyDollarIcon className="h-8 w-8 metallic-gold-text" />, description: "Atur rekening dan integrasi Midtrans." }, 
  { title: "Pengaturan Aplikasi", link: "/admin/app-settings", icon: <Cog6ToothIcon className="h-8 w-8 metallic-gold-text" />, description: "Konfigurasi umum aplikasi. (Segera)" }, 
];

const AdminDashboardPage: React.FC = () => {
  return (
    <Layout>
      <h1 className="text-3xl font-bold metallic-gold-text mb-8">Admin Dashboard</h1>
      <p className="text-indigo-200 mb-8">Selamat datang di area administrasi EWAKO ROYAL. Kelola semua aspek operasional aplikasi dari sini.</p>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-6">
        {adminSections.map(section => (
          <Link 
            key={section.title} 
            to={section.link} 
            className="block group"
            onClick={(e) => {
              if (section.link === "/admin/handling-overview") {
                e.preventDefault();
                alert("Fitur Laporan Tim Handling diakses melalui halaman Detail Pesanan.");
              }
            }}
          >
            <Card className="generic-card-glass hover:border-yellow-400/50 hover:shadow-yellow-glow transition-all duration-300 ease-in-out transform group-hover:scale-105 h-full flex flex-col">
              <div className="flex flex-col items-center text-center p-6 flex-grow">
                <div className="mb-4">{section.icon}</div>
                <h2 className="text-xl font-semibold text-white mb-2 group-hover:metallic-gold-text transition-colors duration-300">{section.title}</h2>
                <p className="text-sm text-indigo-200">{section.description}</p>
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </Layout>
  );
};

export default AdminDashboardPage;
