import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Layout } from '../../components/Layout';
import { Card } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { Order, ChatMessage, User } from '../../types';
import { getAllOrders, getOrderById } from '../../services/orderService';
import { sendChatMessage, getChatMessagesForOrder } from '../../services/chatService';
import { ChatMessageBubble } from '../../components/ChatMessageBubble';
import { ChatInput } from '../../components/ChatInput';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
import { getUserById } from '../../services/userService'; 

const AdminChatPage: React.FC = () => {
  const navigate = useNavigate();
  const { orderId: paramOrderId } = useParams<{ orderId?: string }>();

  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [selectedOrderCustomer, setSelectedOrderCustomer] = useState<User | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const adminUserId = 'adminUser'; // Hardcoded for mock
  const adminUserName = 'Admin Ewako';

  
  const handleSelectOrder = useCallback(async (order: Order) => {
    setSelectedOrder(order);
    setIsLoadingMessages(true);
    try {
      const messages = await getChatMessagesForOrder(order.id);
      setChatMessages(messages);
      const customer = await getUserById(order.userId);
      setSelectedOrderCustomer(customer || null);
    } catch (error) {
      console.error("Failed to fetch messages for order:", order.id, error);
      setChatMessages([]);
    } finally {
      setIsLoadingMessages(false);
    }
  }, []);

  const fetchOrders = useCallback(async () => {
    setIsLoadingOrders(true);
    try {
      const fetchedOrders = await getAllOrders();
      setOrders(fetchedOrders);
      if (paramOrderId) {
        const orderToSelect = fetchedOrders.find(o => o.id === paramOrderId);
        if (orderToSelect) {
          handleSelectOrder(orderToSelect); // Call handleSelectOrder here
        }
      }
    } catch (error) {
      console.error("Failed to fetch orders for chat:", error);
    } finally {
      setIsLoadingOrders(false);
    }
  }, [paramOrderId, handleSelectOrder]);


  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [chatMessages]);


  const handleSendMessage = async (text?: string, file?: File) => {
    if (!selectedOrder || (!text && !file)) return;
    setIsSendingMessage(true);
    try {
      const newMessage = await sendChatMessage(selectedOrder.id, adminUserName, adminUserId, text, file);
      if (newMessage) {
        setChatMessages(prev => [...prev, newMessage]);
      }
    } catch (error) {
      console.error("Failed to send message:", error);
    } finally {
      setIsSendingMessage(false);
    }
  };

  return (
    <Layout>
      <div className="flex items-center mb-6">
        <button 
          onClick={() => navigate('/admin')} 
          className="mr-4 p-2 rounded-full hover:bg-white/15 transition-colors"
          aria-label="Kembali ke Dashboard Admin"
        > {/* Adjusted hover */}
          <ArrowLeftIcon className="h-6 w-6 text-white" />
        </button>
        <h1 className="text-2xl font-bold metallic-gold-text">Chat dengan Pelanggan</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[calc(100vh-12rem-5rem)]"> {/* Adjust height for layout */}
        {/* Orders List */}
        <Card title="Pilih Pesanan untuk Chat" className="generic-card-glass md:col-span-1 overflow-y-auto"> {/* Used generic-card-glass */}
          {isLoadingOrders ? (
            <LoadingSpinner />
          ) : orders.length === 0 ? (
            <p className="text-indigo-200">Tidak ada pesanan.</p>
          ) : (
            <ul className="space-y-2">
              {orders.map(order => (
                <li key={order.id}>
                  <Button
                    variant={selectedOrder?.id === order.id ? "primary" : "outline"}
                    fullWidth
                    onClick={() => handleSelectOrder(order)}
                    className="text-left justify-start !py-2 !px-3"
                  >
                    ID: {order.id.substring(0, 8)}... ({order.serviceType}) <br/>
                    <span className="text-xs opacity-70"> Pemesan: {(order.data as any).customerName}</span>
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Chat Window */}
        <Card 
            title={selectedOrder ? `Chat untuk Pesanan ID: ${selectedOrder.id.substring(0,8)}... (Pelanggan: ${selectedOrderCustomer?.name || selectedOrder.userId})` : "Pilih Pesanan"} 
            className="generic-card-glass md:col-span-2 flex flex-col h-full" /* Used generic-card-glass */
        >
          {selectedOrder ? (
            <>
              <div className="flex-grow overflow-y-auto p-4 space-y-2 bg-black/10 backdrop-blur-sm rounded-t-md"> {/* Subtle bg for messages area */}
                {isLoadingMessages ? (
                  <LoadingSpinner />
                ) : chatMessages.length === 0 ? (
                  <p className="text-indigo-300 text-center py-10">Belum ada pesan. Mulai percakapan!</p>
                ) : (
                  chatMessages.map(msg => (
                    <ChatMessageBubble key={msg.id} message={msg} currentUserId={adminUserId} />
                  ))
                )}
                <div ref={messagesEndRef} />
              </div>
              <ChatInput onSendMessage={handleSendMessage} isLoading={isSendingMessage} />
            </>
          ) : (
            <div className="flex-grow flex items-center justify-center">
              <p className="text-indigo-300">Pilih pesanan dari daftar di samping untuk memulai chat.</p>
            </div>
          )}
        </Card>
      </div>
    </Layout>
  );
};

export default AdminChatPage;