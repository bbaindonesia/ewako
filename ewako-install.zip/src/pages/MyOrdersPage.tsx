

import React, { useState, useEffect, useCallback } from 'react';
import { Layout } from '../components/Layout';
import { OrderItemCard } from '../components/OrderItemCard';
import { Order, OrderStatus } from '../types';
import { getOrdersByUserId, updateOrderStatus } from '../services/orderService';
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { sendNotificationToCustomer } from '../services/whatsappService';
import { ADMIN_WHATSAPP_NUMBER } from '../constants';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';

const MyOrdersPage: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { userId, isAuthenticated } = useAuth();

  const fetchOrders = useCallback(async (showLoading = true) => {
    if (!userId) {
      setIsLoading(false);
      setError("Tidak dapat memuat pesanan, pengguna tidak terautentikasi.");
      return;
    }
    if (showLoading) setIsLoading(true);
    setError(null);
    try {
      const userOrders = await getOrdersByUserId(userId);
      setOrders(userOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch (err) {
      setError("Gagal memuat pesanan. Silakan coba lagi.");
      console.error(err);
    } finally {
      if (showLoading) setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    if (isAuthenticated) {
      fetchOrders();
    } else {
      setIsLoading(false);
      setOrders([]);
    }
  }, [fetchOrders, isAuthenticated]);

  useEffect(() => {
    const handleFocus = () => {
      if (isAuthenticated) {
        fetchOrders(false);
      }
    };
    window.addEventListener('focus', handleFocus);
    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, [fetchOrders, isAuthenticated]);

  const handleCustomerConfirmation = async (orderId: string, confirmed: boolean) => {
    setIsLoading(true);
    try {
      const newStatus = confirmed ? OrderStatus.DEFINITE_CONFIRMATION : OrderStatus.REJECTED_BY_CUSTOMER;
      const updatedOrder = await updateOrderStatus(orderId, newStatus, confirmed);
      
      if (updatedOrder) {
        setOrders(prevOrders => prevOrders.map(o => o.id === orderId ? updatedOrder : o));
        
        const customerPhone = (updatedOrder.data as any).phone;
        const messageToCustomer = confirmed 
          ? `Pesanan Anda (${updatedOrder.serviceType} - ID: ${orderId.substring(0,8)}) telah Anda konfirmasi. Kami akan segera memprosesnya.`
          : `Anda telah menolak pesanan (${updatedOrder.serviceType} - ID: ${orderId.substring(0,8)}). Jika ada pertanyaan, silakan hubungi kami.`;
        if (customerPhone) sendNotificationToCustomer(customerPhone, messageToCustomer);
        
        const messageToAdmin = `Pelanggan ${(updatedOrder.data as any).customerName} (${customerPhone}) telah ${confirmed ? 'MENGKONFIRMASI' : 'MENOLAK'} pesanan ${updatedOrder.serviceType} (ID: ${orderId.substring(0,8)}).`;
        sendNotificationToCustomer(ADMIN_WHATSAPP_NUMBER, messageToAdmin);
      }
    } catch (err) {
      setError("Gagal memperbarui status pesanan.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const renderContent = () => {
    if (isLoading) {
      return <div className="flex justify-center items-center h-64"><LoadingSpinner /></div>;
    }
    if (error) {
      return <p className="text-red-300 bg-red-700/50 backdrop-blur-sm p-3 rounded-lg">{error}</p>;
    }
    if (!isAuthenticated) {
      return <p className="text-indigo-200">Silakan <Link to="/login" className="metallic-gold-text underline">login</Link> untuk melihat pesanan Anda.</p>;
    }
    if (orders.length === 0) {
      return <p className="text-indigo-200">Anda belum memiliki pesanan.</p>;
    }
    return (
      <div className="space-y-6">
        {orders.map(order => (
          <OrderItemCard 
            key={order.id} 
            order={order} 
            onCustomerConfirm={handleCustomerConfirmation} 
          />
        ))}
      </div>
    );
  };

  return (
    <Layout>
      <h1 className="text-3xl font-bold metallic-gold-text mb-8">Pesanan Saya</h1>
      {renderContent()}
    </Layout>
  );
};

export default MyOrdersPage;
