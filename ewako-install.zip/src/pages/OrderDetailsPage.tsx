


import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { Layout } from '../components/Layout'; // Corrected path
import { Order, OrderStatus, HotelBookingData, VisaBookingData, HandlingBookingData, JastipBookingData, ServiceType, RoomBooking, HotelInfo, PackageInfoData, ManifestItem, ChatMessage, User as AuthUserType, JastipItemType, JastipUnit, Vehicle, BusRouteItem, Payment, SenderTransferMethod, AdminManagedBankAccount, ZiarahRouteItem, PaymentApprovalStatus, AddPaymentPayload } from '../types';
import { getOrderById, updateOrderStatus, updateOrderData, updatePackageInfo, updateOrderManifest, addPaymentToOrder } from '../services/orderService'; 
import { getVehicles } from '../services/vehicleService'; 
import { LoadingSpinner } from '../components/ui/LoadingSpinner';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Select } from '../components/ui/Select';
import { Textarea } from '../components/ui/Textarea';
import { Input } from '../components/ui/Input'; 
import { ArrowLeftIcon, PencilIcon, TrashIcon, PlusCircleIcon, ChatBubbleLeftEllipsisIcon, CurrencyDollarIcon, EyeIcon } from '@heroicons/react/24/outline';
import { PackageInfoDisplay } from '../components/PackageInfoDisplay';
import { sendNotificationToCustomer } from '../services/whatsappService';
import { ADMIN_WHATSAPP_NUMBER, MOCK_MUTOWIFS, JASTIP_UNITS_MAP, MIDTRANS_VA_OPTIONS, SENDER_TRANSFER_METHODS, FALLBACK_BANK_ACCOUNTS } from '../constants';
import { generateOrderRequestPdf, generateInvoicePdf, generatePackageInfoPdf, generateManifestPdf } from '../services/pdfService';
import { useAuth } from '../hooks/useAuth'; 
import { ChatMessageBubble } from '../components/ChatMessageBubble';
import { ChatInput } from '../components/ChatInput';
import { getUserById as getAuthUserInfo } from '../services/userService'; 
import { formatCurrency, convertToIDR, MOCK_EXCHANGE_RATES } from '../services/currencyService';
import { getChatMessagesForOrder, sendChatMessage } from '../services/chatService'; 
import { getAdminBankAccounts } from '../services/adminSettingsService';


// Helper functions
const formatDateForDisplay = (dateString?: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString.split('T')[0]);
  if (isNaN(date.getTime())) return '';
  return date.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

const formatDateTimeForDisplay = (dateTimeString?: string): string => {
    if (!dateTimeString) return '-';
    const date = new Date(dateTimeString);
    if (isNaN(date.getTime())) return '-';
    return date.toLocaleString('id-ID', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'});
};

const formatHotelToStringForPackageInfo = (hotel?: HotelInfo): string => {
    if (!hotel || !hotel.name) return '';
    const roomsDescArray: string[] = [];
    if (hotel.rooms.quad > 0) roomsDescArray.push(`Quad(${hotel.rooms.quad})`);
    if (hotel.rooms.triple > 0) roomsDescArray.push(`Triple(${hotel.rooms.triple})`);
    if (hotel.rooms.double > 0) roomsDescArray.push(`Double(${hotel.rooms.double})`);
    const roomsDesc = roomsDescArray.length > 0 ? roomsDescArray.join(', ') : 'Rincian kamar tidak specific';
    return `${hotel.name} (Kamar: ${roomsDesc}), ${hotel.nights} malam. CheckIn: ${formatDateForDisplay(hotel.checkIn)}, CheckOut: ${formatDateForDisplay(hotel.checkOut)}`;
};

const initialHotelInfoForEdit: HotelInfo = { name: '', nights: 1, rooms: { quad: 0, triple: 0, double: 0 }, checkIn: '', checkOut: '' };

const generateGroupCodePlaceholder = (ppiuName: string | undefined, customerName: string, createdAt: string): string => {
    const namePart = (ppiuName || customerName || "EwakoRoyal").replace(/\s+/g, '').substring(0, 10).toUpperCase();
    const date = new Date(createdAt);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
    const year = String(date.getFullYear()).slice(-2);
    return `${namePart}-${day}${month}${year}`;
};


const initialPackageInfo: PackageInfoData = { 
    groupCode: '', 
    ppiuName: '', ppiuPhone: '', paxCount: 0, 
    madinahHotelInfo: '', makkahHotelInfo: '', 
    madinahHotelStructured: { ...initialHotelInfoForEdit }, 
    makkahHotelStructured: { ...initialHotelInfoForEdit },
    busVehicleId: '', busName: '', busVehicleType: '', busDriverName: '', busDriverPhone: '', busSyarikahNumber: '',
    busRoutes: [], 
    ziarahRoutes: [], 
    mutowifName: '', mutowifPhone: '', representativeName: '', 
    representativePhone: '', ewakoRoyalPhone: '', airlineName: '', airlineCode: '', 
    arrivalDateTime: '', departureDateTime: '',
    pnrCode: '', arrivalTerminal: '', departureTerminal: '',
    tourLeaderName: '', tourLeaderPhone: '', tourGuideName: '', tourGuidePhone: ''
};
const initialManifestItemForm: Omit<ManifestItem, 'id' | 'usia'> = { 
    namaJemaah: '', 
    jenisKelamin: '', 
    tanggalLahir: '', 
    nomorVisa: '', 
    namaDiPaspor: '', 
    nomorPaspor: '', 
    tanggalTerbitPaspor: '', 
    tanggalExpiredPaspor: '', 
    kotaTempatIssuedPaspor: '',
    kotaAsalKeberangkatan: '',
};

const initialCustomerPaymentForm = (userId: string | null): AddPaymentPayload => ({
    userId: userId || 'guestUser',
    amount: 0,
    paymentDate: new Date().toISOString().split('T')[0],
    paymentType: 'DP',
    paymentMethod: 'Transfer',
    notes: '',
    senderAccountName: '',
    senderAccountNumber: '',
    senderBankName: '',
    senderTransferMethod: '',
    destinationBankName: '', 
    destinationAccountNumber: '', 
    paymentGatewayType: '',
    paymentApprovalStatus: 'Pending',
});


const DetailItemLocal: React.FC<{label: string, value?: string | number | React.ReactNode}> = ({label, value}) => (
    <div className="py-2 sm:grid sm:grid-cols-3 sm:gap-4 border-b border-white/15 last:border-b-0">
      <dt className="text-sm font-medium text-indigo-300">{label}</dt>
      <dd className="mt-1 text-sm text-indigo-100 sm:mt-0 sm:col-span-2 whitespace-pre-wrap">{value || '-'}</dd>
    </div>
);

const getOrderStatusPillStyleLocal = (status: OrderStatus): string => {
  switch (status) {
    case OrderStatus.REQUEST_CONFIRMATION: return 'border-blue-400 text-blue-300';
    case OrderStatus.TENTATIVE_CONFIRMATION: return 'border-yellow-400 text-yellow-300';
    case OrderStatus.DEFINITE_CONFIRMATION: return 'border-orange-400 text-orange-300';
    case OrderStatus.CONFIRMED_BY_ADMIN: return 'border-teal-400 text-teal-300';
    case OrderStatus.DOWNPAYMENT_RECEIVED: return 'border-indigo-400 text-indigo-300';
    case OrderStatus.FULLY_PAID: return 'border-green-400 text-green-300';
    case OrderStatus.REJECTED_BY_CUSTOMER:
    case OrderStatus.CANCELLED: return 'border-red-400 text-red-300';
    default: return 'border-gray-400 text-gray-300';
  }
};

const getPaymentApprovalStatusPillStyle = (status: PaymentApprovalStatus): string => {
  switch (status) {
    case 'Pending': return 'border-yellow-400 text-yellow-300';
    case 'Approved': return 'border-green-400 text-green-300';
    case 'Rejected': return 'border-red-400 text-red-300';
    default: return 'border-gray-400 text-gray-300';
  }
};

const mapPaymentApprovalStatusToText = (status: PaymentApprovalStatus): string => {
    switch (status) {
        case 'Pending': return 'Menunggu Konfirmasi';
        case 'Approved': return 'Lunas / Disetujui';
        case 'Rejected': return 'Ditolak';
        default: return status;
    }
};


const ziarahKotaOptions: Array<{ value: ZiarahRouteItem['kota'] | string; label: string }> = [
    { value: '', label: 'Pilih Kota' },
    { value: 'Madinah', label: 'Madinah' },
    { value: 'Mekah', label: 'Mekah' },
    { value: 'Thaif', label: 'Thaif' },
    { value: 'Jeddah', label: 'Jeddah' },
    { value: 'Lainnya', label: 'Lainnya' },
];

const ziarahRemakeOptions: Array<{ value: ZiarahRouteItem['remake'] | string; label: string }> = [
    { value: '', label: 'Pilih Jenis' },
    { value: 'Ziarah', label: 'Ziarah' },
    { value: 'City Tour', label: 'City Tour' },
];


const OrderDetailsPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { userId: currentAuthUserId, userRole } = useAuth(); 
  const [currentUser, setCurrentUser] = useState<AuthUserType | null>(null);

  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [isEditingOrderData, setIsEditingOrderData] = useState(false);
  const [editableOrderData, setEditableOrderData] = useState<Partial<HotelBookingData | VisaBookingData | HandlingBookingData>>({}); 
  const [isEditingPackageInfo, setIsEditingPackageInfo] = useState(false);
  const [packageInfoForm, setPackageInfoForm] = useState<PackageInfoData>(initialPackageInfo);
  const [availableVehicles, setAvailableVehicles] = useState<Vehicle[]>([]); 

  const [showManifestFormModal, setShowManifestFormModal] = useState(false);
  const [currentEditingManifestItem, setCurrentEditingManifestItem] = useState<ManifestItem | null>(null);
  const [manifestItemForm, setManifestItemForm] = useState<Omit<ManifestItem, 'id' | 'usia'>>(initialManifestItemForm);
  const [manifestItemAge, setManifestItemAge] = useState<number | undefined>(undefined);

  const [showChatModal, setShowChatModal] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isLoadingChatMessages, setIsLoadingChatMessages] = useState(false);
  const [isSendingChatMessage, setIsSendingChatMessage] = useState(false);
  const chatMessagesEndRef = useRef<HTMLDivElement>(null);

  const [showCustomerPaymentForm, setShowCustomerPaymentForm] = useState(false);
  const [customerPaymentForm, setCustomerPaymentForm] = useState(initialCustomerPaymentForm(currentAuthUserId));
  const [selectedProofFile, setSelectedProofFile] = useState<File | null>(null);
  const [customerPaymentStatus, setCustomerPaymentStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [destinationBankAccounts, setDestinationBankAccounts] = useState<AdminManagedBankAccount[]>([]);


  const fetchOrderDetails = useCallback(async (showLoadingSpinner = true) => {
    if (!orderId) {
      setError("Order ID tidak valid.");
      setIsLoading(false);
      return;
    }
    if (showLoadingSpinner) setIsLoading(true);
    setError(null);
    try {
      const [fetchedOrder, vehicles, adminBanks] = await Promise.all([
        getOrderById(orderId),
        getVehicles(),
        getAdminBankAccounts()
      ]);
      setAvailableVehicles(vehicles);
      setDestinationBankAccounts(adminBanks.length > 0 ? adminBanks : FALLBACK_BANK_ACCOUNTS);


      if (fetchedOrder) {
        if (userRole === 'customer' && fetchedOrder.userId !== currentAuthUserId) {
            setError("Anda tidak diizinkan untuk melihat detail pesanan ini.");
            setOrder(null);
        } else {
            setOrder(fetchedOrder);
            setEditableOrderData(JSON.parse(JSON.stringify(fetchedOrder.data))); // Deep copy
            
            let initialFormStatePopulated: PackageInfoData = { 
                ...initialPackageInfo, 
                ...(fetchedOrder.packageInfo || {}),
                madinahHotelStructured: fetchedOrder.packageInfo?.madinahHotelStructured 
                                      ? { ...(fetchedOrder.packageInfo.madinahHotelStructured) } 
                                      : ((fetchedOrder.data as HotelBookingData)?.madinahHotel ? { ...((fetchedOrder.data as HotelBookingData).madinahHotel!) } : { ...initialHotelInfoForEdit }),
                makkahHotelStructured: fetchedOrder.packageInfo?.makkahHotelStructured 
                                     ? { ...(fetchedOrder.packageInfo.makkahHotelStructured) }
                                     : ((fetchedOrder.data as HotelBookingData)?.makkahHotel ? { ...((fetchedOrder.data as HotelBookingData).makkahHotel!) } : { ...initialHotelInfoForEdit }),
                ewakoRoyalPhone: fetchedOrder.packageInfo?.ewakoRoyalPhone || ADMIN_WHATSAPP_NUMBER,
                ziarahRoutes: fetchedOrder.packageInfo?.ziarahRoutes ? [...fetchedOrder.packageInfo.ziarahRoutes] : [],
            };

            if (fetchedOrder.packageInfo?.busVehicleId) {
                const selectedVehicle = vehicles.find(v => v.id === fetchedOrder.packageInfo?.busVehicleId);
                if (selectedVehicle) {
                    initialFormStatePopulated = {
                        ...initialFormStatePopulated,
                        busVehicleId: selectedVehicle.id,
                        busName: selectedVehicle.name,
                        busVehicleType: selectedVehicle.type,
                        busDriverName: selectedVehicle.driverName || '',
                        busDriverPhone: selectedVehicle.driverPhone || '',
                        busSyarikahNumber: selectedVehicle.companyName || '', 
                    };
                }
            }
            if (initialFormStatePopulated.busRoutes && initialFormStatePopulated.busRoutes.length > 0) {
                initialFormStatePopulated.busRoutes = initialFormStatePopulated.busRoutes.map(route => {
                    if (route.routeVehicleId) {
                        const foundVehicle = vehicles.find(v => v.id === route.routeVehicleId);
                        if (foundVehicle) {
                            return {
                                ...route,
                                vehicleDetails: `${foundVehicle.name} (${foundVehicle.plateNumber}) - Driver: ${foundVehicle.driverName || '-'}`
                            };
                        }
                    }
                    return {...route, vehicleDetails: route.vehicleDetails || ''};
                });
            } else {
                 initialFormStatePopulated.busRoutes = [];
            }
            setPackageInfoForm(initialFormStatePopulated);
        }
      } else {
        setError("Pesanan tidak ditemukan.");
      }
    } catch (err) {
      setError("Gagal memuat detail pesanan.");
      console.error(err);
    } finally {
      if (showLoadingSpinner) setIsLoading(false);
    }
  }, [orderId, currentAuthUserId, userRole]);

  useEffect(() => {
    if (currentAuthUserId) {
        getAuthUserInfo(currentAuthUserId).then(user => setCurrentUser(user || null));
        setCustomerPaymentForm(initialCustomerPaymentForm(currentAuthUserId));
    } else {
        setCustomerPaymentForm(initialCustomerPaymentForm(null));
    }
    fetchOrderDetails();
  }, [fetchOrderDetails, currentAuthUserId]);
  
  const calculateAge = (birthDateString: string): number | undefined => {
    if (!birthDateString) return undefined;
    const birthDate = new Date(birthDateString);
    if (isNaN(birthDate.getTime())) return undefined;
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
  };
  useEffect(() => { setManifestItemAge(calculateAge(manifestItemForm.tanggalLahir)); }, [manifestItemForm.tanggalLahir]);

  const scrollToChatBottom = () => {
    chatMessagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  useEffect(scrollToChatBottom, [chatMessages]);

  const handleCustomerConfirmation = async (confirmed: boolean) => {
    if (!orderId || !order) return;
    setIsSubmitting(true);
    try {
        const newStatus = confirmed ? OrderStatus.DEFINITE_CONFIRMATION : OrderStatus.REJECTED_BY_CUSTOMER;
        const updatedOrder = await updateOrderStatus(orderId, newStatus, confirmed);
        if (updatedOrder) {
            setOrder(updatedOrder);
            const customerPhone = (updatedOrder.data as any).phone;
            const messageToCustomer = confirmed 
            ? `Pesanan Anda (${updatedOrder.serviceType} - ID: ${orderId.substring(0,8)}) telah Anda konfirmasi. Kami akan segera memprosesnya.`
            : `Anda telah menolak pesanan (${updatedOrder.serviceType} - ID: ${orderId.substring(0,8)}). Jika ada pertanyaan, silakan hubungi kami.`;
            if (customerPhone) sendNotificationToCustomer(customerPhone, messageToCustomer);
            
            const messageToAdmin = `Pelanggan ${(updatedOrder.data as any).customerName} (${customerPhone}) telah ${confirmed ? 'MENGKONFIRMASI' : 'MENOLAK'} pesanan ${updatedOrder.serviceType} (ID: ${orderId.substring(0,8)}).`;
            sendNotificationToCustomer(ADMIN_WHATSAPP_NUMBER, messageToAdmin);
        }
    } catch (err) {
        setError("Gagal memperbarui status konfirmasi.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };

const handleEditOrderDataChange = useCallback((
    targetType: 'madinahHotel' | 'makkahHotel' | 'main',
    field: string, 
    value: string | number | boolean
  ) => {
    setEditableOrderData(prev => {
        const newState: any = JSON.parse(JSON.stringify(prev || {}));

        if (targetType === 'madinahHotel' || targetType === 'makkahHotel') {
            let hotelToUpdate: HotelInfo = newState[targetType] ? { ...newState[targetType] } : { ...initialHotelInfoForEdit };
            
            if (field.startsWith('rooms.')) {
                const roomSubField = field.split('.')[1] as keyof RoomBooking;
                hotelToUpdate.rooms[roomSubField] = Math.max(0, Number(value));
            } else if (field === 'nights') {
                hotelToUpdate.nights = Math.max(1, Number(value));
            } else if (field === 'name' || field === 'checkIn' || field === 'checkOut') {
                 (hotelToUpdate as any)[field] = String(value);
            }
            
            if ((field === 'checkIn' || field === 'nights') && hotelToUpdate.checkIn && hotelToUpdate.nights > 0) {
                const checkInDate = new Date(hotelToUpdate.checkIn);
                if (!isNaN(checkInDate.getTime())) {
                     checkInDate.setDate(checkInDate.getDate() + hotelToUpdate.nights);
                     hotelToUpdate.checkOut = checkInDate.toISOString().split('T')[0];
                }
            }
            newState[targetType] = hotelToUpdate;

        } else { // targetType === 'main'
            if (order?.serviceType === ServiceType.HOTEL) {
                const mainFieldKey = field as keyof HotelBookingData;
                if (mainFieldKey === 'visaVehicleType') {
                    (newState as HotelBookingData)[mainFieldKey] = String(value) as HotelBookingData['visaVehicleType'];
                } else if (mainFieldKey === 'customerName' || mainFieldKey === 'phone' || mainFieldKey === 'address' || mainFieldKey === 'ppiuName' || mainFieldKey === 'muasasahName' || mainFieldKey === 'visaAirlineName' || mainFieldKey === 'visaArrivalDate' || mainFieldKey === 'visaDepartureDate') {
                    (newState as HotelBookingData)[mainFieldKey] = String(value);
                } else if (mainFieldKey === 'includeHandling' || mainFieldKey === 'includeVisa') {
                  (newState as HotelBookingData)[mainFieldKey] = value as boolean;
                  if (mainFieldKey === 'includeHandling' && !(value as boolean)) (newState as HotelBookingData).handlingPax = 0;
                  if (mainFieldKey === 'includeVisa' && !(value as boolean)) { 
                    (newState as HotelBookingData).visaPax = 0;
                    (newState as HotelBookingData).visaVehicleType = '';
                    (newState as HotelBookingData).visaAirlineName = '';
                    (newState as HotelBookingData).visaArrivalDate = '';
                    (newState as HotelBookingData).visaDepartureDate = '';
                  }
                } else if (mainFieldKey === 'handlingPax' || mainFieldKey === 'visaPax') {
                  (newState as HotelBookingData)[mainFieldKey] = Math.max(0, Number(value));
                } 
            } else if (order?.serviceType === ServiceType.VISA) {
                const mainFieldKey = field as keyof VisaBookingData;
                 if (mainFieldKey === 'vehicleType') {
                    (newState as VisaBookingData)[mainFieldKey] = String(value) as VisaBookingData['vehicleType'];
                } else if (mainFieldKey === 'customerName' || mainFieldKey === 'phone' || mainFieldKey === 'address' || mainFieldKey === 'ppiuName' || mainFieldKey === 'muasasahName') {
                    (newState as VisaBookingData)[mainFieldKey] = String(value);
                } else if (mainFieldKey === 'pax') {
                  (newState as VisaBookingData)[mainFieldKey] = Math.max(0, Number(value));
                }
            } else if (order?.serviceType === ServiceType.HANDLING) {
                const mainFieldKey = field as keyof HandlingBookingData;
                if (mainFieldKey === 'customerName' || mainFieldKey === 'phone' || mainFieldKey === 'address' || mainFieldKey === 'ppiuName' || mainFieldKey === 'mutowifName') {
                    (newState as HandlingBookingData)[mainFieldKey] = String(value);
                } else if (mainFieldKey === 'includeMutowif') {
                  (newState as HandlingBookingData)[mainFieldKey] = value as boolean;
                   if (!(value as boolean)) (newState as HandlingBookingData).mutowifName = '';
                } else if (mainFieldKey === 'pax') {
                  (newState as HandlingBookingData)[mainFieldKey] = Math.max(0, Number(value));
                }
            } else if (order?.serviceType === ServiceType.JASTIP) {
                const mainFieldKey = field as keyof JastipBookingData;
                 if (mainFieldKey === 'itemType') {
                    (newState as JastipBookingData)[mainFieldKey] = String(value) as JastipItemType | '';
                 } else if (mainFieldKey === 'unit') {
                    (newState as JastipBookingData)[mainFieldKey] = String(value) as JastipUnit | '';
                 } else if (mainFieldKey === 'customerName' || mainFieldKey === 'phone' || mainFieldKey === 'deliveryAddress' || mainFieldKey === 'notes') {
                    (newState as JastipBookingData)[mainFieldKey] = String(value) as any; 
                } else if (mainFieldKey === 'quantity') {
                  (newState as JastipBookingData)[mainFieldKey] = Math.max(1, Number(value));
                }
            }
        }
        return newState;
    });
  }, [order?.serviceType]);

  const saveOrderDataChanges = async () => {
    if (!orderId || !order || Object.keys(editableOrderData).length === 0) return;
    setIsSubmitting(true);
    setError(null);
    try {
        const orderWithUpdatedData = await updateOrderData(orderId, editableOrderData);

        if (orderWithUpdatedData) {
            let finalOrderToSet = orderWithUpdatedData;

            if (orderWithUpdatedData.serviceType === ServiceType.HOTEL) {
                const hotelBookingData = orderWithUpdatedData.data as HotelBookingData;
                
                let ppiuNameForPlaceholder: string | undefined;
                const customerNameForPlaceholder: string = hotelBookingData.customerName; 

                if ('ppiuName' in hotelBookingData) {
                    ppiuNameForPlaceholder = hotelBookingData.ppiuName;
                }

                const basePackageInfo = orderWithUpdatedData.packageInfo || initialPackageInfo;
                let groupCodeToUse = basePackageInfo.groupCode;
                if (!groupCodeToUse) {
                    groupCodeToUse = generateGroupCodePlaceholder(ppiuNameForPlaceholder, customerNameForPlaceholder, orderWithUpdatedData.createdAt);
                }
                const currentPackageInfoWithEnsuredGroupCode = { ...basePackageInfo, groupCode: groupCodeToUse };
                
                const newPackageInfoData: PackageInfoData = {
                    ...currentPackageInfoWithEnsuredGroupCode,
                    ppiuName: hotelBookingData.ppiuName || currentPackageInfoWithEnsuredGroupCode.ppiuName,
                    ppiuPhone: hotelBookingData.phone || currentPackageInfoWithEnsuredGroupCode.ppiuPhone, 
                    paxCount: hotelBookingData.handlingPax || hotelBookingData.visaPax || currentPackageInfoWithEnsuredGroupCode.paxCount || 0,
                    
                    madinahHotelStructured: hotelBookingData.madinahHotel && hotelBookingData.madinahHotel.name 
                                            ? { ...hotelBookingData.madinahHotel } 
                                            : undefined,
                    makkahHotelStructured: hotelBookingData.makkahHotel && hotelBookingData.makkahHotel.name 
                                           ? { ...hotelBookingData.makkahHotel }
                                           : undefined,
                };
                newPackageInfoData.madinahHotelInfo = newPackageInfoData.madinahHotelStructured ? formatHotelToStringForPackageInfo(newPackageInfoData.madinahHotelStructured) : '';
                newPackageInfoData.makkahHotelInfo = newPackageInfoData.makkahHotelStructured ? formatHotelToStringForPackageInfo(newPackageInfoData.makkahHotelStructured) : '';
                
                const orderWithUpdatedPackageInfo = await updatePackageInfo(orderId, newPackageInfoData);
                if (orderWithUpdatedPackageInfo) {
                    finalOrderToSet = orderWithUpdatedPackageInfo;
                } else {
                    console.warn("Gagal menyimpan packageInfo yang diperbarui. Menampilkan packageInfo yang diperbarui secara lokal.");
                    finalOrderToSet = { ...orderWithUpdatedData, packageInfo: newPackageInfoData };
                }
            }
            
            setOrder(finalOrderToSet); 
            setIsEditingOrderData(false);
            alert("Detail pesanan berhasil diperbarui.");
        } else {
            throw new Error("Gagal memperbarui data pesanan.");
        }
    } catch (err) {
        setError("Gagal menyimpan perubahan detail pesanan.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
};
  
  const handlePackageInfoFormHotelChange = useCallback((
    hotelFieldKey: 'madinahHotelStructured' | 'makkahHotelStructured',
    field: string, 
    value: string | number
  ) => {
    setPackageInfoForm(prev => {
        const hotelToUpdate: HotelInfo = JSON.parse(JSON.stringify(prev[hotelFieldKey] || initialHotelInfoForEdit)); 
    
        if (field.startsWith('rooms.')) {
          const roomSubField = field.split('.')[1] as keyof RoomBooking;
          hotelToUpdate.rooms[roomSubField] = Math.max(0, Number(value));
        } else {
          const typedField = field as keyof HotelInfo;
          if (typedField === 'name') {
              hotelToUpdate.name = String(value);
          } else if (typedField === 'checkIn') {
              hotelToUpdate.checkIn = String(value);
          } else if (typedField === 'checkOut') { 
              hotelToUpdate.checkOut = String(value);
          } else if (typedField === 'nights') {
              hotelToUpdate.nights = Math.max(1, Number(value));
          }
        }
    
        if ((field === 'checkIn' || field === 'nights') && hotelToUpdate.checkIn && hotelToUpdate.nights > 0) {
          const checkInDate = new Date(hotelToUpdate.checkIn);
          if (!isNaN(checkInDate.getTime())) {
            checkInDate.setDate(checkInDate.getDate() + hotelToUpdate.nights);
            hotelToUpdate.checkOut = checkInDate.toISOString().split('T')[0];
          }
        }
        
        return { ...prev, [hotelFieldKey]: hotelToUpdate };
      });
  }, []);


  const handlePackageInfoFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'busVehicleId') {
        const selectedVehicle = availableVehicles.find(v => v.id === value);
        setPackageInfoForm(prev => ({
            ...prev,
            busVehicleId: value,
            busName: selectedVehicle?.name || '',
            busVehicleType: selectedVehicle?.type || '',
            busDriverName: selectedVehicle?.driverName || '',
            busDriverPhone: selectedVehicle?.driverPhone || '',
            busSyarikahNumber: selectedVehicle?.companyName || '', 
        }));
    } else {
        setPackageInfoForm(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleAddBusRoutePackageInfo = () => {
    setPackageInfoForm(prev => ({
        ...prev,
        busRoutes: [...(prev.busRoutes || []), { id: uuidv4(), date: '', from: '', to: '', routeVehicleId: '', vehicleDetails: '' }]
    }));
  };
  
  const handleBusRouteChangePackageInfo = (index: number, field: keyof Omit<BusRouteItem, 'id'>, value: string) => {
    setPackageInfoForm(prev => {
        const newRoutes = [...(prev.busRoutes || [])];
        const routeToUpdate: BusRouteItem = { ...newRoutes[index] };
        
        if (field === 'date' || field === 'from' || field === 'to' || field === 'vehicleDetails') {
            (routeToUpdate as any)[field] = value; 
        } else if (field === 'routeVehicleId') {
            routeToUpdate.routeVehicleId = value;
            const selectedVehicle = availableVehicles.find(v => v.id === value);
            routeToUpdate.vehicleDetails = selectedVehicle 
                ? `${selectedVehicle.name} (${selectedVehicle.plateNumber}) - Driver: ${selectedVehicle.driverName || '-'}` 
                : '';
        }

        newRoutes[index] = routeToUpdate;
        return { ...prev, busRoutes: newRoutes };
    });
  };
  
  const handleRemoveBusRoutePackageInfo = (index: number) => {
    setPackageInfoForm(prev => ({
        ...prev,
        busRoutes: (prev.busRoutes || []).filter((_, i) => i !== index)
    }));
  };

  const handleAddZiarahRoutePackageInfo = () => {
    setPackageInfoForm(prev => ({
      ...prev,
      ziarahRoutes: [...(prev.ziarahRoutes || []), { id: uuidv4(), tujuan: '', kota: '', tanggal: '', waktu: '', remake: '' }]
    }));
  };

  const handleZiarahRouteChangePackageInfo = (index: number, field: keyof Omit<ZiarahRouteItem, 'id'>, value: string) => {
    setPackageInfoForm(prev => {
      const newZiarahRoutes = [...(prev.ziarahRoutes || [])];
      const routeToUpdate = { ...newZiarahRoutes[index] };
      
       if (field === 'kota') {
        routeToUpdate.kota = value as ZiarahRouteItem['kota'];
      } else if (field === 'remake') {
        routeToUpdate.remake = value as ZiarahRouteItem['remake'];
      } else if (field === 'tujuan' || field === 'tanggal' || field === 'waktu') {
         (routeToUpdate as Record<string, string>)[field] = value;
      }
      newZiarahRoutes[index] = routeToUpdate;
      return { ...prev, ziarahRoutes: newZiarahRoutes };
    });
  };

  const handleRemoveZiarahRoutePackageInfo = (index: number) => {
    setPackageInfoForm(prev => ({
      ...prev,
      ziarahRoutes: (prev.ziarahRoutes || []).filter((_, i) => i !== index)
    }));
  };


const handleEditPackageInfoClick = async () => {
    if (availableVehicles.length === 0) { 
        try {
            const vehicles = await getVehicles();
            setAvailableVehicles(vehicles);
        } catch (err) {
            console.error("Failed to load vehicles for package info form:", err);
        }
    }

    if (order) {
        let currentFormState: PackageInfoData = { 
            ...initialPackageInfo, 
            ...(order.packageInfo || {}),
             madinahHotelStructured: JSON.parse(JSON.stringify(order.packageInfo?.madinahHotelStructured || (order.data as HotelBookingData)?.madinahHotel || initialHotelInfoForEdit)), 
             makkahHotelStructured: JSON.parse(JSON.stringify(order.packageInfo?.makkahHotelStructured || (order.data as HotelBookingData)?.makkahHotel || initialHotelInfoForEdit)), 
            ewakoRoyalPhone: order.packageInfo?.ewakoRoyalPhone || ADMIN_WHATSAPP_NUMBER,
            ziarahRoutes: order.packageInfo?.ziarahRoutes ? [...order.packageInfo.ziarahRoutes] : [], 
         };
        
        if (order.packageInfo?.busVehicleId) {
            const selectedVehicle = availableVehicles.find(v => v.id === order.packageInfo?.busVehicleId) || (await getVehicles()).find(v => v.id === order.packageInfo?.busVehicleId);
            if (selectedVehicle) {
                currentFormState = {
                    ...currentFormState,
                    busVehicleId: selectedVehicle.id,
                    busName: selectedVehicle.name,
                    busVehicleType: selectedVehicle.type,
                    busDriverName: selectedVehicle.driverName || '',
                    busDriverPhone: selectedVehicle.driverPhone || '',
                    busSyarikahNumber: selectedVehicle.companyName || '', 
                };
            }
        } 
        if (order.data && order.serviceType === ServiceType.HOTEL) {
            const hotelData = order.data as HotelBookingData;
            if (!currentFormState.madinahHotelStructured?.name && hotelData.madinahHotel?.name) {
                 currentFormState.madinahHotelStructured = JSON.parse(JSON.stringify(hotelData.madinahHotel));
            }
            if (!currentFormState.makkahHotelStructured?.name && hotelData.makkahHotel?.name) {
                 currentFormState.makkahHotelStructured = JSON.parse(JSON.stringify(hotelData.makkahHotel));
            }
            currentFormState.ppiuName = hotelData.ppiuName || currentFormState.ppiuName;
            currentFormState.ppiuPhone = hotelData.phone || currentFormState.ppiuPhone;
            currentFormState.airlineName = hotelData.visaAirlineName || currentFormState.airlineName;
            currentFormState.arrivalDateTime = hotelData.visaArrivalDate || currentFormState.arrivalDateTime;
            currentFormState.departureDateTime = hotelData.visaDepartureDate || currentFormState.departureDateTime;
        }
        
        let pax = 0;
        if (order.serviceType === ServiceType.HOTEL) {
            const hotelD = order.data as HotelBookingData;
            if (hotelD.visaPax && hotelD.visaPax > 0) pax = hotelD.visaPax;
            else if (hotelD.handlingPax && hotelD.handlingPax > 0) pax = hotelD.handlingPax;
        } else if (order.serviceType === ServiceType.VISA) {
            pax = (order.data as VisaBookingData).pax || 0;
        } else if (order.serviceType === ServiceType.HANDLING) {
            pax = (order.data as HandlingBookingData).pax || 0;
        }
        currentFormState.paxCount = pax > 0 ? pax : (currentFormState.paxCount || 0);

        if (currentFormState.busRoutes && currentFormState.busRoutes.length > 0) {
            currentFormState.busRoutes = currentFormState.busRoutes.map(route => {
                let vehicleDetails = route.vehicleDetails || '';
                if (route.routeVehicleId) {
                    const foundVehicle = availableVehicles.find(v => v.id === route.routeVehicleId);
                    if (foundVehicle) {
                        vehicleDetails = `${foundVehicle.name} (${foundVehicle.plateNumber}) - Driver: ${foundVehicle.driverName || '-'}`;
                    }
                }
                 return { ...route, vehicleDetails }; 
            });
        } else {
             currentFormState.busRoutes = [];
        }
        
        currentFormState.madinahHotelInfo = formatHotelToStringForPackageInfo(currentFormState.madinahHotelStructured);
        currentFormState.makkahHotelInfo = formatHotelToStringForPackageInfo(currentFormState.makkahHotelStructured);


        setPackageInfoForm(currentFormState);
    }
    setIsEditingPackageInfo(true);
};


  const handleSavePackageInfo = async () => {
    if (!orderId || !packageInfoForm) return;
    setIsSubmitting(true);
    try {
        const packageDataToSave = { ...packageInfoForm };
        packageDataToSave.madinahHotelInfo = formatHotelToStringForPackageInfo(packageDataToSave.madinahHotelStructured);
        packageDataToSave.makkahHotelInfo = formatHotelToStringForPackageInfo(packageDataToSave.makkahHotelStructured);
        
        const updatedOrder = await updatePackageInfo(orderId, packageDataToSave);
        if (updatedOrder) {
            setOrder(updatedOrder);
            setIsEditingPackageInfo(false);
            alert("Informasi paket berhasil disimpan/diperbarui.");
            await fetchOrderDetails(false); 
        }
    } catch (err) {
        setError("Gagal menyimpan informasi paket.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleOpenManifestForm = (item?: ManifestItem) => {
    if (item) {
        setCurrentEditingManifestItem(item);
        const { id, usia, ...formData } = item;
        setManifestItemForm(formData);
    } else {
        setCurrentEditingManifestItem(null);
        setManifestItemForm(initialManifestItemForm);
    }
    setShowManifestFormModal(true);
  };
  
  const handleCloseManifestForm = () => {
    setShowManifestFormModal(false);
    setCurrentEditingManifestItem(null);
    setManifestItemForm(initialManifestItemForm);
    setManifestItemAge(undefined);
  };

  const handleManifestItemFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setManifestItemForm({ ...manifestItemForm, [e.target.name]: e.target.value });
  };
  
  const handleSaveManifestItem = async () => {
    if(!order || !orderId) return;
    setIsSubmitting(true);
    try {
        let currentManifest = order.manifest || [];
        if (currentEditingManifestItem) { 
            currentManifest = currentManifest.map(item => 
                item.id === currentEditingManifestItem.id 
                ? { ...currentEditingManifestItem, ...manifestItemForm, usia: calculateAge(manifestItemForm.tanggalLahir) } 
                : item
            );
        } else { 
            const newItem: ManifestItem = {
                id: uuidv4(),
                ...manifestItemForm,
                usia: calculateAge(manifestItemForm.tanggalLahir),
            };
            currentManifest.push(newItem);
        }
        const updatedOrder = await updateOrderManifest(orderId, currentManifest);
        if (updatedOrder) {
            setOrder(updatedOrder);
            handleCloseManifestForm();
            alert(`Item manifest berhasil ${currentEditingManifestItem ? 'diperbarui' : 'ditambahkan'}.`);
        }
    } catch (err) {
        setError(`Gagal menyimpan item manifest.`);
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleDeleteManifestItem = async (itemId: string) => {
    if(!order || !orderId || !window.confirm("Yakin ingin menghapus item manifest ini?")) return;
    setIsSubmitting(true); 
    try {
        const currentManifest = (order.manifest || []).filter(item => item.id !== itemId);
        const updatedOrder = await updateOrderManifest(orderId, currentManifest);
        if (updatedOrder) {
            setOrder(updatedOrder);
            alert("Item manifest berhasil dihapus.");
        }
    } catch (err) {
        setError("Gagal menghapus item manifest.");
        console.error(err);
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleOpenChatModal = async () => {
    if (!order || !currentAuthUserId || !currentUser) return;
    setShowChatModal(true);
    setIsLoadingChatMessages(true);
    try {
        const messages = await getChatMessagesForOrder(order.id);
        setChatMessages(messages);
    } catch (error) {
        console.error("Failed to load chat messages:", error);
        setChatMessages([]); 
    } finally {
        setIsLoadingChatMessages(false);
    }
  };

  const handleSendChatMessage = async (text?: string, file?: File) => {
    if (!order || !currentUser || (!text && !file)) return;
    setIsSendingChatMessage(true);
    try {
        const newMessage = await sendChatMessage(order.id, currentUser.name, currentUser.id, text, file);
        if (newMessage) {
            setChatMessages(prev => [...prev, newMessage]);
        }
    } catch (err: any) {
        console.error("Failed to send chat message:", err);
        setError("Gagal mengirim pesan chat: " + err.message);
    } finally {
        setIsSendingChatMessage(false);
    }
  };

  const handleCustomerPaymentFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCustomerPaymentForm(prev => ({ ...prev, [name]: name === 'amount' ? parseFloat(value) || 0 : value }));
  };

  const handleCustomerProofFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const allowedTypes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg'];
      const maxSize = 2 * 1024 * 1024; // 2MB
      if (!allowedTypes.includes(file.type)) {
        alert('Format file tidak didukung. Harap unggah PDF, PNG, atau JPG.');
        setSelectedProofFile(null); e.target.value = ''; return;
      }
      if (file.size > maxSize) {
        alert('Ukuran file terlalu besar. Maksimal 2MB.');
        setSelectedProofFile(null); e.target.value = ''; return;
      }
      setSelectedProofFile(file);
    } else { setSelectedProofFile(null); }
  };

  const handleCustomerSubmitPayment = async () => {
    if (!order || !orderId || !currentAuthUserId) return;
    if (customerPaymentForm.amount <= 0) {
        setCustomerPaymentStatus({ type: 'error', message: 'Jumlah pembayaran harus lebih dari 0.' }); return;
    }
    if (customerPaymentForm.paymentMethod === 'Transfer') {
        if (!selectedProofFile) { 
            setCustomerPaymentStatus({ type: 'error', message: 'Bukti transfer wajib diunggah.' }); return; 
        }
        if (!customerPaymentForm.senderAccountName || !customerPaymentForm.senderAccountNumber || !customerPaymentForm.senderBankName || !customerPaymentForm.senderTransferMethod) {
            setCustomerPaymentStatus({ type: 'error', message: 'Detail rekening pengirim wajib diisi lengkap untuk metode Transfer Bank.' }); return;
        }
    }
     if (customerPaymentForm.paymentMethod === 'Midtrans VA' && !customerPaymentForm.paymentGatewayType) {
        setCustomerPaymentStatus({type: 'error', message: 'Pilih salah satu opsi Virtual Account Midtrans.'}); return;
    }

    setIsSubmitting(true); setCustomerPaymentStatus(null);
    try {
        const paymentDetailsToSend: AddPaymentPayload = { 
          userId: currentAuthUserId,
          amount: customerPaymentForm.amount,
          paymentDate: customerPaymentForm.paymentDate,
          paymentType: customerPaymentForm.paymentType,
          paymentMethod: customerPaymentForm.paymentMethod,
          notes: customerPaymentForm.notes,
          senderAccountName: customerPaymentForm.senderAccountName,
          senderAccountNumber: customerPaymentForm.senderAccountNumber,
          senderBankName: customerPaymentForm.senderBankName,
          senderTransferMethod: customerPaymentForm.senderTransferMethod,
          destinationBankName: customerPaymentForm.destinationBankName, 
          destinationAccountNumber: customerPaymentForm.destinationAccountNumber,
          paymentGatewayType: customerPaymentForm.paymentGatewayType,
          paymentApprovalStatus: 'Pending',
        };
        const updatedOrder = await addPaymentToOrder(orderId, paymentDetailsToSend, selectedProofFile || undefined);
        if (updatedOrder) {
            setOrder(updatedOrder);
            setShowCustomerPaymentForm(false);
            setCustomerPaymentForm(initialCustomerPaymentForm(currentAuthUserId));
            setSelectedProofFile(null);
            setCustomerPaymentStatus({ type: 'success', message: 'Informasi pembayaran berhasil dikirim. Admin akan segera memverifikasi.' });
            if (currentUser) {
              sendNotificationToCustomer(ADMIN_WHATSAPP_NUMBER, `Pelanggan ${currentUser?.name || order.data.customerName} telah melakukan pembayaran untuk Order ID: ${orderId.substring(0,8)} sejumlah ${formatCurrency(paymentDetailsToSend.amount, 'IDR')} via ${paymentDetailsToSend.paymentMethod}. Mohon dicek.`);
            }
        } else { throw new Error("Gagal menyimpan pembayaran"); }
    } catch (err) {
        console.error(err);
        setCustomerPaymentStatus({ type: 'error', message: 'Gagal mengirim informasi pembayaran. Silakan coba lagi.' });
    } finally { setIsSubmitting(false); }
  };

  const canMakePayment = order && order.totalPrice && order.totalPrice > 0 && order.status !== OrderStatus.FULLY_PAID && order.status !== OrderStatus.CANCELLED && order.status !== OrderStatus.REJECTED_BY_CUSTOMER && order.status !== OrderStatus.REQUEST_CONFIRMATION;

  const handleViewPaymentProof = (payment: Payment) => {
    if (payment.paymentProofFileDataUrl && payment.paymentProofFileType?.startsWith('image/')) {
        const imageWindow = window.open();
        if (imageWindow) {
            imageWindow.document.write(`<body style="margin:0; background: #222;"><img src="${payment.paymentProofFileDataUrl}" style="display:block; margin: auto; max-width:100%; max-height:100vh; object-fit:contain;" alt="Bukti Pembayaran: ${payment.paymentProofFileName || 'image'}"/></body>`);
            imageWindow.document.title = payment.paymentProofFileName || 'Bukti Pembayaran';
        }
    } else if (payment.paymentProofFileName) {
        // Simulate download for non-image or large files
        const fileName = payment.paymentProofFileName;
        const fileType = payment.paymentProofFileType || 'application/octet-stream';
        const mockContent = `Ini adalah simulasi unduhan untuk file: ${fileName}\nTipe file: ${fileType}\nURL Data (jika ada dan ini bukan gambar atau terlalu besar): ${payment.paymentProofFileDataUrl ? 'Ada Data URL (tidak ditampilkan di sini)' : 'Tidak ada Data URL yang dapat ditampilkan langsung'}\n\nDalam aplikasi nyata, ini akan menjadi file ${fileName} yang sebenarnya.`;
        const blob = new Blob([mockContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `mock_download_EWAKO_${fileName.replace(/[^a-zA-Z0-9.]/g, '_')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        alert(`Simulasi unduh untuk: ${fileName}. Sebuah file teks akan diunduh.`);
    } else {
        alert("Tidak ada file bukti pembayaran yang dapat ditampilkan atau diunduh.");
    }
  };


  if (isLoading && !order) return <Layout><div className="flex justify-center items-center h-64"><LoadingSpinner /></div></Layout>;
  if (error && !order) return <Layout><p className="text-red-300 bg-red-700/50 backdrop-blur-sm p-4 rounded-lg text-center">{error}</p></Layout>;
  if (!order) return <Layout><p className="text-indigo-200 text-center">Detail pesanan tidak ditemukan.</p></Layout>;

  const data = order.data as any; 
  const canEditOrderDataByUser = order.status === OrderStatus.REQUEST_CONFIRMATION && userRole === 'customer';
  const canUserModifyDetails = userRole === 'customer' && (order.status === OrderStatus.REQUEST_CONFIRMATION || order.status === OrderStatus.TENTATIVE_CONFIRMATION || order.status === OrderStatus.DEFINITE_CONFIRMATION);


  const renderHotelInfoBlock = (hotelInfo: HotelInfo | undefined, city: string) => {
    if (!hotelInfo || !hotelInfo.name) {
      return (
        <div className="py-2 text-indigo-200">
          <p><strong className="text-white">{city}:</strong> Tidak ada data hotel.</p>
        </div>
      );
    }
    const roomDetailsArray: string[] = [];
    if (hotelInfo.rooms.quad > 0) roomDetailsArray.push(`Quad(${hotelInfo.rooms.quad})`);
    if (hotelInfo.rooms.triple > 0) roomDetailsArray.push(`Triple(${hotelInfo.rooms.triple})`);
    if (hotelInfo.rooms.double > 0) roomDetailsArray.push(`Double(${hotelInfo.rooms.double})`);
    const roomText = roomDetailsArray.length > 0 ? roomDetailsArray.join(', ') : 'Tidak ada rincian kamar';

    let costDisplay = '';
    if (userRole === 'customer' && hotelInfo.pricesSAR && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice)) {
      let hotelTotalCostSAR = 0;
      if (hotelInfo.rooms.quad > 0 && hotelInfo.pricesSAR.quad) {
        hotelTotalCostSAR += hotelInfo.pricesSAR.quad * hotelInfo.nights * hotelInfo.rooms.quad;
      }
      if (hotelInfo.rooms.triple > 0 && hotelInfo.pricesSAR.triple) {
        hotelTotalCostSAR += hotelInfo.pricesSAR.triple * hotelInfo.nights * hotelInfo.rooms.triple;
      }
      if (hotelInfo.rooms.double > 0 && hotelInfo.pricesSAR.double) {
        hotelTotalCostSAR += hotelInfo.pricesSAR.double * hotelInfo.nights * hotelInfo.rooms.double;
      }
      if (hotelTotalCostSAR > 0) {
        costDisplay = ` (${formatCurrency(hotelTotalCostSAR, 'SAR')}, setara ${formatCurrency(convertToIDR(hotelTotalCostSAR, 'SAR'), 'IDR')})`;
      }
    } else if (userRole === 'customer' && order.status === OrderStatus.REQUEST_CONFIRMATION && !order.totalPrice) {
      costDisplay = ` (Harga akan ditetapkan admin)`;
    }


    return (
      <div className="py-2 mb-3 last:mb-0 last:border-b-0 border-b border-white/10 pb-3">
        <p className="font-semibold text-white">{city}: {hotelInfo.name}{costDisplay}</p>
        <div className="pl-4 mt-1 space-y-0.5 text-sm">
            <p className="text-indigo-200"><strong className="text-indigo-100">Kamar:</strong> {roomText}</p>
            <p className="text-indigo-200"><strong className="text-indigo-100">Durasi:</strong> {hotelInfo.nights} malam</p>
            <p className="text-indigo-200"><strong className="text-indigo-100">Check In:</strong> {formatDateForDisplay(hotelInfo.checkIn)}</p>
            <p className="text-indigo-200"><strong className="text-indigo-100">Check Out:</strong> {formatDateForDisplay(hotelInfo.checkOut)}</p>
        </div>
      </div>
    );
  };
  
  const renderHotelEditFormSection = (currentHotelData: HotelInfo | undefined, hotelType: 'madinahHotel' | 'makkahHotel', title: string) => {
    const hotelData = currentHotelData || initialHotelInfoForEdit;
    return (
        <Card title={title} className="mb-4 generic-card-glass">
            <div className="space-y-3 p-3">
                 <Input label="Nama Hotel" name="name" value={hotelData.name} onChange={(e) => handleEditOrderDataChange(hotelType, 'name', e.target.value)} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <Input label="Tanggal Check In" name="checkIn" type="date" value={hotelData.checkIn} onChange={(e) => handleEditOrderDataChange(hotelType, 'checkIn', e.target.value)} />
                    <Input label="Jumlah Malam" name="nights" type="number" min="1" value={String(hotelData.nights)} onChange={(e) => handleEditOrderDataChange(hotelType, 'nights', parseInt(e.target.value))} />
                </div>
                <Input label="Tanggal Check Out (Otomatis)" name="checkOut" type="date" value={hotelData.checkOut} readOnly className="bg-white/5 cursor-not-allowed" />
                <fieldset className="border border-white/20 p-3 rounded-md">
                    <legend className="text-sm font-medium text-indigo-200 px-1">Jumlah Kamar</legend>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-1">
                        <Input label="Quad" name="quad" type="number" min="0" value={String(hotelData.rooms.quad)} onChange={(e) => handleEditOrderDataChange(hotelType, 'rooms.quad', parseInt(e.target.value))} />
                        <Input label="Triple" name="triple" type="number" min="0" value={String(hotelData.rooms.triple)} onChange={(e) => handleEditOrderDataChange(hotelType, 'rooms.triple', parseInt(e.target.value))} />
                        <Input label="Double" name="double" type="number" min="0" value={String(hotelData.rooms.double)} onChange={(e) => handleEditOrderDataChange(hotelType, 'rooms.double', parseInt(e.target.value))} />
                    </div>
                </fieldset>
            </div>
        </Card>
    );
  };
  
  const renderHotelEditForm = (currentEditableData: Partial<HotelBookingData>): React.ReactNode => { 
    return (
      <Card title="Edit Detail Hotel Pesanan" className="my-4 generic-card-glass">
        <div className="p-4 space-y-4">
            <Input label="Nama Pemesan*" name="customerName" value={currentEditableData.customerName || ''} onChange={(e) => handleEditOrderDataChange('main', 'customerName', e.target.value)} required />
            <Input label="Nama PPIU/PIHK" name="ppiuName" value={currentEditableData.ppiuName || ''} onChange={(e) => handleEditOrderDataChange('main', 'ppiuName', e.target.value)} />
            <Input label="No. Handphone*" name="phone" type="tel" value={currentEditableData.phone || ''} onChange={(e) => handleEditOrderDataChange('main', 'phone', e.target.value)} required />
            <Textarea label="Alamat" name="address" value={currentEditableData.address || ''} onChange={(e) => handleEditOrderDataChange('main', 'address', e.target.value)} />
            
            {renderHotelEditFormSection(currentEditableData.madinahHotel, 'madinahHotel', 'Hotel Madinah')}
            {renderHotelEditFormSection(currentEditableData.makkahHotel, 'makkahHotel', 'Hotel Mekah')}

            <Card title="Layanan Tambahan (Edit)" className="generic-card-glass">
                <div className="space-y-3 p-3">
                    <div className="flex items-center">
                        <input id="editIncludeHandling" name="includeHandling" type="checkbox" checked={currentEditableData.includeHandling || false} onChange={(e) => handleEditOrderDataChange('main', 'includeHandling', e.target.checked)} className="form-checkbox-glass" />
                        <label htmlFor="editIncludeHandling" className="ml-2 block text-sm text-indigo-100">Include Handling Bandara</label>
                    </div>
                    {currentEditableData.includeHandling && <Input label="Jumlah Jemaah (Handling)" name="handlingPax" type="number" min="0" value={String(currentEditableData.handlingPax ?? 0)} onChange={(e) => handleEditOrderDataChange('main', 'handlingPax', parseInt(e.target.value))} />}

                    <div className="flex items-center">
                        <input id="editIncludeVisa" name="includeVisa" type="checkbox" checked={currentEditableData.includeVisa || false} onChange={(e) => handleEditOrderDataChange('main', 'includeVisa', e.target.checked)} className="form-checkbox-glass" />
                        <label htmlFor="editIncludeVisa" className="ml-2 block text-sm text-indigo-100">Include Visa</label>
                    </div>
                    {currentEditableData.includeVisa && (
                    <div className="ml-6 mt-2 space-y-3 p-3 border border-white/20 rounded-md">
                        <Input label="Jumlah Jemaah (Visa)*" name="visaPax" type="number" min="1" value={String(currentEditableData.visaPax ?? 0)} onChange={(e) => handleEditOrderDataChange('main', 'visaPax', parseInt(e.target.value))} required={currentEditableData.includeVisa} />
                        <Select label="Jenis Kendaraan (Visa)" name="visaVehicleType" value={currentEditableData.visaVehicleType || ''} onChange={(e) => handleEditOrderDataChange('main', 'visaVehicleType', e.target.value)} options={[{value: '', label: 'Pilih jenis'}, {value: 'Bus', label: 'Bus'}, {value: 'HiAce', label: 'HiAce'}, {value: 'SUV', label: 'SUV'}]} placeholder="Pilih Jenis Kendaraan" />
                        <Input label="Nama Maskapai (Visa)" name="visaAirlineName" value={currentEditableData.visaAirlineName || ''} onChange={(e) => handleEditOrderDataChange('main', 'visaAirlineName', e.target.value)} placeholder="Mis: Garuda Indonesia"/>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <Input label="Tgl & Waktu Kedatangan (Visa)*" name="visaArrivalDate" type="datetime-local" value={currentEditableData.visaArrivalDate || ''} onChange={(e) => handleEditOrderDataChange('main', 'visaArrivalDate', e.target.value)} required={currentEditableData.includeVisa} />
                            <Input label="Tgl & Waktu Kepulangan (Visa)*" name="visaDepartureDate" type="datetime-local" value={currentEditableData.visaDepartureDate || ''} onChange={(e) => handleEditOrderDataChange('main', 'visaDepartureDate', e.target.value)} required={currentEditableData.includeVisa} />
                        </div>
                    </div>
                    )}
                </div>
            </Card>

            <div className="flex space-x-2 pt-3">
                <Button variant="primary" onClick={saveOrderDataChanges} isLoading={isSubmitting}>Simpan Perubahan</Button>
                <Button variant="outline" onClick={() => setIsEditingOrderData(false)} disabled={isSubmitting}>Batal</Button>
            </div>
        </div>
      </Card>
    );
  };
  
  const renderPackageInfoEditFormHotelSection = (
    hotelFieldKey: 'madinahHotelStructured' | 'makkahHotelStructured',
    title: string
  ) => {
    const hotelData = packageInfoForm[hotelFieldKey] || { ...initialHotelInfoForEdit };
    return (
      <Card title={title} className="generic-card-glass my-3">
        <div className="p-3 space-y-2">
          <Input 
            label="Nama Hotel (Paket)" 
            name={`${hotelFieldKey}.name`} 
            value={hotelData.name} 
            onChange={(e) => handlePackageInfoFormHotelChange(hotelFieldKey, 'name', e.target.value)} 
          />
          <div className="grid grid-cols-2 gap-2">
            <Input 
              label="Check In" 
              type="date" 
              name={`${hotelFieldKey}.checkIn`} 
              value={hotelData.checkIn} 
              onChange={(e) => handlePackageInfoFormHotelChange(hotelFieldKey, 'checkIn', e.target.value)} 
            />
            <Input 
              label="Durasi (malam)" 
              type="number" 
              min="1" 
              name={`${hotelFieldKey}.nights`} 
              value={String(hotelData.nights)} 
              onChange={(e) => handlePackageInfoFormHotelChange(hotelFieldKey, 'nights', parseInt(e.target.value))} 
            />
          </div>
          <Input 
            label="Check Out (Otomatis)" 
            type="date" 
            name={`${hotelFieldKey}.checkOut`} 
            value={hotelData.checkOut} 
            readOnly 
            className="bg-white/5 cursor-not-allowed"
          />
          <fieldset className="border border-white/20 p-2 rounded-md">
            <legend className="text-sm font-medium text-indigo-200 px-1">Kamar (Paket)</legend>
            <div className="grid grid-cols-3 gap-2 mt-1">
              <Input 
                label="Quad" 
                type="number" 
                min="0" 
                name={`${hotelFieldKey}.rooms.quad`} 
                value={String(hotelData.rooms.quad)} 
                onChange={(e) => handlePackageInfoFormHotelChange(hotelFieldKey, 'rooms.quad', parseInt(e.target.value))} 
              />
              <Input 
                label="Triple" 
                type="number" 
                min="0" 
                name={`${hotelFieldKey}.rooms.triple`} 
                value={String(hotelData.rooms.triple)} 
                onChange={(e) => handlePackageInfoFormHotelChange(hotelFieldKey, 'rooms.triple', parseInt(e.target.value))} 
              />
              <Input 
                label="Double" 
                type="number" 
                min="0" 
                name={`${hotelFieldKey}.rooms.double`} 
                value={String(hotelData.rooms.double)} 
                onChange={(e) => handlePackageInfoFormHotelChange(hotelFieldKey, 'rooms.double', parseInt(e.target.value))} 
              />
            </div>
          </fieldset>
        </div>
      </Card>
    );
  };
  
  const renderPackageInfoEditForm = (): React.ReactNode => {
    const vehicleOptionsForSelect: Array<{ value: string; label: string }> = [
        { value: '', label: 'Pilih Kendaraan' },
        ...availableVehicles.map(v => ({ value: v.id, label: `${v.name} (${v.type} - ${v.plateNumber})` }))
    ];
    return (
    <Card title="Edit Informasi Paket" className="my-6 generic-card-glass">
        <form className="space-y-4 p-4" onSubmit={(e) => { e.preventDefault(); handleSavePackageInfo(); }}>
            <Input label="Kode Grup (Otomatis)" name="groupCode" value={packageInfoForm.groupCode || ''} readOnly className="bg-white/5 cursor-not-allowed" />
            <Input label="Nama PPIU/PIHK" name="ppiuName" value={packageInfoForm.ppiuName} onChange={handlePackageInfoFormChange} />
            <Input label="No. Telpon PPIU" name="ppiuPhone" type="tel" value={packageInfoForm.ppiuPhone} onChange={handlePackageInfoFormChange} />
            <Input label="Jumlah Jemaah (Pax)" name="paxCount" type="number" min="0" value={String(packageInfoForm.paxCount || 0)} onChange={handlePackageInfoFormChange} />
            
            {renderPackageInfoEditFormHotelSection('madinahHotelStructured', 'Hotel Madinah (Detail Paket)')}
            {renderPackageInfoEditFormHotelSection('makkahHotelStructured', 'Hotel Mekah (Detail Paket)')}
            
            <h3 className="text-lg font-semibold metallic-gold-text pt-2 border-t border-white/20 mt-3">Informasi Bus Utama</h3>
            <Select 
                label="Pilih Kendaraan Bus Utama" 
                name="busVehicleId" 
                value={packageInfoForm.busVehicleId || ''} 
                onChange={handlePackageInfoFormChange} 
                options={vehicleOptionsForSelect} 
            />
             {packageInfoForm.busVehicleId && (
                <div className="p-3 bg-white/5 rounded-md text-sm space-y-1">
                    <p><strong>Nama Bus Terpilih:</strong> {packageInfoForm.busName || '-'}</p>
                    <p><strong>Jenis Kendaraan:</strong> {packageInfoForm.busVehicleType || '-'}</p>
                    <p><strong>Nama Driver:</strong> {packageInfoForm.busDriverName || '-'}</p>
                    <p><strong>No. HP Driver:</strong> {packageInfoForm.busDriverPhone || '-'}</p>
                </div>
            )}
            <Input 
                label="Nomor Syarikah Bus Utama" 
                name="busSyarikahNumber" 
                value={packageInfoForm.busSyarikahNumber || ''} 
                readOnly
                className="bg-white/5 cursor-not-allowed"
                placeholder="Otomatis dari data kendaraan terpilih"
            />
            
            <fieldset className="border border-white/20 p-3 rounded-md">
                <legend className="text-lg font-semibold metallic-gold-text px-1">Rute Perjalanan Bus</legend>
                {(packageInfoForm.busRoutes || []).map((route, index) => (
                    <div key={route.id || index} className="mb-3 p-3 border border-white/15 rounded-md space-y-2 relative">
                        <h4 className="text-md font-medium text-indigo-100">Rute {index + 1}</h4>
                        <Input label={`Tanggal Rute`} type="date" value={route.date} onChange={(e) => handleBusRouteChangePackageInfo(index, 'date', e.target.value)} />
                        <Input label="Dari" value={route.from} onChange={(e) => handleBusRouteChangePackageInfo(index, 'from', e.target.value)} />
                        <Input label="Ke" value={route.to} onChange={(e) => handleBusRouteChangePackageInfo(index, 'to', e.target.value)} />
                        <Select 
                            label="Kendaraan untuk Rute Ini"
                            name={`routeVehicleId_${index}`}
                            value={route.routeVehicleId || ''}
                            onChange={(e) => handleBusRouteChangePackageInfo(index, 'routeVehicleId', e.target.value)}
                            options={vehicleOptionsForSelect}
                            placeholder="Pilih Kendaraan Rute"
                        />
                        {route.vehicleDetails && <p className="text-xs text-indigo-200 bg-white/5 p-1.5 rounded">Detail Kendaraan Rute: {route.vehicleDetails}</p>}
                        <Button type="button" onClick={() => handleRemoveBusRoutePackageInfo(index)} variant="danger" size="sm" className="absolute top-2 right-2 !p-1">
                            <TrashIcon className="h-4 w-4"/>
                        </Button>
                    </div>
                ))}
                <Button type="button" onClick={handleAddBusRoutePackageInfo} variant="outline" size="sm">Tambah Rute Bus</Button>
            </fieldset>

            <fieldset className="border border-white/20 p-3 rounded-md">
                <legend className="text-lg font-semibold metallic-gold-text px-1">Rute Ziarah / City Tour</legend>
                {(packageInfoForm.ziarahRoutes || []).map((route, index) => (
                    <div key={route.id || index} className="mb-3 p-3 border border-white/15 rounded-md space-y-2 relative">
                         <h4 className="text-md font-medium text-indigo-100">Ziarah/Tour {index + 1}</h4>
                        <Input label="Tujuan Ziarah/Tour" value={route.tujuan} onChange={(e) => handleZiarahRouteChangePackageInfo(index, 'tujuan', e.target.value)} />
                        <Select label="Kota" options={ziarahKotaOptions as { value: string | number; label: string }[]} value={route.kota} onChange={(e) => handleZiarahRouteChangePackageInfo(index, 'kota', e.target.value)} />
                        <Input label="Tanggal" type="date" value={route.tanggal} onChange={(e) => handleZiarahRouteChangePackageInfo(index, 'tanggal', e.target.value)} />
                        <Input label="Waktu (HH:MM)" type="time" value={route.waktu} onChange={(e) => handleZiarahRouteChangePackageInfo(index, 'waktu', e.target.value)} />
                        <Select label="Jenis (Remake)" options={ziarahRemakeOptions as { value: string | number; label: string }[]} value={route.remake} onChange={(e) => handleZiarahRouteChangePackageInfo(index, 'remake', e.target.value)} />
                        <Button type="button" onClick={() => handleRemoveZiarahRoutePackageInfo(index)} variant="danger" size="sm" className="absolute top-2 right-2 !p-1">
                            <TrashIcon className="h-4 w-4"/>
                        </Button>
                    </div>
                ))}
                <Button type="button" onClick={handleAddZiarahRoutePackageInfo} variant="outline" size="sm">Tambah Rute Ziarah/Tour</Button>
            </fieldset>

            <h3 className="text-lg font-semibold metallic-gold-text pt-2 border-t border-white/20 mt-3">Tim Pendamping (Request Pengguna)</h3>
             <Input label="Nama Mutowif (Request)" name="mutowifName" value={packageInfoForm.mutowifName || ''} onChange={handlePackageInfoFormChange} placeholder="Jika pengguna request mutowif tertentu"/>
             <Input label="No. Tlp Mutowif (Request)" name="mutowifPhone" type="tel" value={packageInfoForm.mutowifPhone || ''} onChange={handlePackageInfoFormChange} />
             <Input label="Nama Tour Leader (Request)" name="tourLeaderName" value={packageInfoForm.tourLeaderName || ''} onChange={handlePackageInfoFormChange} />
             <Input label="No. Tlp Tour Leader (Request)" name="tourLeaderPhone" type="tel" value={packageInfoForm.tourLeaderPhone || ''} onChange={handlePackageInfoFormChange} />
             <Input label="Nama Tour Guide (Request)" name="tourGuideName" value={packageInfoForm.tourGuideName || ''} onChange={handlePackageInfoFormChange} />
             <Input label="No. Tlp Tour Guide (Request)" name="tourGuidePhone" type="tel" value={packageInfoForm.tourGuidePhone || ''} onChange={handlePackageInfoFormChange} />


            <h3 className="text-lg font-semibold metallic-gold-text pt-2 border-t border-white/20 mt-3">Kontak & Penerbangan</h3>
            <Input label="Nama Perwakilan Saudi" name="representativeName" value={packageInfoForm.representativeName || ''} onChange={handlePackageInfoFormChange} />
            <Input label="No. Tlp Perwakilan Saudi" name="representativePhone" type="tel" value={packageInfoForm.representativePhone || ''} onChange={handlePackageInfoFormChange} />
            <Input label="No. Tlp Ewako Royal (PIC Saudi)" name="ewakoRoyalPhone" type="tel" value={packageInfoForm.ewakoRoyalPhone || ''} onChange={handlePackageInfoFormChange} />
            
            <Input label="Nama Maskapai" name="airlineName" value={packageInfoForm.airlineName || ''} onChange={handlePackageInfoFormChange} />
            <Input label="Kode Penerbangan / No. Tiket" name="airlineCode" value={packageInfoForm.airlineCode || ''} onChange={handlePackageInfoFormChange} />
            <Input label="Kode PNR" name="pnrCode" value={packageInfoForm.pnrCode || ''} onChange={handlePackageInfoFormChange} />
            <Input label="Tgl & Waktu Kedatangan Saudi" name="arrivalDateTime" type="datetime-local" value={packageInfoForm.arrivalDateTime || ''} onChange={handlePackageInfoFormChange} />
            <Input label="Terminal Kedatangan" name="arrivalTerminal" value={packageInfoForm.arrivalTerminal || ''} onChange={handlePackageInfoFormChange} />
            <Input label="Tgl & Waktu Kepulangan (dari Saudi)" name="departureDateTime" type="datetime-local" value={packageInfoForm.departureDateTime || ''} onChange={handlePackageInfoFormChange} />
            <Input label="Terminal Kepulangan" name="departureTerminal" value={packageInfoForm.departureTerminal || ''} onChange={handlePackageInfoFormChange} />


            <div className="flex justify-end space-x-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setIsEditingPackageInfo(false)} disabled={isSubmitting}>Batal</Button>
                <Button type="submit" variant="primary" isLoading={isSubmitting}>Simpan Info Paket</Button>
            </div>
        </form>
    </Card>
  );
  };
  
  const renderManifestFormModal = (): React.ReactNode => (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[60]"> 
        <Card 
            title={currentEditingManifestItem ? "Edit Item Manifest" : "Tambah Item Manifest"} 
            className="generic-card-glass w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        >
            <form onSubmit={(e) => { e.preventDefault(); handleSaveManifestItem(); }} className="space-y-3 p-1"> 
                <Input label="Nama Jemaah*" name="namaJemaah" value={manifestItemForm.namaJemaah} onChange={handleManifestItemFormChange} required />
                <Select
                    label="Jenis Kelamin*"
                    name="jenisKelamin"
                    value={manifestItemForm.jenisKelamin}
                    onChange={handleManifestItemFormChange}
                    options={[{ value: '', label: 'Pilih Jenis Kelamin' }, { value: 'Laki-laki', label: 'Laki-laki' }, { value: 'Perempuan', label: 'Perempuan' },]}
                    required
                />
                <Input label="Tanggal Lahir*" name="tanggalLahir" type="date" value={manifestItemForm.tanggalLahir} onChange={handleManifestItemFormChange} required />
                <p className="text-sm text-indigo-200">Usia: {manifestItemAge !== undefined ? `${manifestItemAge} tahun` : 'Mohon isi tanggal lahir'}</p>
                
                <Input label="Nomor Visa" name="nomorVisa" value={manifestItemForm.nomorVisa || ''} onChange={handleManifestItemFormChange} />
                <Input label="Nama Sesuai Paspor*" name="namaDiPaspor" value={manifestItemForm.namaDiPaspor} onChange={handleManifestItemFormChange} required />
                <Input label="Nomor Paspor*" name="nomorPaspor" value={manifestItemForm.nomorPaspor} onChange={handleManifestItemFormChange} required />
                <Input label="Tanggal Terbit Paspor*" name="tanggalTerbitPaspor" type="date" value={manifestItemForm.tanggalTerbitPaspor} onChange={handleManifestItemFormChange} required />
                <Input label="Tanggal Expired Paspor*" name="tanggalExpiredPaspor" type="date" value={manifestItemForm.tanggalExpiredPaspor} onChange={handleManifestItemFormChange} required />
                <Input label="Kota Tempat Issued Paspor" name="kotaTempatIssuedPaspor" value={manifestItemForm.kotaTempatIssuedPaspor || ''} onChange={handleManifestItemFormChange} />
                <Input label="Kota Asal Keberangkatan (Contoh: Jakarta, Surabaya)" name="kotaAsalKeberangkatan" value={manifestItemForm.kotaAsalKeberangkatan || ''} onChange={handleManifestItemFormChange} />


                <div className="flex justify-end space-x-2 pt-3">
                    <Button type="button" variant="outline" onClick={handleCloseManifestForm} disabled={isSubmitting}>Batal</Button>
                    <Button type="submit" variant="primary" isLoading={isSubmitting}>
                        {currentEditingManifestItem ? "Update Item" : "Simpan Item"}
                    </Button>
                </div>
            </form>
        </Card>
    </div>
  );

const renderCostBreakdown = (currentOrder: Order): React.ReactNode => {
    if (!currentOrder.totalPrice || currentOrder.totalPrice === 0) {
        return (
            <Card title="Rincian Biaya Estimasi" className="mt-6 generic-card-glass">
                <p className="text-indigo-200">Rincian biaya akan tersedia setelah Admin menetapkan harga dan mengkonfirmasi pesanan Anda.</p>
            </Card>
        );
    }

    const orderData = currentOrder.data as any;
    const costItems: Array<{label: string; valueSAR?: number; valueUSD?: number; valueIDR: number; originalCurrency?: 'SAR'|'USD'; originalValue?: number; qty?: string | number; pricePerUnit?: number }> = [];
  
    let runningTotalSAR = 0;
    let runningTotalUSD = 0;

    const addCostItem = (label: string, amount: number, currency: 'SAR' | 'USD', qty?: string | number, pricePerUnit?: number) => {
        const amountIDR = convertToIDR(amount, currency);
        const item = { label, valueIDR: amountIDR, originalCurrency: currency, originalValue: amount, qty, pricePerUnit };
        if (currency === 'SAR') {
            costItems.push({ ...item, valueSAR: amount });
            runningTotalSAR += amount;
        } else {
            costItems.push({ ...item, valueUSD: amount });
            runningTotalUSD += amount;
        }
    };

    if (currentOrder.serviceType === ServiceType.HOTEL) {
        const hotelData = orderData as HotelBookingData;
        
        const processHotelCosts = (hotelInfo: HotelInfo | undefined, prefix: string) => {
            if (hotelInfo && hotelInfo.name && hotelInfo.pricesSAR) {
                const prices = hotelInfo.pricesSAR;
                const processRoomType = (roomType: keyof RoomBooking, roomLabel: string, pricePerNightSAR?: number) => {
                    const roomCount = hotelInfo.rooms[roomType];
                    if (roomCount > 0 && pricePerNightSAR) {
                        const totalCostForRoomTypeSAR = pricePerNightSAR * hotelInfo.nights * roomCount;
                         addCostItem(
                            `${prefix} - ${hotelInfo.name} - Kamar ${roomLabel}`, 
                            totalCostForRoomTypeSAR, 
                            'SAR', 
                            `${roomCount}k x ${hotelInfo.nights}m`, 
                            pricePerNightSAR
                        );
                    }
                };
                processRoomType('quad', 'Quad', prices.quad);
                processRoomType('triple', 'Triple', prices.triple);
                processRoomType('double', 'Double', prices.double);
            }
        };
        processHotelCosts(hotelData.madinahHotel, "Hotel Madinah");
        processHotelCosts(hotelData.makkahHotel, "Hotel Mekah");

        if (hotelData.includeVisa && hotelData.visaPricePerPaxUSD && hotelData.visaPax) {
            addCostItem(`Visa (${hotelData.muasasahName || 'Umum'})`, hotelData.visaPricePerPaxUSD * hotelData.visaPax, 'USD', `${hotelData.visaPax} pax`, hotelData.visaPricePerPaxUSD);
        }
        if (hotelData.includeHandling && hotelData.handlingPricePerPaxSAR && hotelData.handlingPax) {
            addCostItem('Layanan Handling Bandara', hotelData.handlingPricePerPaxSAR * hotelData.handlingPax, 'SAR', `${hotelData.handlingPax} pax`, hotelData.handlingPricePerPaxSAR);
        }
        if (hotelData.busPriceTotalSAR && hotelData.busPriceTotalSAR > 0) {
            addCostItem('Transportasi Bus (Paket)', hotelData.busPriceTotalSAR, 'SAR', `1 paket`, hotelData.busPriceTotalSAR);
        }
    } else if (currentOrder.serviceType === ServiceType.VISA) {
        const visaData = orderData as VisaBookingData;
        if (visaData.visaPricePerPaxUSD && visaData.pax) {
            addCostItem(`Visa (${visaData.muasasahName || 'Umum'})`, visaData.visaPricePerPaxUSD * visaData.pax, 'USD', `${visaData.pax} pax`, visaData.visaPricePerPaxUSD);
        }
        if (visaData.busPriceTotalSAR && visaData.busPriceTotalSAR > 0) {
            addCostItem('Transportasi Bus (Paket Visa)', visaData.busPriceTotalSAR, 'SAR', `1 paket`, visaData.busPriceTotalSAR);
        }
    } else if (currentOrder.serviceType === ServiceType.HANDLING) {
        const handlingData = orderData as HandlingBookingData;
        if (handlingData.handlingPricePerPaxSAR && handlingData.pax) {
            addCostItem('Layanan Handling Bandara', handlingData.handlingPricePerPaxSAR * handlingData.pax, 'SAR', `${handlingData.pax} pax`, handlingData.handlingPricePerPaxSAR);
        }
    } else if (currentOrder.serviceType === ServiceType.JASTIP && currentOrder.totalPrice) {
        costItems.push({ 
            label: `Jasa Titipan: ${ (orderData as JastipBookingData).itemType } (${(orderData as JastipBookingData).quantity} ${(orderData as JastipBookingData).unit})`, 
            qty: 1,
            valueIDR: currentOrder.totalPrice 
        });
    }
    
    if (costItems.length === 0 && currentOrder.totalPrice && currentOrder.totalPrice > 0) { 
         costItems.push({ label: `Total Paket Layanan`, qty: 1, valueIDR: currentOrder.totalPrice });
    } else if (costItems.length === 0) {
         return (
            <Card title="Rincian Biaya Estimasi" className="mt-6 generic-card-glass">
                 <p className="text-indigo-200">Detail rincian biaya tidak tersedia. Total: {order.totalPrice ? formatCurrency(order.totalPrice, 'IDR') : '-'}</p>
            </Card>
        );
    }

    return (
        <Card title="Rincian Biaya Estimasi" className="mt-6 generic-card-glass">
            <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                    <thead className="border-b border-white/20">
                        <tr>
                            <th className="text-left py-2 px-2 text-indigo-300 font-medium">Deskripsi</th>
                            <th className="text-right py-2 px-2 text-indigo-300 font-medium">Kuantitas</th>
                            <th className="text-right py-2 px-2 text-indigo-300 font-medium">Harga Satuan</th>
                            <th className="text-right py-2 px-2 text-indigo-300 font-medium">Subtotal</th>
                            <th className="text-right py-2 px-2 text-indigo-300 font-medium">(IDR)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {costItems.map((item, index) => (
                            <tr key={index} className="border-b border-white/10 last:border-b-0 hover:bg-white/5">
                                <td className="py-2 px-2 text-indigo-100">{item.label}</td>
                                <td className="py-2 px-2 text-indigo-100 text-right">{item.qty || '1'}</td>
                                <td className="py-2 px-2 text-indigo-100 text-right">
                                    {item.pricePerUnit && item.originalCurrency 
                                        ? formatCurrency(item.pricePerUnit, item.originalCurrency) 
                                        : (item.originalValue && item.originalCurrency ? formatCurrency(item.originalValue, item.originalCurrency) : (item.valueIDR && !item.originalCurrency ? formatCurrency(item.valueIDR, 'IDR') : '-'))
                                    }
                                </td>
                                <td className="py-2 px-2 text-indigo-100 text-right">
                                    {item.valueSAR !== undefined && formatCurrency(item.valueSAR, 'SAR')}
                                    {item.valueUSD !== undefined && formatCurrency(item.valueUSD, 'USD')}
                                    {!item.valueSAR && !item.valueUSD && formatCurrency(item.valueIDR, 'IDR')}
                                </td>
                                <td className="py-2 px-2 text-indigo-100 text-right">
                                    {formatCurrency(item.valueIDR, 'IDR')}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {(runningTotalSAR > 0 || runningTotalUSD > 0) && (
                <div className="mt-4 pt-3 border-t border-white/20 space-y-1 text-sm">
                    {runningTotalSAR > 0 && <p className="flex justify-between text-indigo-100"><span>Subtotal Estimasi (SAR):</span> <span className="font-medium">{formatCurrency(runningTotalSAR, 'SAR')}</span></p>}
                    {runningTotalUSD > 0 && <p className="flex justify-between text-indigo-100"><span>Subtotal Estimasi (USD):</span> <span className="font-medium">{formatCurrency(runningTotalUSD, 'USD')}</span></p>}
                    <p className="text-xs text-indigo-300 mt-1">Kurs Estimasi: 1 USD = {formatCurrency(MOCK_EXCHANGE_RATES.USD_TO_IDR, 'IDR')}, 1 SAR = {formatCurrency(MOCK_EXCHANGE_RATES.SAR_TO_IDR, 'IDR')}</p>
                </div>
            )}
            <div className="mt-4 pt-3 border-t border-white/20">
                <p className="flex justify-between text-lg font-bold text-white">
                    <span>Grand Total (IDR):</span>
                    <span className="metallic-gold-text">{currentOrder.totalPrice ? formatCurrency(currentOrder.totalPrice, 'IDR') : '-'}</span>
                </p>
            </div>
        </Card>
    );
};

  const renderPaymentHistory = () => {
    const totalApprovedPayments = (order?.payments || [])
        .filter(p => p.paymentApprovalStatus === 'Approved')
        .reduce((sum, p) => sum + p.amount, 0);
    
    let sisaPembayaranText = "Harga total paket belum ditetapkan.";
    if (order?.totalPrice && order.totalPrice > 0) {
        const sisa = order.totalPrice - totalApprovedPayments;
        if (sisa <= 0) {
            sisaPembayaranText = "LUNAS SEPENUHNYA";
        } else {
            sisaPembayaranText = `${formatCurrency(sisa, 'IDR')}`;
        }
    }


    return (
    <Card title="Riwayat Pembayaran" className="generic-card-glass mt-6">
      {(order.payments || []).length === 0 ? (
        <p className="text-indigo-200">Belum ada riwayat pembayaran.</p>
      ) : (
        <ul className="space-y-3">
          {(order.payments || []).map(payment => (
            <li key={payment.id} className="p-3 bg-black/10 rounded-md text-sm">
              <div className="flex justify-between items-start">
                <p className="font-semibold text-indigo-100">{payment.paymentType} - {formatCurrency(payment.amount, 'IDR')}</p>
                 <span className={`text-xs px-2 py-0.5 rounded-full border backdrop-blur-sm ${getPaymentApprovalStatusPillStyle(payment.paymentApprovalStatus)}`}>
                    {mapPaymentApprovalStatusToText(payment.paymentApprovalStatus)}
                </span>
              </div>
              <p className="text-xs text-indigo-300">Tanggal: {formatDateForDisplay(payment.paymentDate)}</p>
              <p className="text-xs text-indigo-300">Metode: {payment.paymentMethod} {payment.paymentGatewayType ? `(${payment.paymentGatewayType})` : ''}</p>
              {payment.notes && <p className="text-xs text-indigo-300 italic">Catatan: {payment.notes}</p>}
              {payment.senderAccountName && (
                <div className="mt-1 pt-1 border-t border-white/10 text-xs text-indigo-300">
                    <p>Pengirim: {payment.senderAccountName} {payment.senderBankName ? `(${payment.senderBankName} - ${payment.senderAccountNumber})` : `(${payment.senderAccountNumber})`}</p>
                    {payment.senderTransferMethod && <p>Via: {payment.senderTransferMethod}</p>}
                    {payment.destinationBankName && <p>Ke Rekening: {payment.destinationBankName} - {payment.destinationAccountNumber}</p>}
                </div>
              )}
              {payment.paymentProofFileName && (
                <Button
                  variant="outline" size="sm"
                  onClick={() => handleViewPaymentProof(payment)}
                  className="!py-0.5 !px-1.5 text-xs mt-1"
                >
                  <EyeIcon className="h-3 w-3 mr-1"/> Lihat Bukti
                </Button>
              )}
            </li>
          ))}
        </ul>
      )}
      {order.totalPrice && (order.payments || []).length > 0 && (
        <div className="mt-4 pt-3 border-t border-white/15">
            <p className="text-sm font-semibold text-indigo-100">
                Total Harga Paket: <span className="metallic-gold-text">{formatCurrency(order.totalPrice, 'IDR')}</span>
            </p>
             <p className="text-sm font-semibold text-indigo-100">
                Total Pembayaran Disetujui: <span className="text-green-300">{formatCurrency(totalApprovedPayments, 'IDR')}</span>
            </p>
            <p className="text-md font-bold text-white mt-1">
                Sisa Pembayaran: <span className="metallic-gold-text">{sisaPembayaranText}</span>
            </p>
        </div>
      )}
    </Card>
  );
  }

  const renderCustomerPaymentForm = () => (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center p-4 z-[75] backdrop-blur-sm">
        <Card title="Formulir Pembayaran" className="generic-card-glass w-full max-w-lg max-h-[95vh] overflow-y-auto">
            <form onSubmit={(e) => { e.preventDefault(); handleCustomerSubmitPayment(); }} className="space-y-3">
                {customerPaymentStatus && (
                  <div className={`p-2.5 rounded-md text-xs ${customerPaymentStatus.type === 'success' ? 'bg-green-600/80 text-white' : 'bg-red-600/80 text-white'}`}>
                    {customerPaymentStatus.message}
                  </div>
                )}
                <Input label="Jumlah Pembayaran (IDR)*" type="number" name="amount" value={String(customerPaymentForm.amount)} onChange={handleCustomerPaymentFormChange} required min="1"/>
                <Input label="Tanggal Pembayaran*" type="date" name="paymentDate" value={customerPaymentForm.paymentDate} onChange={handleCustomerPaymentFormChange} required />
                 <Select label="Jenis Pembayaran*" name="paymentType" value={customerPaymentForm.paymentType} onChange={handleCustomerPaymentFormChange} options={[{value: 'DP', label: 'DP'}, {value: 'LUNAS', label: 'Pelunasan'}]} required/>

                <Select label="Metode Pembayaran*" name="paymentMethod" value={customerPaymentForm.paymentMethod} 
                    onChange={(e) => {
                        handleCustomerPaymentFormChange(e);
                        if (e.target.value !== 'Midtrans VA') {
                            setCustomerPaymentForm(prev => ({...prev, paymentGatewayType: ''}));
                        }
                    }}
                    options={[{value: 'Transfer', label: 'Transfer Bank'}, {value: 'Midtrans VA', label: 'Midtrans (Virtual Account, dll)'}]}
                    required
                />

                {customerPaymentForm.paymentMethod === 'Transfer' && (
                    <div className="p-3 border border-white/20 rounded-md space-y-3">
                        <h4 className="text-sm font-semibold text-indigo-100">Silakan transfer ke salah satu rekening berikut:</h4>
                        {destinationBankAccounts.length > 0 ? destinationBankAccounts.map(acc => (
                            <div key={acc.id} className="p-2 bg-black/20 rounded text-xs">
                                {acc.logoUrl && <img src={acc.logoUrl} alt={`${acc.bankName} logo`} className="h-6 mb-1"/>}
                                <p><strong>{acc.bankName}</strong></p>
                                <p>No. Rek: {acc.accountNumber}</p>
                                <p>A/N: {acc.accountHolderName}</p>
                                {acc.branchName && <p>Cabang: {acc.branchName}</p>}
                            </div>
                        )) : <p className="text-xs text-indigo-200">Rekening tujuan belum diatur oleh Admin. Silakan hubungi Admin.</p>}
                        <h4 className="text-sm font-semibold text-indigo-100 mt-2">Detail Pengirim:</h4>
                        <Input label="Nama Bank Pengirim*" name="senderBankName" value={customerPaymentForm.senderBankName || ''} onChange={handleCustomerPaymentFormChange} required/>
                        <Input label="Nomor Rekening Pengirim*" name="senderAccountNumber" value={customerPaymentForm.senderAccountNumber || ''} onChange={handleCustomerPaymentFormChange} required/>
                        <Input label="Nama Pemilik Rekening Pengirim*" name="senderAccountName" value={customerPaymentForm.senderAccountName || ''} onChange={handleCustomerPaymentFormChange} required/>
                        <Select label="Transfer Dilakukan Via*" name="senderTransferMethod" value={customerPaymentForm.senderTransferMethod || ''} onChange={handleCustomerPaymentFormChange} options={SENDER_TRANSFER_METHODS} required/>
                        <div>
                            <label htmlFor="paymentProofFile" className="block text-xs font-medium text-gray-200 mb-1">Unggah Bukti Transfer (PDF, JPG, PNG, maks 2MB)*</label>
                            <input type="file" id="paymentProofFile" onChange={handleCustomerProofFileChange} accept=".pdf,.png,.jpg,.jpeg" className="block w-full text-xs text-indigo-200 file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-indigo-500/30 file:text-indigo-100 hover:file:bg-indigo-600/40" required/>
                            {selectedProofFile && <p className="text-[10px] text-indigo-200 mt-1">File: {selectedProofFile.name}</p>}
                        </div>
                    </div>
                )}
                {customerPaymentForm.paymentMethod === 'Midtrans VA' && (
                    <div className="p-3 border border-white/20 rounded-md space-y-2">
                        <h4 className="text-sm font-semibold text-indigo-100">Pilih Virtual Account / Metode Midtrans:</h4>
                        <div className="grid grid-cols-2 gap-2">
                            {MIDTRANS_VA_OPTIONS.map(va => (
                                <Button type="button" key={va.code} 
                                    variant={customerPaymentForm.paymentGatewayType === va.name ? 'primary' : 'outline'}
                                    onClick={() => setCustomerPaymentForm(prev => ({...prev, paymentGatewayType: va.name}))}
                                    className="flex items-center space-x-2 !p-2 text-xs h-auto"
                                >
                                   {va.logoUrl && <img src={va.logoUrl} alt={`${va.name} logo`} className="h-5 w-auto mr-1"/>}
                                   {va.name}
                                </Button>
                            ))}
                        </div>
                        {customerPaymentForm.paymentGatewayType && <p className="text-xs text-indigo-200 mt-1">Anda memilih: {customerPaymentForm.paymentGatewayType}. Instruksi pembayaran akan ditampilkan setelah konfirmasi (simulasi).</p>}
                    </div>
                )}
                <Textarea label="Catatan (Opsional)" name="notes" value={customerPaymentForm.notes || ''} onChange={handleCustomerPaymentFormChange} rows={2} />
                <div className="flex justify-end space-x-2 pt-2">
                    <Button type="button" variant="outline" onClick={() => {setShowCustomerPaymentForm(false); setCustomerPaymentStatus(null);}} disabled={isSubmitting}>Batal</Button>
                    <Button type="submit" variant="primary" isLoading={isSubmitting}>Kirim Informasi Pembayaran</Button>
                </div>
            </form>
        </Card>
    </div>
  );


  return (
    <Layout>
      {showManifestFormModal && renderManifestFormModal()}
      {showChatModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[70]">
            <Card title={`Chat untuk Order ID: ${order.id.substring(0,8)}`} className="generic-card-glass w-full max-w-lg h-[70vh] flex flex-col">
                <div className="absolute top-3 right-3">
                    <Button onClick={() => setShowChatModal(false)} variant="danger" size="sm" className="!p-1.5">X</Button>
                </div>
                <div className="flex-grow overflow-y-auto p-4 space-y-2 bg-black/10 backdrop-blur-sm rounded-t-md">
                    {isLoadingChatMessages ? <LoadingSpinner/> :
                        chatMessages.length === 0 ? <p className="text-indigo-300 text-center">Belum ada pesan.</p> :
                        chatMessages.map(msg => <ChatMessageBubble key={msg.id} message={msg} currentUserId={currentAuthUserId!} />) 
                    }
                    <div ref={chatMessagesEndRef} />
                </div>
                <ChatInput onSendMessage={handleSendChatMessage} isLoading={isSendingChatMessage} />
            </Card>
        </div>
      )}
      {showCustomerPaymentForm && renderCustomerPaymentForm()}

      <div className="flex items-center justify-between mb-6">
         <button 
            onClick={() => navigate(userRole === 'admin' ? '/admin/orders' : '/orders')} 
            className="mr-4 p-2 rounded-full hover:bg-white/15 transition-colors"
            aria-label="Kembali"
          >
            <ArrowLeftIcon className="h-6 w-6 text-white" />
        </button>
        <h1 className="text-2xl font-bold metallic-gold-text">Detail Pesanan</h1>
         <Button onClick={handleOpenChatModal} variant="outline" size="sm" className="ml-auto">
            <ChatBubbleLeftEllipsisIcon className="h-5 w-5 mr-2" /> Chat
        </Button>
      </div>
      
      <Card title={`Order ID: ${order.id.substring(0,12)}...`} className="mb-6 generic-card-glass">
          <dl className="divide-y divide-white/15">
            <DetailItemLocal label="Jenis Layanan" value={order.serviceType} /> 
            <DetailItemLocal 
                label="Status Pesanan"
                value={
                    <span className={`text-xs px-2 py-1 rounded-full border bg-black/10 backdrop-blur-sm font-medium ${getOrderStatusPillStyleLocal(order.status)}`}>
                        {order.status}
                    </span>
                } 
            />
            <DetailItemLocal label="Harga Total Paket" value={order.totalPrice !== undefined && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice > 0) ? formatCurrency(order.totalPrice, 'IDR') : 'Belum Ditetapkan Admin'} />
            <DetailItemLocal label="Tanggal Pesan" value={new Date(order.createdAt).toLocaleString('id-ID')} /> 
            <DetailItemLocal label="Terakhir Update" value={new Date(order.updatedAt).toLocaleString('id-ID')} />
            
            <DetailItemLocal label="Nama Pemesan" value={(data as any).customerName} />
            <DetailItemLocal label="PPIU/PIHK" value={(data as any).ppiuName} />
            <DetailItemLocal label="No. Handphone" value={(data as any).phone} />
            <DetailItemLocal label="Alamat" value={(data as any).address} />
          </dl>

          {order.serviceType === ServiceType.HOTEL && (
            <div className="mt-4 pt-4 border-t border-white/15">
              <h3 className="text-md font-semibold text-indigo-100 mb-2">Detail Akomodasi Hotel:</h3>
              {renderHotelInfoBlock((data as HotelBookingData).madinahHotel, "Madinah")}
              {renderHotelInfoBlock((data as HotelBookingData).makkahHotel, "Mekah")}
              <div className="mt-3 pt-3 border-t border-white/10">
                <DetailItemLocal label="Include Handling" value={(data as HotelBookingData).includeHandling ? `Ya (${(data as HotelBookingData).handlingPax} pax)` : 'Tidak'} />
                {(data as HotelBookingData).includeHandling && (data as HotelBookingData).handlingPricePerPaxSAR && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice) &&
                    <DetailItemLocal label="Estimasi Biaya Handling" value={`${formatCurrency((data as HotelBookingData).handlingPricePerPaxSAR! * ((data as HotelBookingData).handlingPax || 0), 'SAR')} (setara ${formatCurrency(convertToIDR((data as HotelBookingData).handlingPricePerPaxSAR! * ((data as HotelBookingData).handlingPax || 0), 'SAR'), 'IDR')})`} />
                }
                <DetailItemLocal label="Include Visa" value={(data as HotelBookingData).includeVisa ? `Ya (${(data as HotelBookingData).visaPax} pax)` : 'Tidak'} />
                {(data as HotelBookingData).includeVisa && <>
                    <DetailItemLocal label="Nama Muasasah (Visa)" value={(data as HotelBookingData).muasasahName || '-'} />
                    {(data as HotelBookingData).visaPricePerPaxUSD && (data as HotelBookingData).visaPax && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice) &&
                        <DetailItemLocal label="Estimasi Biaya Visa" value={`${formatCurrency((data as HotelBookingData).visaPricePerPaxUSD! * ((data as HotelBookingData).visaPax||0), 'USD')} (setara ${formatCurrency(convertToIDR((data as HotelBookingData).visaPricePerPaxUSD! * ((data as HotelBookingData).visaPax||0), 'USD'), 'IDR')})`} />
                    }
                    <DetailItemLocal label="Visa - Kendaraan" value={(data as HotelBookingData).visaVehicleType} />
                    <DetailItemLocal label="Visa - Maskapai" value={(data as HotelBookingData).visaAirlineName} />
                    <DetailItemLocal label="Visa - Tgl & Waktu Kedatangan" value={formatDateTimeForDisplay((data as HotelBookingData).visaArrivalDate)} />
                    <DetailItemLocal label="Visa - Tgl & Waktu Kepulangan" value={formatDateTimeForDisplay((data as HotelBookingData).visaDepartureDate)} />
                </>}
                 {(data as HotelBookingData).busPriceTotalSAR && (data as HotelBookingData).busPriceTotalSAR! > 0 && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice) &&
                    <DetailItemLocal label="Biaya Bus (Total)" value={`${formatCurrency((data as HotelBookingData).busPriceTotalSAR!, 'SAR')} (setara ${formatCurrency(convertToIDR((data as HotelBookingData).busPriceTotalSAR!, 'SAR'), 'IDR')})`} />
                }
              </div>
            </div>
          )}
          
          {order.serviceType === ServiceType.VISA && (
            <dl className="divide-y divide-white/15 mt-4 pt-4 border-t border-white/15">
                <DetailItemLocal label="Jumlah Pax" value={(data as VisaBookingData).pax} />
                <DetailItemLocal label="Jenis Kendaraan" value={(data as VisaBookingData).vehicleType || '-'} />
                <DetailItemLocal label="Nama Muasasah (Visa)" value={(data as VisaBookingData).muasasahName || '-'} />
                {(data as VisaBookingData).visaPricePerPaxUSD && (data as VisaBookingData).pax && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice) &&
                    <DetailItemLocal label="Estimasi Biaya Visa" value={`${formatCurrency(((data as VisaBookingData).visaPricePerPaxUSD || 0) * ((data as VisaBookingData).pax || 0), 'USD')} (setara ${formatCurrency(convertToIDR(((data as VisaBookingData).visaPricePerPaxUSD || 0) * ((data as VisaBookingData).pax || 0), 'USD'), 'IDR')})`} />
                }
                {(data as VisaBookingData).busPriceTotalSAR && (data as VisaBookingData).busPriceTotalSAR! > 0 && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice) &&
                    <DetailItemLocal label="Biaya Bus (Total)" value={`${formatCurrency((data as VisaBookingData).busPriceTotalSAR!, 'SAR')} (setara ${formatCurrency(convertToIDR((data as VisaBookingData).busPriceTotalSAR!, 'SAR'), 'IDR')})`} />
                }
            </dl>
          )}

          {order.serviceType === ServiceType.HANDLING && (
            <dl className="divide-y divide-white/15 mt-4 pt-4 border-t border-white/15">
                 <DetailItemLocal label="Jumlah Jemaah" value={(data as HandlingBookingData).pax || 0} />
                <DetailItemLocal label="Include Mutowif" value={(data as HandlingBookingData).includeMutowif ? `Ya (${(data as HandlingBookingData).mutowifName || 'Belum Dipilih'})` : 'Tidak'} />
                {(data as HandlingBookingData).handlingPricePerPaxSAR && (data as HandlingBookingData).pax && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice) &&
                    <DetailItemLocal label="Estimasi Biaya Handling" value={`${formatCurrency(((data as HandlingBookingData).handlingPricePerPaxSAR || 0) * ((data as HandlingBookingData).pax || 0), 'SAR')} (setara ${formatCurrency(convertToIDR(((data as HandlingBookingData).handlingPricePerPaxSAR || 0) * ((data as HandlingBookingData).pax || 0), 'SAR'), 'IDR')})`} />
                }
            </dl>
          )}

          {order.serviceType === ServiceType.JASTIP && (
            <dl className="divide-y divide-white/15 mt-4 pt-4 border-t border-white/15">
                <DetailItemLocal label="Jenis Titipan" value={(data as JastipBookingData).itemType} />
                <DetailItemLocal label="Jumlah" value={`${(data as JastipBookingData).quantity} ${(data as JastipBookingData).unit}`} />
                <DetailItemLocal label="Alamat Kirim" value={(data as JastipBookingData).deliveryAddress} />
                <DetailItemLocal label="Catatan" value={(data as JastipBookingData).notes || '-'} />
            </dl>
          )}


          {order.status === OrderStatus.TENTATIVE_CONFIRMATION && userRole === 'customer' && (
             <div className="mt-4 pt-4 border-t border-white/15">
                <p className="text-yellow-300 mb-2">Admin telah menetapkan harga. Mohon konfirmasi pesanan Anda.</p>
                <div className="flex space-x-2">
                    <Button onClick={() => handleCustomerConfirmation(true)} isLoading={isSubmitting} variant="primary">Konfirmasi & Lanjutkan</Button>
                    <Button onClick={() => handleCustomerConfirmation(false)} isLoading={isSubmitting} variant="danger">Tolak Pesanan</Button>
                </div>
            </div>
          )}
          {order.serviceType === ServiceType.HOTEL && canEditOrderDataByUser && !isEditingOrderData && (
             <Button onClick={() => { setEditableOrderData(order.data as HotelBookingData); setIsEditingOrderData(true); }} variant="outline" size="sm" className="mt-4">
                <PencilIcon className="h-4 w-4 mr-1" /> Ubah Detail Hotel
            </Button>
          )}
          {order.serviceType === ServiceType.HOTEL && isEditingOrderData && renderHotelEditForm(editableOrderData as HotelBookingData)}
      </Card>
      
      {order && userRole === 'customer' && (order.totalPrice && order.totalPrice > 0) && renderCostBreakdown(order)}

      {userRole === 'customer' && canMakePayment && (
          <Button 
            onClick={() => setShowCustomerPaymentForm(true)} 
            variant="primary" 
            size="lg" 
            className="w-full mt-4"
            icon={<CurrencyDollarIcon className="h-5 w-5 mr-2"/>}
          >
            Lakukan Pembayaran
          </Button>
      )}
      {renderPaymentHistory()}


      {isEditingPackageInfo ? renderPackageInfoEditForm() : (
        <div className="mb-6 mt-6">
            <PackageInfoDisplay packageInfo={order.packageInfo} />
            {userRole === 'customer' && canUserModifyDetails && (
                <Button onClick={handleEditPackageInfoClick} variant="outline" className="mt-4">
                    <PencilIcon className="h-4 w-4 mr-1" /> 
                    {order.packageInfo && Object.keys(order.packageInfo).length > 2 ? 'Ubah' : 'Lengkapi'} Informasi Paket Tambahan 
                </Button>
            )}
        </div>
      )}

      {userRole === 'customer' && (
      <Card title="Manifest Jemaah" className="mb-6 generic-card-glass">
        {(order.manifest || []).length === 0 && <p className="text-indigo-200 mb-3">Belum ada data manifest jemaah. Silakan tambahkan.</p>}
        {(order.manifest || []).length > 0 && (
            <div className="overflow-x-auto">
                <table className="min-w-full text-sm text-left text-indigo-100 table-auto">
                    <thead className="bg-white/5 text-xs uppercase">
                        <tr>
                            <th className="px-4 py-2 text-indigo-200">Nama Jemaah</th>
                            <th className="px-4 py-2 text-indigo-200">JK</th>
                            <th className="px-4 py-2 text-indigo-200">Usia</th>
                            <th className="px-4 py-2 text-indigo-200">No. Visa</th>
                            <th className="px-4 py-2 text-indigo-200">Kota Asal Keberangkatan</th>
                            <th className="px-4 py-2 text-indigo-200">Nama Paspor</th>
                            <th className="px-4 py-2 text-indigo-200">No. Paspor</th>
                            <th className="px-4 py-2 text-indigo-200">Tgl Terbit</th>
                            <th className="px-4 py-2 text-indigo-200">Tgl Expired</th>
                            <th className="px-4 py-2 text-indigo-200">Aksi</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/10">
                        {(order.manifest || []).map(item => (
                            <tr key={item.id} className="hover:bg-white/5">
                                <td className="px-4 py-2 whitespace-nowrap">{item.namaJemaah}</td>
                                <td className="px-4 py-2">{item.jenisKelamin?.charAt(0) || '-'}</td>
                                <td className="px-4 py-2">{item.usia !== undefined ? `${item.usia} th` : '-'}</td>
                                <td className="px-4 py-2">{item.nomorVisa || '-'}</td>
                                <td className="px-4 py-2">{item.kotaAsalKeberangkatan || item.kotaTempatIssuedPaspor || '-'}</td>
                                <td className="px-4 py-2 whitespace-nowrap">{item.namaDiPaspor}</td>
                                <td className="px-4 py-2">{item.nomorPaspor}</td>
                                <td className="px-4 py-2">{formatDateForDisplay(item.tanggalTerbitPaspor)}</td>
                                <td className="px-4 py-2">{formatDateForDisplay(item.tanggalExpiredPaspor)}</td>
                                <td className="px-4 py-2 whitespace-nowrap">
                                    {canUserModifyDetails && (
                                        <div className="flex space-x-2">
                                            <Button variant="outline" size="sm" onClick={() => handleOpenManifestForm(item)} className="!p-1.5"><PencilIcon className="h-4 w-4"/></Button>
                                            <Button variant="danger" size="sm" onClick={() => handleDeleteManifestItem(item.id)} className="!p-1.5"><TrashIcon className="h-4 w-4"/></Button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        )}
        {canUserModifyDetails && (
            <Button onClick={() => handleOpenManifestForm()} variant="primary" size="sm" className="mt-3">
                <PlusCircleIcon className="h-5 w-5 mr-1"/> Tambah Data Manifest
            </Button>
        )}
      </Card>
      )}

      <Card title="Dokumen Pesanan" className="generic-card-glass">
        <div className="flex flex-wrap gap-2">
            <Button onClick={() => generateOrderRequestPdf(order)} variant="secondary" size="sm">Surat Permintaan Pesanan (PDF)</Button>
            {order.totalPrice && (order.status !== OrderStatus.REQUEST_CONFIRMATION || order.totalPrice > 0) && 
                <Button onClick={() => generateInvoicePdf(order)} variant="secondary" size="sm">Invoice/Faktur (PDF)</Button>
            }
            {order.packageInfo && 
                <Button onClick={() => generatePackageInfoPdf(order)} variant="secondary" size="sm">Informasi Paket (PDF)</Button>
            }
            {order.manifest && order.manifest.length > 0 &&
                <Button onClick={() => generateManifestPdf(order)} variant="secondary" size="sm">Manifest Jemaah (PDF)</Button>
            }
        </div>
      </Card>

    </Layout>
  );
};

export default OrderDetailsPage;
