
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { APP_NAME } from '../constants';
import { LockClosedIcon, EnvelopeIcon } from '@heroicons/react/24/outline';
import { BottomNav } from '../components/BottomNav';
import { useAuth } from '../hooks/useAuth';
import { loginUser } from '../services/userService'; 

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { userRole } = useAuth(); 
  const [emailOrPhone, setEmailOrPhone] = useState(''); 
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const loggedInUser = await loginUser(emailOrPhone, password);
      
      if (loggedInUser) {
        if (loggedInUser.accountStatus === 'active') {
          // loginUser service now handles setting localStorage and dispatching the event.
          // The useAuth hook will pick up the change and update the state.
          if (loggedInUser.role === 'admin' || loggedInUser.role === 'tim_staff') {
            navigate('/admin');
          } else {
            navigate('/');
          }
        } else if (loggedInUser.accountStatus === 'pending_approval') {
          setError('Akun Anda sedang menunggu persetujuan Admin. Silakan hubungi Admin.');
        } else if (loggedInUser.accountStatus === 'suspended') {
          setError('Akun Anda telah ditangguhkan. Silakan hubungi Admin.');
        } else {
          setError('Status akun tidak valid atau tidak aktif. Silakan hubungi Admin.');
        }
      } else {
        setError('Gagal login. Respon tidak valid dari server.');
      }
    } catch (apiError: any) {
      console.error("Login API error:", apiError);
      if (apiError.message && (apiError.message.includes('User not found') || apiError.message.includes('Invalid credentials') || apiError.message.includes('salah'))) {
        setError('Email/No. HP atau kata sandi salah.');
      } else if (apiError.message) {
         setError(apiError.message);
      }
      else {
        setError('Terjadi kesalahan saat mencoba login. Periksa koneksi Anda.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-between">
      <div className="flex flex-grow items-center justify-center p-4">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold metallic-gold-text" style={{ fontFamily: "'Poppins', sans-serif" }}>{APP_NAME}</h1>
            <p className="text-indigo-200 mt-2">Silakan login untuk melanjutkan</p>
          </div>
          <Card className="generic-card-glass shadow-2xl">
            <form onSubmit={handleLogin} className="space-y-6 p-2">
              <Input
                id="emailOrPhone"
                label="Email atau No. Handphone"
                type="text" 
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                required
                icon={<EnvelopeIcon className="h-5 w-5 text-indigo-300" />}
                placeholder="user@ewako.com atau 08123..."
              />
              <Input
                id="password"
                label="Sandi"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                icon={<LockClosedIcon className="h-5 w-5 text-indigo-300" />}
                placeholder="Kata Sandi"
              />
              {error && <p className="text-xs text-red-300 text-center bg-red-700/40 backdrop-blur-sm p-2 rounded-md">{error}</p>}
              <Button type="submit" variant="primary" isLoading={isLoading} fullWidth size="lg">
                Login
              </Button>
            </form>
            <div className="mt-6 text-center">
              <p className="text-sm text-indigo-200">
                Belum punya akun? <Link to="/register" className="font-medium metallic-gold-text hover:opacity-80">Daftar di sini</Link>
              </p>
            </div>
          </Card>
        </div>
      </div>
      <BottomNav userRole={userRole} />
    </div>
  );
};

export default LoginPage;
