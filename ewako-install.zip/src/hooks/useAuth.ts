
import React from 'react';

// Auth Check Hook
export const useAuth = () => {
  const getInitialAuth = () => {
    const userId = localStorage.getItem('ewakoRoyalUserId');
    const token = localStorage.getItem('ewakoRoyalAuthToken');
    return !!userId && !!token; // Must have both userId and token
  };
  const getInitialRole = () => localStorage.getItem('ewakoRoyalUserRole') as 'customer' | 'admin' | 'tim_staff' | null;
  const getInitialUserId = () => localStorage.getItem('ewakoRoyalUserId');

  const [internalIsAuthenticated, setInternalIsAuthenticated] = React.useState<boolean>(getInitialAuth);
  const [internalUserRole, setInternalUserRole] = React.useState<'customer' | 'admin' | 'tim_staff' | null>(getInitialRole);
  const [internalUserId, setInternalUserId] = React.useState<string | null>(getInitialUserId);

  React.useEffect(() => {
    const syncAuthState = () => {
      const storedUserId = localStorage.getItem('ewakoRoyalUserId');
      const storedUserRole = localStorage.getItem('ewakoRoyalUserRole') as 'customer' | 'admin' | 'tim_staff' | null;
      const storedToken = localStorage.getItem('ewakoRoyalAuthToken');
      
      const newIsAuthenticated = !!storedUserId && !!storedToken; // Check both
      
      setInternalIsAuthenticated(newIsAuthenticated);
      setInternalUserRole(newIsAuthenticated ? storedUserRole : null); // Clear role if not authenticated
      setInternalUserId(newIsAuthenticated ? storedUserId : null); // Clear userId if not authenticated
    };

    // Listen to storage events (e.g., from other tabs)
    window.addEventListener('storage', syncAuthState);
    // Listen to custom events dispatched on login/logout
    window.addEventListener('customAuthChange', syncAuthState);
    
    // Initial sync when component mounts or dependencies change
    syncAuthState(); 

    return () => {
        window.removeEventListener('storage', syncAuthState);
        window.removeEventListener('customAuthChange', syncAuthState);
    };
  }, []); 
  
  return { 
    isAuthenticated: internalIsAuthenticated, 
    userRole: internalUserRole, 
    userId: internalUserId, 
    isLoading: false 
  };
};
