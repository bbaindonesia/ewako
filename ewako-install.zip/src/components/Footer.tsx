

import React from 'react';
import { Link } from 'react-router-dom'; // Import Link

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    // bg-gray-800 removed. Global CSS will style footer tag for glass effect.
    <footer className="w-full text-center py-4 mt-auto border-t border-gray-700"> 
      <p className="text-sm text-indigo-200">
        Copyright © {currentYear} Ewako Royal - Dev By{' '}
        <a 
          href="https://bbaindonesia.net" 
          target="_blank" 
          rel="noopener noreferrer" 
          className="metallic-gold-text hover:opacity-80 underline"
        >
          BBA Indonesia
        </a>
      </p>
      <p className="text-xs text-indigo-300 mt-1">
        <Link to="/privacy-policy" className="hover:metallic-gold-text underline">
          Kebijakan Privasi
        </Link>
      </p>
    </footer>
  );
};