import React from 'react';
import { TimeComponents } from '../hooks/useRealTimeClocks';

interface AnalogDigitalClockProps {
  timeComponents: TimeComponents;
  label: string;
}

export const AnalogDigitalClock: React.FC<AnalogDigitalClockProps> = ({ timeComponents, label }) => {
  const { hours, minutes, seconds, dayName, dateString } = timeComponents;

  // Angles for SVG transform, relative to 12 o'clock (0 deg is North)
  // SVG rotation is clockwise. Start hands pointing North (0, -length) then rotate.
  const sAngle = (seconds / 60) * 360;
  const mAngle = (minutes / 60) * 360 + (seconds / 60) * 6; // minute hand moves with seconds
  const hAngle = ((hours % 12) / 12) * 360 + (minutes / 60) * 30; // hour hand moves with minutes

  const clockSize = 120; // ViewBox size for the SVG clock
  const center = clockSize / 2;
  const radius = clockSize / 2 - 6; // Radius for the clock face elements

  const hourMarkers = [];
  for (let i = 0; i < 12; i++) {
    const angleDeg = i * 30; // 0 is 3 o'clock, 90 is 12 o'clock. We want 0 to be 12 o'clock.
    const angleRad = (angleDeg - 90) * Math.PI / 180; // Adjust so 0 angle is 12 o'clock
    
    const isMajor = i % 3 === 0; // Mark 12, 3, 6, 9
    const markerLength = isMajor ? 5 : 2.5;
    const markerThickness = isMajor ? 1.5 : 1;

    const x1 = center + (radius - markerLength) * Math.cos(angleRad);
    const y1 = center + (radius - markerLength) * Math.sin(angleRad);
    const x2 = center + radius * Math.cos(angleRad);
    const y2 = center + radius * Math.sin(angleRad);
    
    hourMarkers.push(
      <line
        key={`marker-${i}`}
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        className={`futuristic-clock-marker ${isMajor ? 'major' : ''}`}
        strokeWidth={markerThickness}
      />
    );
  }
  
  const decorativeCircles = [
    { r: radius * 0.92, class: "futuristic-clock-face-pattern" },
    { r: radius * 0.8, class: "futuristic-clock-face-pattern-accent" },
    { r: radius * 0.65, class: "futuristic-clock-face-pattern" },
    { r: radius * 0.35, class: "futuristic-clock-face-pattern-accent" },
  ];

  const hourHandLength = radius * 0.5;
  const minuteHandLength = radius * 0.7;
  const secondHandLength = radius * 0.85;

  return (
    <div className="futuristic-clock-container flex flex-col items-center w-full">
      <h3 className="futuristic-clock-label text-xs sm:text-sm font-semibold metallic-gold-text mb-1.5 sm:mb-2 text-center">{label}</h3>
      <svg viewBox={`0 0 ${clockSize} ${clockSize}`} className="futuristic-clock-svg w-32 h-32 sm:w-36 sm:h-36 md:w-40 md:h-40">
        {/* Background and Face */}
        <circle cx={center} cy={center} r={radius + 3} className="futuristic-clock-outer-glow" />
        <circle cx={center} cy={center} r={radius} className="futuristic-clock-face-bg" />
        
        {/* Decorative Concentric Circles */}
        {decorativeCircles.map(circle => (
            <circle key={circle.r} cx={center} cy={center} r={circle.r} className={circle.class} />
        ))}

        {/* Markers */}
        <g>{hourMarkers}</g>

        {/* Hands - Defined pointing upwards from center, then rotated */}
        <g transform={`rotate(${hAngle} ${center} ${center})`}>
          <line
            x1={center}
            y1={center}
            x2={center}
            y2={center - hourHandLength}
            className="futuristic-clock-hand futuristic-hour-hand"
          />
        </g>
        <g transform={`rotate(${mAngle} ${center} ${center})`}>
          <line
            x1={center}
            y1={center}
            x2={center}
            y2={center - minuteHandLength}
            className="futuristic-clock-hand futuristic-minute-hand"
          />
        </g>
        <g transform={`rotate(${sAngle} ${center} ${center})`}>
          <line
            x1={center}
            y1={center}
            x2={center}
            y2={center - secondHandLength}
            className="futuristic-clock-hand futuristic-second-hand"
          />
        </g>
        {/* Center Dot */}
        <circle cx={center} cy={center} r="2.5" className="futuristic-center-dot" />
      </svg>
      <div className="futuristic-clock-date-info text-center mt-1.5 sm:mt-2">
        <p className="static-neon-text text-sm sm:text-base md:text-lg font-bold">
            {String(hours).padStart(2, '0')}:{String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </p>
        <p className="static-neon-text text-[8px] sm:text-[9px] md:text-[10px] opacity-90">{dateString}</p>
        <p className="static-neon-text text-[7px] sm:text-[8px] md:text-[9px] opacity-75">{dayName}</p>
      </div>
    </div>
  );
};