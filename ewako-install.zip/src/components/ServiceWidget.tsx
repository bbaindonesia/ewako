

import React from 'react';
import { Link } from 'react-router-dom';
import { Card } from './ui/Card';

interface ServiceWidgetProps {
  title: string;
  icon: React.ReactElement<React.SVGProps<SVGSVGElement>>; // Expect an SVG-compatible ReactElement
  linkTo: string;
  description?: string;
}

export const ServiceWidget: React.FC<ServiceWidgetProps> = ({ title, icon, linkTo, description }) => {
  return (
    <Link to={linkTo} className="block group">
      <Card className="generic-card-glass h-full 
                     hover:border hover:border-yellow-400/50
                     hover:shadow-yellow-glow
                     transition-all duration-300 ease-in-out 
                     transform group-hover:scale-[1.03]">
        <div className="flex flex-col items-center text-center p-4">
          <div className="mb-3 metallic-gold-text group-hover:opacity-80 transition-opacity duration-300">
            {React.cloneElement(icon, { className: "h-12 w-12" })}
          </div>
          <h3 className="text-lg font-semibold text-white mb-1 group-hover:metallic-gold-text transition-colors duration-300">{title}</h3>
          {description && <p className="text-sm text-indigo-200">{description}</p>}
        </div>
      </Card>
    </Link>
  );
};