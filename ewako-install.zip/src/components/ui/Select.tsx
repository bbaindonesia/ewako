import React from 'react';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: { value: string | number; label: string }[];
  placeholder?: string;
}

export const Select: React.FC<SelectProps> = ({ label, id, error, options, className, placeholder, ...restProps }) => {
  return (
    <div className="w-full">
      {label && <label htmlFor={id} className="block text-sm font-medium text-indigo-200 mb-1">{label}</label>}
      <select
        id={id}
        className={`
          form-select block w-full sm:text-sm
          ${error ? 'border-red-500' : ''}
          ${className}
        `}
        aria-invalid={!!error}
        {...restProps}
      >
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(option => (
          <option key={option.value} value={option.value}>{option.label}</option>
        ))}
      </select>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
};