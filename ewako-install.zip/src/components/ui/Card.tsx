
import React from 'react';

interface CardProps {
  children?: React.ReactNode;
  className?: string;
  title?: string;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({ children, className, title, onClick }) => {
  return (
    <div
      className={`shadow-xl rounded-xl overflow-hidden ${onClick ? 'cursor-pointer transition-shadow duration-300' : ''} ${className}`}
      onClick={onClick}
    >
      {title && (
        <div className="p-4 border-b border-[rgba(212,175,55,0.2)]">
          <h3 className="text-lg font-semibold card-title-custom-style">{title}</h3>
        </div>
      )}
      <div className="p-4 md:p-6">
        {children}
      </div>
    </div>
  );
};