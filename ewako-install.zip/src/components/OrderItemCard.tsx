

import React from 'react';
import { Order, OrderStatus, ServiceType, HotelBookingData, VisaBookingData, HandlingBookingData, JastipBookingData } from '../types'; 
import { Link } from 'react-router-dom';
import { Button } from './ui/Button';

interface OrderItemCardProps {
  order: Order;
  isAdminView?: boolean;
  onStatusChange?: (orderId: string, newStatus: OrderStatus) => void;
  onCustomerConfirm?: (orderId: string, confirmed: boolean) => void;
}

const getOrderStatusPillStyle = (status: OrderStatus): string => {
  // Using text and border for glass, background will be subtle from pill itself
  switch (status) {
    case OrderStatus.REQUEST_CONFIRMATION: return 'border-blue-400 text-blue-300';
    case OrderStatus.TENTATIVE_CONFIRMATION: return 'border-yellow-400 text-yellow-300';
    case OrderStatus.DEFINITE_CONFIRMATION: return 'border-orange-400 text-orange-300';
    case OrderStatus.CONFIRMED_BY_ADMIN: return 'border-teal-400 text-teal-300';
    case OrderStatus.DOWNPAYMENT_RECEIVED: return 'border-indigo-400 text-indigo-300';
    case OrderStatus.FULLY_PAID: return 'border-green-400 text-green-300';
    case OrderStatus.REJECTED_BY_CUSTOMER:
    case OrderStatus.CANCELLED: return 'border-red-400 text-red-300';
    default: return 'border-gray-400 text-gray-300';
  }
};


const getOrderSummary = (order: Order): string => {
    switch (order.serviceType) {
        case ServiceType.HOTEL:
            const hotelData = order.data as HotelBookingData;
            const madinahInfo = hotelData.madinahHotel?.name ? `Madinah: ${hotelData.madinahHotel.name}` : '';
            const makkahInfo = hotelData.makkahHotel?.name ? `Makkah: ${hotelData.makkahHotel.name}` : '';
            return [madinahInfo, makkahInfo].filter(Boolean).join(' & ') || 'Detail Hotel';
        case ServiceType.VISA:
            return `Visa untuk ${(order.data as VisaBookingData).pax} jemaah`;
        case ServiceType.HANDLING:
            return `Handling untuk ${(order.data as HandlingBookingData).pax} jemaah`;
        case ServiceType.JASTIP:
            const jastipData = order.data as JastipBookingData;
            return `Jastip: ${jastipData.quantity} ${jastipData.unit} ${jastipData.itemType}`;
        default:
            return 'Detail Pesanan';
    }
};

export const OrderItemCard: React.FC<OrderItemCardProps> = ({ order, isAdminView = false, onStatusChange, onCustomerConfirm }) => {
  const detailPath = isAdminView ? `/admin/orders/${order.id}` : `/orders/${order.id}`;

  return (
    <div className="generic-card-glass shadow-lg rounded-lg overflow-hidden transition-all hover:shadow-xl"> 
      <div className={`p-3 bg-white/5 border-b border-white/10 text-white flex justify-between items-center`}> 
        <h3 className="font-semibold text-base">{order.serviceType} - ID: {order.id.substring(0, 8)}...</h3>
        <span className={`text-xs px-2 py-0.5 rounded-full border bg-black/10 backdrop-blur-sm ${getOrderStatusPillStyle(order.status)}`}>{order.status}</span>
      </div>
      <div className="p-4 space-y-2">
        <p className="text-indigo-200"><span className="font-medium text-indigo-100">Tanggal Pesan:</span> {new Date(order.createdAt).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        <p className="text-indigo-200"><span className="font-medium text-indigo-100">Pemesan:</span> {(order.data as any).customerName}</p>
        <p className="text-indigo-200"><span className="font-medium text-indigo-100">Ringkasan:</span> {getOrderSummary(order)}</p>
        
        {order.status === OrderStatus.TENTATIVE_CONFIRMATION && !isAdminView && onCustomerConfirm && (
          <div className="mt-3 pt-3 border-t border-white/15"> 
            <p className="text-yellow-300 text-sm mb-2">Pesanan ini memerlukan konfirmasi Anda.</p>
            <div className="flex space-x-2">
              <Button size="sm" variant="primary" onClick={() => onCustomerConfirm(order.id, true)}>Konfirmasi Pesanan</Button>
              <Button size="sm" variant="danger" onClick={() => onCustomerConfirm(order.id, false)}>Tolak Pesanan</Button>
            </div>
          </div>
        )}

        <div className="mt-4 flex justify-end">
          <Link to={detailPath}>
            <Button variant="outline" size="sm">Lihat Detail</Button>
          </Link>
        </div>
      </div>
    </div>
  );
};
