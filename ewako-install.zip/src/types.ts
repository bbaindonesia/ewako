
import { v4 as uuidv4 } from 'uuid';

export interface User {
  id: string;
  email: string;
  phone?: string;
  name: string;
  role: 'customer' | 'admin' | 'tim_staff';
  ppiuName?: string;
  address?: string;
  password?: string; // Only for form state, not for direct storage
  accountStatus: 'pending_approval' | 'active' | 'suspended'; // Non-optional
}

export enum OrderStatus {
  REQUEST_CONFIRMATION = "Request Confirmation",
  TENTATIVE_CONFIRMATION = "Tentative Confirmation",
  DEFINITE_CONFIRMATION = "Definite Confirmation",
  CONFIRMED_BY_ADMIN = "Confirmed by Admin",
  DOWNPAYMENT_RECEIVED = "Downpayment Received",
  FULLY_PAID = "Lunas",
  REJECTED_BY_CUSTOMER = "Rejected by Customer",
  CANCELLED = "Cancelled"
}

export enum ServiceType {
  HOTEL = "Hotel",
  VISA = "Visa",
  HANDLING = "Handling",
  TRAIN_TICKET = "Tiket Kereta",
  JASTIP = "Jasa Titipan"
}

export interface RoomBooking {
  quad: number;
  triple: number;
  double: number;
}

export interface HotelInfo {
  name: string;
  nights: number;
  rooms: RoomBooking;
  checkIn: string;
  checkOut: string;
  pricesSAR?: {
    quad?: number;
    triple?: number;
    double?: number;
  };
}

export interface HotelBookingData {
  customerName: string;
  ppiuName?: string;
  phone: string;
  address: string;
  madinahHotel?: HotelInfo;
  makkahHotel?: HotelInfo;
  includeHandling: boolean;
  handlingPax?: number;
  handlingPricePerPaxSAR?: number;
  includeVisa: boolean;
  visaPax?: number;
  visaPricePerPaxUSD?: number;
  visaVehicleType?: 'Bus' | 'HiAce' | 'SUV' | '';
  visaAirlineName?: string;
  visaArrivalDate?: string;
  visaDepartureDate?: string;
  muasasahName?: string;
  busPriceTotalSAR?: number;
}

export interface VisaBookingData {
  customerName: string;
  ppiuName?: string;
  phone: string;
  address: string;
  pax: number;
  vehicleType: 'Bus' | 'HiAce' | 'SUV' | '';
  muasasahName?: string;
  visaPricePerPaxUSD?: number;
  busPriceTotalSAR?: number;
}

export interface HandlingBookingData {
  customerName: string;
  ppiuName?: string;
  phone: string;
  address: string;
  pax: number;
  includeMutowif: boolean;
  mutowifName?: string;
  handlingPricePerPaxSAR?: number;
}

export enum JastipItemType {
  FOOD = "Makanan",
  CLOTHES = "Pakaian",
  PERFUME = "Parfum",
  DATES = "Kurma",
  OTHER = "Lainnya"
}

export enum JastipUnit {
  BOX = "Box",
  KG = "Kg",
  PCS = "Pcs",
  KODI = "Kodi",
  BOTTLE = "Botol",
  LUSIN = "Lusin",
  UNIT = "Unit"
}

export interface JastipBookingData {
  customerName: string;
  phone: string;
  itemType: JastipItemType | '';
  unit: JastipUnit | '';
  quantity: number;
  deliveryAddress: string;
  notes?: string;
}

export interface BusRouteItem {
  id: string; // Added for unique key
  date: string;
  from: string;
  to: string;
  routeVehicleId?: string;
  vehicleDetails?: string;
}

export interface ZiarahRouteItem {
  id: string;
  tujuan: string;
  kota: 'Madinah' | 'Mekah' | 'Thaif' | 'Jeddah' | 'Lainnya' | '';
  tanggal: string;
  waktu: string;
  remake: 'Ziarah' | 'City Tour' | '';
}

export interface PackageInfoData {
  groupCode?: string;
  ppiuName: string;
  ppiuPhone: string;
  paxCount: number;
  madinahHotelInfo?: string;
  makkahHotelInfo?: string;
  madinahHotelStructured?: HotelInfo;
  makkahHotelStructured?: HotelInfo;
  busVehicleId?: string;
  busName?: string;
  busVehicleType?: 'Bus' | 'HiAce' | 'SUV' | '';
  busDriverName?: string;
  busDriverPhone?: string;
  busSyarikahNumber?: string;
  busRoutes?: Array<BusRouteItem>;
  ziarahRoutes?: Array<ZiarahRouteItem>;
  mutowifName?: string;
  mutowifPhone?: string;
  representativeName?: string;
  representativePhone?: string;
  ewakoRoyalPhone?: string;
  airlineName?: string;
  airlineCode?: string;
  pnrCode?: string;
  arrivalDateTime?: string;
  arrivalTerminal?: string;
  departureDateTime?: string;
  departureTerminal?: string;
  tourLeaderName?: string;
  tourLeaderPhone?: string;
  tourGuideName?: string;
  tourGuidePhone?: string;
}

export interface Mutowif {
  id: string;
  name: string;
  phone: string;
}

export interface ManifestItem {
  id: string;
  namaJemaah: string;
  jenisKelamin: 'Laki-laki' | 'Perempuan' | '';
  tanggalLahir: string;
  usia?: number;
  nomorVisa?: string;
  namaDiPaspor: string;
  nomorPaspor: string;
  tanggalTerbitPaspor: string;
  tanggalExpiredPaspor: string;
  kotaTempatIssuedPaspor?: string;
  kotaAsalKeberangkatan?: string;
}

export type SenderTransferMethod = 'Teller' | 'ATM' | 'MobileBanking' | 'InternetBanking' | '';

export interface AdminManagedBankAccount {
  id: string;
  bankName: string;
  bankCode?: string;
  accountNumber: string;
  accountHolderName: string;
  branchName?: string;
  logoUrl?: string;
}

export type PaymentApprovalStatus = 'Pending' | 'Approved' | 'Rejected';

export interface Payment {
  id: string;
  orderId: string;
  userId: string;
  amount: number;
  paymentDate: string;
  paymentType: 'DP' | 'LUNAS' | 'LAINNYA';
  paymentMethod: 'Transfer' | 'Midtrans VA' | 'Cash' | 'Lainnya';
  notes?: string;
  createdAt: string;
  paymentProofFileName?: string;
  paymentProofFileDataUrl?: string;
  paymentProofFileType?: string;
  senderAccountName?: string;
  senderAccountNumber?: string;
  senderBankName?: string;
  senderTransferMethod?: SenderTransferMethod;
  destinationBankName?: string;
  destinationAccountNumber?: string;
  paymentGatewayType?: string;
  paymentApprovalStatus: PaymentApprovalStatus;
  approvedAt?: string;
  rejectedAt?: string;
  approvedByUserId?: string;
  adminActionNotes?: string;
}

export interface AddPaymentPayload {
  userId: string;
  amount: number;
  paymentDate: string;
  paymentType: 'DP' | 'LUNAS' | 'LAINNYA';
  paymentMethod: 'Transfer' | 'Midtrans VA' | 'Cash' | 'Lainnya';
  notes?: string;
  senderAccountName?: string;
  senderAccountNumber?: string;
  senderBankName?: string;
  senderTransferMethod?: SenderTransferMethod;
  destinationBankName?: string;
  destinationAccountNumber?: string;
  paymentGatewayType?: string;
  paymentApprovalStatus: PaymentApprovalStatus;
}


export interface Vehicle {
  id: string;
  type: 'Bus' | 'HiAce' | 'SUV' | '';
  name: string;
  plateNumber: string;
  driverName?: string;
  driverPhone?: string;
  companyName?: string;
}

export enum ChatParty {
  ADMIN = 'Admin Ewako',
  CUSTOMER = 'Customer',
}

export interface ChatMessage {
  id: string;
  orderId: string;
  timestamp: string;
  sender: ChatParty | string;
  senderId: string;
  text?: string;
  fileName?: string;
  fileType?: 'image/jpeg' | 'image/png' | 'application/pdf';
  fileDataUrl?: string;
  isRead?: boolean;
}

// --- START: Handling Report Types ---

export interface HandlingReportJemaahHealth {
  id: string; // Added for unique keying in UI
  jemaahId: string;
  namaJemaah: string;
  nomorPaspor: string;
  nomorVisa?: string;
  kotaAsal?: string;
  keluhan: string;
}

export type BusCondition = 'Bagus' | 'Standar' | 'Jelek' | '';
export type JemaahCondition = 'Baik' | 'Sakit' | '';
export type HotelAvailabilityStatus = 'Tersedia' | 'Belum Tersedia' | '';
export type HotelRoomCountStatus = 'Sesuai' | 'Belum Sesuai' | '';
export type BaggageDistributionStatus = 'Sudah' | 'Belum' | '';
export type YesNoStatus = 'Ya' | 'Tidak' | '';

// --- Specifics types (data part of the report) ---
export interface HandlingArrivalReportDataSpecifics {
  waktuKedatanganJemaah: string;
  namaMaskapai: string;
  terminalKedatangan: string;
  namaMutowif?: string;
  namaTourGuideLeader?: string;
  transportasiNamaBus: string;
  transportasiNomorSeriBus: string;
  transportasiNoDriver: string;
  transportasiKondisiBus: BusCondition;
  bagasiKoper: number;
  bagasiTasKabin: number;
  bagasiLain?: string;
  absensiJemaah: { [jemaahId: string]: boolean };
  kondisiJemaahUmum: JemaahCondition;
  jemaahSakitDetails: HandlingReportJemaahHealth[];
  waktuKeberangkatanDariAirport: string;
}

export interface HandlingHotelCheckInReportDataSpecifics {
  lokasiHotel: 'Mekah' | 'Madinah' | '';
  namaHotel?: string;
  tanggalCheckInOut?: string;
  durasi?: string;
  jumlahKamarByTipe?: string;
  ketersediaanKunci: HotelAvailabilityStatus;
  alasanKunciBelumTersedia?: string;
  ketersediaanJumlahKamar: HotelRoomCountStatus;
  alasanKamarBelumSesuai?: string;
  solusiKamarBelumSesuai?: string;
  bagasiKoperUlang?: number;
  bagasiTasKabinUlang?: number;
  bagasiLainUlang?: string;
  distribusiBagasi: BaggageDistributionStatus;
  nomorKamarBagasiBelumTerdistribusi?: string;
}

export interface HandlingActivityReportDataSpecifics {
  namaKegiatan: string;
  transportasiNamaBus: string;
  transportasiNomorSeriBus: string;
  transportasiNoDriver: string;
  transportasiKondisiBus: BusCondition;
  absensiJemaahKeberangkatan: { [jemaahId: string]: boolean };
  tujuanKegiatan: string[];
  kondisiJemaahUmum: JemaahCondition;
  jemaahSakitDetails: HandlingReportJemaahHealth[];
  waktuKembaliDariKegiatan: string;
  rangkumanPerjalanan?: string;
}

export interface HandlingDepartureReportDataSpecifics {
  bagasiKoperAkhir: number;
  bagasiTasKabinAkhir: number;
  bagasiLainAkhir?: string;
  absensiJemaahCheckout: { [jemaahId: string]: boolean };
  kondisiJemaahUmumCheckout: JemaahCondition;
  jemaahSakitDetailsCheckout: HandlingReportJemaahHealth[];
  waktuCheckoutHotel: string;
  transportasiNamaBusKeAirport: string;
  transportasiNomorSeriBusKeAirport: string;
  transportasiNoDriverKeAirport: string;
  adaCityTourTambahan: YesNoStatus;
  tujuanCityTourTambahan?: string;
  waktuKedatanganDiAirportPulang: string;
  namaAirportTerminalPulang: string;
  catatanProsesCheckInCounter?: string;
  catatanProsesPembagianTiket?: string;
  catatanProsesBoarding?: string;
}

// Re-exporting original data types without petugasPJ info
// This is to maintain compatibility while refactoring
export type HandlingArrivalReportData = HandlingArrivalReportDataSpecifics;
export type HandlingHotelCheckInReportData = HandlingHotelCheckInReportDataSpecifics;
export type HandlingActivityReportData = HandlingActivityReportDataSpecifics;
export type HandlingDepartureReportData = HandlingDepartureReportDataSpecifics;


// Union type for the 'data' part of a report
export type ReportDataSpecificsType = 
  | HandlingArrivalReportDataSpecifics
  | HandlingHotelCheckInReportDataSpecifics
  | HandlingActivityReportDataSpecifics
  | HandlingDepartureReportDataSpecifics;

// The main HandlingReport object structure
export interface HandlingReport {
  id: string;
  orderId: string;
  reportType: 'Arrival' | 'HotelCheckIn' | 'Activity' | 'Departure';
  createdByUserId: string; // Admin or Staff User ID who created the entry
  petugasPJId: string; // Staff User ID responsible for this report instance
  petugasPJName?: string; // Staff User Name
  createdAt: string; // ISO datetime string
  data: ReportDataSpecificsType; // Contains only the specific data
}

// Payload for creating/updating a handling report via the service
export interface AddHandlingReportServicePayload {
  reportType: 'Arrival' | 'HotelCheckIn' | 'Activity' | 'Departure';
  createdByUserId: string;
  petugasPJId: string;
  petugasPJName?: string;
  data: ReportDataSpecificsType;
}

// --- END: Handling Report Types ---

export interface Order {
  id: string;
  userId: string;
  serviceType: ServiceType;
  data: HotelBookingData | VisaBookingData | HandlingBookingData | JastipBookingData;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
  adminNotes?: string;
  customerConfirmation?: boolean;
  packageInfo?: PackageInfoData;
  manifest?: ManifestItem[];
  payments?: Payment[];
  chatHistory?: ChatMessage[];
  handlingReports?: HandlingReport[];
  totalPrice?: number;
}
