
import { ChatMessage, Order, User } from '../types'; // Corrected path for User and Order

const API_BASE_URL = 'http://localhost:3002/api'; // Pastikan port sesuai

// Helper untuk mendapatkan token JWT dari localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('ewakoRoyalAuthToken');
};

// Helper untuk fetch request dengan Authorization header
async function fetchApi<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    ...(options.headers ? (options.headers as Record<string, string>) : {}),
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Untuk FormData, Content-Type di-set otomatis oleh browser, jadi jangan di-override manual
  if (!(options.body instanceof FormData)) {
     if (!headers['Content-Type']) {
        headers['Content-Type'] = 'application/json';
    }
  }

  try {
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: `HTTP error! status: ${response.statusText || response.status}` }));
      throw new Error(errorData.message || `API Error: ${response.status} - Unknown error`);
    }
    if (response.status === 204) { 
      return undefined as T;
    }
    return await response.json() as T;
  } catch (error) {
    console.error('Fetch API error (ChatService):', url, options, error);
    throw error;
  }
}

export const getChatMessagesForOrder = async (orderId: string): Promise<ChatMessage[]> => {
  return fetchApi<ChatMessage[]>(`${API_BASE_URL}/orders/${orderId}/chat`);
};

// Helper function untuk membaca file sebagai data URL (untuk preview di client)
const readFileAsDataURL = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
};

export const sendChatMessage = async (
  orderId: string,
  senderName: string,
  senderId: string,
  text?: string,
  file?: File
): Promise<ChatMessage | null> => {
  if (!text && !file) {
    console.error("Chat message must have text or a file.");
    return null;
  }

  const formData = new FormData();
  formData.append('senderName', senderName);
  formData.append('senderId', senderId); // Backend akan menggunakan ini untuk validasi atau logging
  if (text) formData.append('text', text);
  if (file) formData.append('chatFile', file, file.name); // 'chatFile' harus cocok dengan nama field di backend (multer)
  
  try {
    const newMessage = await fetchApi<ChatMessage>(`${API_BASE_URL}/orders/${orderId}/chat`, {
      method: 'POST',
      body: formData, 
      // Tidak perlu set Content-Type untuk FormData, browser akan menanganinya
    });

    // Client-side Data URL generation for immediate preview if image
    if (newMessage && file && !newMessage.fileDataUrl && file.type.startsWith('image/') && file.size < 1 * 1024 * 1024) { // Batas 1MB untuk preview
        try { newMessage.fileDataUrl = await readFileAsDataURL(file); } 
        catch (e) { console.error("Error reading file as Data URL for UI preview:", e); }
    }
    
    console.log(`%c[Chat Service] Pesan dikirim ke order ${orderId}.`, 'color: green;');
    return newMessage;
  } catch (error) {
    console.error("Failed to send chat message via API:", error);
    throw error; // Rethrow untuk ditangani oleh pemanggil
  }
};
