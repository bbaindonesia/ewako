
import { User } from '../types';
import { sendNotificationToCustomer } from './whatsappService'; 

const API_BASE_URL = 'http://localhost:3002/api';

async function handleApiResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: `HTTP error! status: ${response.statusText || response.status}` }));
    throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
  }
  if (response.status === 204) { 
      return undefined as T;
  }
  return response.json();
}

const getAuthToken = (): string | null => {
  return localStorage.getItem('ewakoRoyalAuthToken');
};

const mapApiUserToFrontendUser = (apiUser: any): User => {
  return {
    id: String(apiUser.id), // Ensure ID is string
    email: apiUser.email,
    phone: apiUser.phone,
    name: apiUser.name,
    role: apiUser.role,
    ppiuName: apiUser.ppiu_name || apiUser.ppiuName, // Handle snake_case
    address: apiUser.address,
    accountStatus: apiUser.account_status || apiUser.accountStatus, // Handle snake_case
    // password is not mapped from API responses to frontend User state
  };
};

export const loginUser = async (emailOrPhone: string, passwordInput: string): Promise<User> => {
  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ emailOrPhone, password: passwordInput }),
  });
  const data = await handleApiResponse<{ token: string; user: any }>(response);
  
  localStorage.setItem('ewakoRoyalAuthToken', data.token);
  localStorage.setItem('ewakoRoyalUserId', String(data.user.id)); 
  localStorage.setItem('ewakoRoyalUserRole', data.user.role);

  window.dispatchEvent(new CustomEvent('customAuthChange'));

  return mapApiUserToFrontendUser(data.user); 
};

export const registerUser = async (userData: Omit<User, 'id' | 'role' | 'accountStatus'> & { password?: string }): Promise<User> => {
  const response = await fetch(`${API_BASE_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData), 
  });
  const data = await handleApiResponse<{ message: string, user?: any }>(response);
  if (data.user) {
    return mapApiUserToFrontendUser(data.user);
  } else {
    console.warn("Registrasi berhasil tapi tidak ada data user dikembalikan dari API:", data.message);
    throw new Error(data.message || "Registrasi berhasil, menunggu persetujuan Admin.");
  }
};

export const getUsers = async (roleFilter?: User['role'] | User['role'][]): Promise<User[]> => {
  let url = `${API_BASE_URL}/users`;
  if (roleFilter) {
    const rolesToFilterQuery = Array.isArray(roleFilter) ? roleFilter.join(',') : roleFilter;
    url += `?role=${rolesToFilterQuery}`;
  }
  const token = getAuthToken();
  const response = await fetch(url, {
    headers: token ? { 'Authorization': `Bearer ${token}` } : {}
  });
  const apiUsers = await handleApiResponse<any[]>(response);
  return apiUsers.map(mapApiUserToFrontendUser);
};

export const getUserById = async (userId: string): Promise<User | undefined> => {
  const token = getAuthToken();
  try {
    const response = await fetch(`${API_BASE_URL}/users/${userId}`, {
        headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (response.status === 404) return undefined; // User not found
    const apiUser = await handleApiResponse<any>(response);
    return mapApiUserToFrontendUser(apiUser);
  } catch (error) {
    if ((error as Error).message.toLowerCase().includes('not found') || (error as Error).message.includes('404')) {
      return undefined;
    }
    console.error(`Error fetching user by ID ${userId}:`, error);
    throw error;
  }
};

export const updateUser = async (userId: string, updates: Partial<Omit<User, 'id' | 'role' | 'accountStatus' | 'password'>>): Promise<User | undefined> => {
  const token = getAuthToken();
  const response = await fetch(`${API_BASE_URL}/users/${userId}`, {
    method: 'PUT',
    headers: { 
        'Content-Type': 'application/json',
        ...(token && {'Authorization': `Bearer ${token}`})
    },
    body: JSON.stringify(updates),
  });
  const apiUser = await handleApiResponse<any>(response);
  return mapApiUserToFrontendUser(apiUser);
};

export const updateUserAccountStatus = async (userId: string, newStatus: User['accountStatus']): Promise<User | undefined> => {
  const token = getAuthToken();
  const updatedUserFromApi = await fetch(`${API_BASE_URL}/users/${userId}/account-status`, {
    method: 'PUT',
    headers: { 
        'Content-Type': 'application/json',
        ...(token && {'Authorization': `Bearer ${token}`})
    },
    body: JSON.stringify({ accountStatus: newStatus }),
  }).then(res => handleApiResponse<any>(res));

  const updatedUser = mapApiUserToFrontendUser(updatedUserFromApi);

  if (updatedUser && updatedUser.phone) {
    let message = '';
    if (newStatus === 'active') {
      message = `Akun Ewako Royal Anda (${updatedUser.name}) telah DIAKTIFKAN oleh Admin. Anda sekarang dapat login.`;
    } else if (newStatus === 'suspended') {
      message = `Akun Ewako Royal Anda (${updatedUser.name}) telah DITANGGUHKAN oleh Admin. Silakan hubungi Admin untuk informasi lebih lanjut.`;
    } else if (newStatus === 'pending_approval') {
      message = `Status akun Ewako Royal Anda (${updatedUser.name}) diubah menjadi 'Menunggu Persetujuan'.`;
    }
    if (message) {
      sendNotificationToCustomer(updatedUser.phone, message); 
    }
  }
  return updatedUser;
};
