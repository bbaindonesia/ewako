import { AdminManagedBankAccount, JastipItemType, JastipUnit, SenderTransferMethod } from './types'; // Ensure correct import

export const ADMIN_WHATSAPP_NUMBER = "+966566943064"; // Replace with actual number for production
export const APP_NAME = "EWAKO ROYAL";

export const PRIMARY_COLOR_METALLIC_RED = "#B71C1C";
export const SECONDARY_COLOR_METALLIC_GOLD = "#D4AF37";

export const MOCK_API_KEY = "YOUR_GEMINI_API_KEY"; // Placeholder for Gemini API Key if used

export const MOCK_MUTOWIFS = [
  { id: "m1", name: "Abdullah", phone: "+966501234567" },
  { id: "m2", name: "Muhammad", phone: "+966507654321" },
  { id: "m3", name: "Ahmad", phone: "+966509876543" },
];

export const JASTIP_UNITS_MAP: { [key in JastipItemType]?: JastipUnit[] } = {
  [JastipItemType.FOOD]: [JastipUnit.BOX, JastipUnit.KG, JastipUnit.PCS],
  [JastipItemType.DATES]: [JastipUnit.BOX, JastipUnit.KG, JastipUnit.PCS],
  [JastipItemType.CLOTHES]: [JastipUnit.PCS, JastipUnit.KODI],
  [JastipItemType.PERFUME]: [JastipUnit.BOTTLE, JastipUnit.LUSIN],
  [JastipItemType.OTHER]: [JastipUnit.PCS, JastipUnit.UNIT],
};

// Default support contacts
export const DEFAULT_SUPPORT_PHONE = "+628110000000"; // Example Main Admin Phone
export const DEFAULT_SUPPORT_EMAIL = "support@ewakoroyal.com"; // Example Main Admin Email

// This will be replaced by admin-managed accounts. 
// Kept for reference or potential fallback if admin hasn't set any.
export const FALLBACK_BANK_ACCOUNTS: AdminManagedBankAccount[] = [
  { 
    id: 'fallback_bsi',
    bankName: 'Bank Syariah Indonesia (BSI)', 
    bankCode: '451',
    accountNumber: '7123456789', 
    accountHolderName: 'PT EWAKO ROYAL NUSANTARA',
    logoUrl: '/assets/bsi-logo.png' 
  },
  { 
    id: 'fallback_bca',
    bankName: 'Bank Central Asia (BCA)', 
    bankCode: '014',
    accountNumber: '0123456789', 
    accountHolderName: 'PT EWAKO ROYAL NUSANTARA',
    logoUrl: '/assets/bca-logo.png'
  },
];


export const MIDTRANS_VA_OPTIONS = [
  { name: 'BNI Virtual Account', code: 'bni_va', logoUrl: '/assets/bni-logo.png' },
  { name: 'BCA Virtual Account', code: 'bca_va', logoUrl: '/assets/bca-logo.png' },
  { name: 'Permata Virtual Account', code: 'permata_va', logoUrl: '/assets/permata-logo.png' },
  { name: 'BRI Virtual Account', code: 'bri_va', logoUrl: '/assets/bri-logo.png' },
  { name: 'Mandiri Bill Payment', code: 'mandiri_bill', logoUrl: '/assets/mandiri-logo.png' },
  { name: 'GoPay / QRIS', code: 'gopay_qris', logoUrl: '/assets/gopay-qris-logo.png' },
];

export const SENDER_TRANSFER_METHODS: { value: SenderTransferMethod, label: string }[] = [
    { value: '', label: 'Pilih Metode Transfer' },
    { value: 'ATM', label: 'ATM' },
    { value: 'MobileBanking', label: 'Mobile Banking' },
    { value: 'InternetBanking', label: 'Internet Banking' },
    { value: 'Teller', label: 'Teller Bank' },
];

export const INDONESIAN_BANK_LIST = [
    { name: "Bank Central Asia (BCA)", code: "014", logoUrl: "/assets/bca-logo.png" },
    { name: "Bank Mandiri", code: "008", logoUrl: "/assets/mandiri-logo.png" },
    { name: "Bank Negara Indonesia (BNI)", code: "009", logoUrl: "/assets/bni-logo.png" },
    { name: "Bank Rakyat Indonesia (BRI)", code: "002", logoUrl: "/assets/bri-logo.png" },
    { name: "Bank Syariah Indonesia (BSI)", code: "451", logoUrl: "/assets/bsi-logo.png" },
    { name: "Bank CIMB Niaga", code: "022" },
    { name: "Bank Permata", code: "013", logoUrl: "/assets/permata-logo.png" },
    { name: "Bank Danamon", code: "011" },
    { name: "Bank Tabungan Negara (BTN)", code: "200" },
    { name: "Bank OCBC NISP", code: "028" },
    { name: "Bank Maybank Indonesia", code: "016" },
    { name: "Bank UOB Indonesia", code: "023" },
    { name: "Bank DBS Indonesia", code: "046" },
    { name: "Standard Chartered Bank", code: "050" },
    { name: "Bank Muamalat Indonesia", code: "147" },
    // Add more banks as needed
    { name: "Lainnya (Input Manual)", code: "999" } 
];