import React from 'react';
import { HashRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import BookServicePage from './pages/BookServicePage';
import HotelBookingPage from './pages/HotelBookingPage';
import VisaBookingPage from './pages/VisaBookingPage';
import HandlingBookingPage from './pages/HandlingBookingPage';
import JastipPage from './pages/JastipPage';
import MyOrdersPage from './pages/MyOrdersPage';
import OrderDetailsPage from './pages/OrderDetailsPage';
import AccountPage from './pages/AccountPage';
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import AdminManageOrdersPage from './pages/admin/AdminManageOrdersPage';
import AdminOrderDetailsPage from './pages/admin/AdminOrderDetailsPage';
import AdminSettingsPage from './pages/admin/AdminSettingsPage';
import NotFoundPage from './pages/NotFoundPage';
import { LoadingSpinner } from './components/ui/LoadingSpinner';
import FlightBookingPage from './pages/FlightBookingPage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import { Layout } from './components/Layout'; // Added import for Layout

// Import actual admin pages
import AdminManageUsersPage from './pages/admin/AdminManageUsersPage';
import AdminUserDetailsPage from './pages/admin/AdminUserDetailsPage';
import AdminManageVehiclesPage from './pages/admin/AdminManageVehiclesPage';
import AdminChatPage from './pages/admin/AdminChatPage';
import AdminHandlingReportPage from './pages/admin/handling/AdminHandlingReportPage';

console.log("%c EWAKO ROYAL APP.TSX (MAIN COMPONENT) IS RUNNING - VERSION: DEBUG_V7_DIAGNOSTIC_LOG_ENHANCED ", "background: darkblue; color: white; font-size: 16px; font-weight: bold;");

// Mock Auth Check
export const useAuth = () => {
  const getInitialAuth = () => !!localStorage.getItem('ewakoRoyalUserId');
  const getInitialRole = () => localStorage.getItem('ewakoRoyalUserRole') as 'customer' | 'admin' | 'tim_staff' | null;
  const getInitialUserId = () => localStorage.getItem('ewakoRoyalUserId');

  const [internalIsAuthenticated, setInternalIsAuthenticated] = React.useState<boolean>(getInitialAuth);
  const [internalUserRole, setInternalUserRole] = React.useState<'customer' | 'admin' | 'tim_staff' | null>(getInitialRole);
  const [internalUserId, setInternalUserId] = React.useState<string | null>(getInitialUserId);

  React.useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === 'ewakoRoyalUserId' || event.key === 'ewakoRoyalUserRole' || event.key === 'ewakoRoyalAuthToken') {
        const storedUserId = localStorage.getItem('ewakoRoyalUserId');
        const storedUserRole = localStorage.getItem('ewakoRoyalUserRole') as 'customer' | 'admin' | 'tim_staff' | null;
        setInternalIsAuthenticated(!!storedUserId);
        setInternalUserRole(storedUserRole);
        setInternalUserId(storedUserId);
        console.log(`%c[Auth Sync Hook] Storage changed. New Auth State: ${!!storedUserId}, Role: ${storedUserRole}`, "color: purple;");
      }
    };
    window.addEventListener('storage', handleStorageChange);
    // Also listen for custom 'authChange' events if dispatched from login/logout explicitly
    const handleCustomAuthChange = () => {
        const storedUserId = localStorage.getItem('ewakoRoyalUserId');
        const storedUserRole = localStorage.getItem('ewakoRoyalUserRole') as 'customer' | 'admin' | 'tim_staff' | null;
        setInternalIsAuthenticated(!!storedUserId);
        setInternalUserRole(storedUserRole);
        setInternalUserId(storedUserId);
        console.log(`%c[Auth Sync Hook] Custom auth event. New Auth State: ${!!storedUserId}, Role: ${storedUserRole}`, "color: darkcyan;");
    };
    window.addEventListener('customAuthChange', handleCustomAuthChange);

    return () => {
        window.removeEventListener('storage', handleStorageChange);
        window.removeEventListener('customAuthChange', handleCustomAuthChange);
    };
  }, []);
  
  return { 
    isAuthenticated: internalIsAuthenticated, 
    userRole: internalUserRole, 
    userId: internalUserId, 
    isLoading: false 
  };
};


const ProtectedRoute: React.FC<{ allowedRoles?: Array<'customer' | 'admin' | 'tim_staff'> }> = ({ allowedRoles }) => {
  const { isAuthenticated, userRole, isLoading } = useAuth();

  if (isLoading) { 
    return ( <div className="flex justify-center items-center h-screen bg-[#0A0514]"> <LoadingSpinner size="lg" /> </div> );
  }
  if (!isAuthenticated) { 
    console.log("%c[ProtectedRoute] User not authenticated. Redirecting to /login.", "color: red;");
    return <Navigate to="/login" replace />; 
  }
  if (allowedRoles && userRole && !allowedRoles.includes(userRole)) {
    console.log(`%c[ProtectedRoute] User role '${userRole}' not allowed. Redirecting.`, "color: orange;");
    if (userRole === 'admin' || userRole === 'tim_staff') {
        return <Navigate to={'/admin'} replace />;
    }
    return <Navigate to={'/'} replace />;
  }
  return <Outlet />;
};


const App: React.FC = () => {
  const initialAuthForLog = useAuth(); 
  console.log(
    `%c[App.tsx Init (Main Component) - V7] Diagnostic Log:
    --------------------------------------
    Window HREF: ${window.location.href}
    Window Hash: ${window.location.hash}
    Initial isAuthenticated (from useAuth): ${initialAuthForLog.isAuthenticated}
    Initial User Role (from useAuth): ${initialAuthForLog.userRole}
    Initial User ID (from useAuth): ${initialAuthForLog.userId}
    --------------------------------------`,
    "color: blue; font-weight: bold; font-size: 14px; border: 1px solid blue; padding: 5px;"
  );
  
  // This effect will run once when App mounts, and then whenever the auth state changes.
  // It helps ensure that App.tsx rerenders correctly when login/logout happens.
  React.useEffect(() => {
    const forceUpdateOnAuthChange = () => {
        console.log("%c[App.tsx Effect] Auth change detected by custom event, forcing re-check.", "color: teal");
        // No need to setState here, useAuth hook handles its own state and will trigger re-render.
    };
    window.addEventListener('customAuthChange', forceUpdateOnAuthChange);
    return () => window.removeEventListener('customAuthChange', forceUpdateOnAuthChange);
  }, []);


  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />

        <Route element={<ProtectedRoute />}>
          <Route path="/book" element={<BookServicePage />} />
          <Route path="/book/hotel" element={<HotelBookingPage />} />
          <Route path="/book/visa" element={<VisaBookingPage />} />
          <Route path="/book/handling" element={<HandlingBookingPage />} />
          <Route path="/book/train" element={<Layout><div><h1>Tiket Kereta (Segera Hadir)</h1></div></Layout>} />
          <Route path="/book/flight" element={<FlightBookingPage />} /> 
          <Route path="/jastip" element={<JastipPage />} />
          <Route path="/orders" element={<MyOrdersPage />} />
          <Route path="/orders/:orderId" element={<OrderDetailsPage />} />
          <Route path="/account" element={<AccountPage />} />
        </Route>

        <Route element={<ProtectedRoute allowedRoles={['admin', 'tim_staff']} />}>
          <Route path="/admin" element={<AdminDashboardPage />} />
          <Route path="/admin/orders" element={<AdminManageOrdersPage />} />
          <Route path="/admin/orders/:orderId" element={<AdminOrderDetailsPage />} />
          <Route path="/admin/settings" element={<AdminSettingsPage />} />
          <Route path="/admin/users" element={<AdminManageUsersPage />} />
          <Route path="/admin/users/:userId" element={<AdminUserDetailsPage />} />
          <Route path="/admin/vehicles" element={<AdminManageVehiclesPage />} />
          <Route path="/admin/chat" element={<AdminChatPage />} />
          <Route path="/admin/chat/:orderId" element={<AdminChatPage />} /> 
          <Route path="/admin/orders/:orderId/handling-reports" element={<AdminHandlingReportPage />} />
          <Route path="/admin/app-settings" element={<Layout><div><h1>Pengaturan Aplikasi (Segera Hadir)</h1></div></Layout>} />
        </Route>
        
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </HashRouter>
  );
};

export default App;