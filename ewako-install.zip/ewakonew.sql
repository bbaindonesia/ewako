-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Waktu pembuatan: 20 Jun 2025 pada 22.03
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ewakonew`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin_bank_accounts`
--

CREATE TABLE `admin_bank_accounts` (
  `id` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_code` varchar(10) DEFAULT NULL,
  `account_number` varchar(50) NOT NULL,
  `account_holder_name` varchar(255) NOT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bus_routes`
--

CREATE TABLE `bus_routes` (
  `id` varchar(255) NOT NULL,
  `package_info_order_id` varchar(255) NOT NULL,
  `route_date` date NOT NULL,
  `from_location` varchar(255) NOT NULL,
  `to_location` varchar(255) NOT NULL,
  `route_vehicle_id` varchar(255) DEFAULT NULL,
  `vehicle_details` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `sender_name` varchar(255) NOT NULL,
  `sender_id` varchar(255) NOT NULL,
  `text` text DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `handling_reports`
--

CREATE TABLE `handling_reports` (
  `id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `report_type` enum('Arrival','HotelCheckIn','Activity','Departure') NOT NULL,
  `created_by_user_id` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `data_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data_json`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `hotel_info_details`
--

CREATE TABLE `hotel_info_details` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nights` int(11) NOT NULL,
  `rooms_quad` int(11) DEFAULT 0,
  `rooms_triple` int(11) DEFAULT 0,
  `rooms_double` int(11) DEFAULT 0,
  `check_in` date DEFAULT NULL,
  `check_out` date DEFAULT NULL,
  `price_quad_sar` decimal(10,2) DEFAULT NULL,
  `price_triple_sar` decimal(10,2) DEFAULT NULL,
  `price_double_sar` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `manifest_items`
--

CREATE TABLE `manifest_items` (
  `id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `nama_jemaah` varchar(255) NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan','') DEFAULT '',
  `tanggal_lahir` date DEFAULT NULL,
  `usia` int(11) DEFAULT NULL,
  `nomor_visa` varchar(100) DEFAULT NULL,
  `nama_di_paspor` varchar(255) NOT NULL,
  `nomor_paspor` varchar(100) NOT NULL,
  `tanggal_terbit_paspor` date DEFAULT NULL,
  `tanggal_expired_paspor` date DEFAULT NULL,
  `kota_tempat_issued_paspor` varchar(255) DEFAULT NULL,
  `kota_asal_keberangkatan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `service_type` enum('Hotel','Visa','Handling','Tiket Kereta','Jasa Titipan') NOT NULL,
  `status` enum('Request Confirmation','Tentative Confirmation','Definite Confirmation','Confirmed by Admin','Downpayment Received','Lunas','Rejected by Customer','Cancelled') NOT NULL DEFAULT 'Request Confirmation',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `admin_notes` text DEFAULT NULL,
  `customer_confirmation` tinyint(1) DEFAULT NULL,
  `total_price_idr` decimal(15,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_handling_data`
--

CREATE TABLE `order_handling_data` (
  `order_id` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `ppiu_name` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text DEFAULT NULL,
  `pax` int(11) NOT NULL,
  `include_mutowif` tinyint(1) DEFAULT 0,
  `mutowif_name` varchar(255) DEFAULT NULL,
  `handling_price_per_pax_sar` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_hotel_data`
--

CREATE TABLE `order_hotel_data` (
  `order_id` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `ppiu_name` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text DEFAULT NULL,
  `madinah_hotel_detail_id` varchar(255) DEFAULT NULL,
  `makkah_hotel_detail_id` varchar(255) DEFAULT NULL,
  `include_handling` tinyint(1) DEFAULT 0,
  `handling_pax` int(11) DEFAULT NULL,
  `handling_price_per_pax_sar` decimal(10,2) DEFAULT NULL,
  `include_visa` tinyint(1) DEFAULT 0,
  `visa_pax` int(11) DEFAULT NULL,
  `visa_price_per_pax_usd` decimal(10,2) DEFAULT NULL,
  `visa_vehicle_type` enum('Bus','HiAce','SUV','') DEFAULT '',
  `visa_airline_name` varchar(255) DEFAULT NULL,
  `visa_arrival_date` datetime DEFAULT NULL,
  `visa_departure_date` datetime DEFAULT NULL,
  `muasasah_name` varchar(255) DEFAULT NULL,
  `bus_price_total_sar` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_jastip_data`
--

CREATE TABLE `order_jastip_data` (
  `order_id` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `item_type` enum('Makanan','Pakaian','Parfum','Kurma','Lainnya','') NOT NULL,
  `unit` enum('Box','Kg','Pcs','Kodi','Botol','Lusin','Unit','') NOT NULL,
  `quantity` int(11) NOT NULL,
  `delivery_address` text NOT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_visa_data`
--

CREATE TABLE `order_visa_data` (
  `order_id` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `ppiu_name` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text DEFAULT NULL,
  `pax` int(11) NOT NULL,
  `vehicle_type` enum('Bus','HiAce','SUV','') DEFAULT '',
  `muasasah_name` varchar(255) DEFAULT NULL,
  `visa_price_per_pax_usd` decimal(10,2) DEFAULT NULL,
  `bus_price_total_sar` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `package_info`
--

CREATE TABLE `package_info` (
  `order_id` varchar(255) NOT NULL,
  `group_code` varchar(255) DEFAULT NULL,
  `ppiu_name` varchar(255) DEFAULT NULL,
  `ppiu_phone` varchar(20) DEFAULT NULL,
  `pax_count` int(11) DEFAULT 0,
  `madinah_hotel_info_str` text DEFAULT NULL,
  `makkah_hotel_info_str` text DEFAULT NULL,
  `madinah_hotel_structured_id` varchar(255) DEFAULT NULL,
  `makkah_hotel_structured_id` varchar(255) DEFAULT NULL,
  `bus_vehicle_id` varchar(255) DEFAULT NULL,
  `bus_name` varchar(255) DEFAULT NULL,
  `bus_vehicle_type` enum('Bus','HiAce','SUV','') DEFAULT '',
  `bus_driver_name` varchar(255) DEFAULT NULL,
  `bus_driver_phone` varchar(20) DEFAULT NULL,
  `bus_syarikah_number` varchar(255) DEFAULT NULL,
  `mutowif_name` varchar(255) DEFAULT NULL,
  `mutowif_phone` varchar(20) DEFAULT NULL,
  `representative_name` varchar(255) DEFAULT NULL,
  `representative_phone` varchar(20) DEFAULT NULL,
  `ewako_royal_phone` varchar(20) DEFAULT NULL,
  `airline_name` varchar(255) DEFAULT NULL,
  `airline_code` varchar(50) DEFAULT NULL,
  `pnr_code` varchar(50) DEFAULT NULL,
  `arrival_date_time` datetime DEFAULT NULL,
  `arrival_terminal` varchar(50) DEFAULT NULL,
  `departure_date_time` datetime DEFAULT NULL,
  `departure_terminal` varchar(50) DEFAULT NULL,
  `tour_leader_name` varchar(255) DEFAULT NULL,
  `tour_leader_phone` varchar(20) DEFAULT NULL,
  `tour_guide_name` varchar(255) DEFAULT NULL,
  `tour_guide_phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `payments`
--

CREATE TABLE `payments` (
  `id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `amount_idr` decimal(15,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_type` enum('DP','LUNAS','LAINNYA') NOT NULL,
  `payment_method` enum('Transfer','Midtrans VA','Cash','Lainnya') NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_proof_file_name` varchar(255) DEFAULT NULL,
  `payment_proof_file_path` varchar(255) DEFAULT NULL,
  `payment_proof_file_type` varchar(100) DEFAULT NULL,
  `sender_account_name` varchar(255) DEFAULT NULL,
  `sender_account_number` varchar(100) DEFAULT NULL,
  `sender_bank_name` varchar(255) DEFAULT NULL,
  `sender_transfer_method` enum('Teller','ATM','MobileBanking','InternetBanking','') DEFAULT '',
  `destination_bank_name` varchar(255) DEFAULT NULL,
  `destination_account_number` varchar(100) DEFAULT NULL,
  `payment_gateway_type` varchar(100) DEFAULT NULL,
  `payment_approval_status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `approved_at` datetime DEFAULT NULL,
  `rejected_at` datetime DEFAULT NULL,
  `approved_by_user_id` varchar(255) DEFAULT NULL,
  `admin_action_notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `role` enum('customer','admin','tim_staff') NOT NULL,
  `ppiu_name` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `account_status` enum('pending_approval','active','suspended') DEFAULT 'pending_approval',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `vehicles`
--

CREATE TABLE `vehicles` (
  `id` varchar(255) NOT NULL,
  `type` enum('Bus','HiAce','SUV','') NOT NULL,
  `name` varchar(255) NOT NULL,
  `plate_number` varchar(20) NOT NULL,
  `driver_name` varchar(255) DEFAULT NULL,
  `driver_phone` varchar(20) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `ziarah_routes`
--

CREATE TABLE `ziarah_routes` (
  `id` varchar(255) NOT NULL,
  `package_info_order_id` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `kota` enum('Madinah','Mekah','Thaif','Jeddah','Lainnya','') NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  `remake` enum('Ziarah','City Tour','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin_bank_accounts`
--
ALTER TABLE `admin_bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bus_routes`
--
ALTER TABLE `bus_routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `package_info_order_id` (`package_info_order_id`),
  ADD KEY `fk_busroute_vehicle` (`route_vehicle_id`);

--
-- Indeks untuk tabel `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indeks untuk tabel `handling_reports`
--
ALTER TABLE `handling_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `created_by_user_id` (`created_by_user_id`);

--
-- Indeks untuk tabel `hotel_info_details`
--
ALTER TABLE `hotel_info_details`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `manifest_items`
--
ALTER TABLE `manifest_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `order_handling_data`
--
ALTER TABLE `order_handling_data`
  ADD PRIMARY KEY (`order_id`);

--
-- Indeks untuk tabel `order_hotel_data`
--
ALTER TABLE `order_hotel_data`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `madinah_hotel_detail_id` (`madinah_hotel_detail_id`),
  ADD KEY `makkah_hotel_detail_id` (`makkah_hotel_detail_id`);

--
-- Indeks untuk tabel `order_jastip_data`
--
ALTER TABLE `order_jastip_data`
  ADD PRIMARY KEY (`order_id`);

--
-- Indeks untuk tabel `order_visa_data`
--
ALTER TABLE `order_visa_data`
  ADD PRIMARY KEY (`order_id`);

--
-- Indeks untuk tabel `package_info`
--
ALTER TABLE `package_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `madinah_hotel_structured_id` (`madinah_hotel_structured_id`),
  ADD KEY `makkah_hotel_structured_id` (`makkah_hotel_structured_id`),
  ADD KEY `fk_package_bus_vehicle` (`bus_vehicle_id`);

--
-- Indeks untuk tabel `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `approved_by_user_id` (`approved_by_user_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indeks untuk tabel `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `plate_number` (`plate_number`);

--
-- Indeks untuk tabel `ziarah_routes`
--
ALTER TABLE `ziarah_routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `package_info_order_id` (`package_info_order_id`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `bus_routes`
--
ALTER TABLE `bus_routes`
  ADD CONSTRAINT `bus_routes_ibfk_1` FOREIGN KEY (`package_info_order_id`) REFERENCES `package_info` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_busroute_vehicle` FOREIGN KEY (`route_vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `handling_reports`
--
ALTER TABLE `handling_reports`
  ADD CONSTRAINT `handling_reports_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `handling_reports_ibfk_2` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`);

--
-- Ketidakleluasaan untuk tabel `manifest_items`
--
ALTER TABLE `manifest_items`
  ADD CONSTRAINT `manifest_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `order_handling_data`
--
ALTER TABLE `order_handling_data`
  ADD CONSTRAINT `order_handling_data_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `order_hotel_data`
--
ALTER TABLE `order_hotel_data`
  ADD CONSTRAINT `order_hotel_data_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_hotel_data_ibfk_2` FOREIGN KEY (`madinah_hotel_detail_id`) REFERENCES `hotel_info_details` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `order_hotel_data_ibfk_3` FOREIGN KEY (`makkah_hotel_detail_id`) REFERENCES `hotel_info_details` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `order_jastip_data`
--
ALTER TABLE `order_jastip_data`
  ADD CONSTRAINT `order_jastip_data_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `order_visa_data`
--
ALTER TABLE `order_visa_data`
  ADD CONSTRAINT `order_visa_data_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `package_info`
--
ALTER TABLE `package_info`
  ADD CONSTRAINT `fk_package_bus_vehicle` FOREIGN KEY (`bus_vehicle_id`) REFERENCES `vehicles` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `package_info_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `package_info_ibfk_2` FOREIGN KEY (`madinah_hotel_structured_id`) REFERENCES `hotel_info_details` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `package_info_ibfk_3` FOREIGN KEY (`makkah_hotel_structured_id`) REFERENCES `hotel_info_details` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`approved_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `ziarah_routes`
--
ALTER TABLE `ziarah_routes`
  ADD CONSTRAINT `ziarah_routes_ibfk_1` FOREIGN KEY (`package_info_order_id`) REFERENCES `package_info` (`order_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
